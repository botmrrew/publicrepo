import React, { useState, useEffect } from 'react';
import {
  X,
  Cpu,
  Play,
  Square,
  Zap,
  ShieldCheck,
  Sliders,
  ArrowUpRight,
  CheckCircle2,
  Layers,
  RefreshCw,
} from 'lucide-react';
import {
  RegisteredExchangeAPI,
  TensorOrder,
  ArbitrageResult,
} from '../types/quantum';

interface TensorBotMicroModalProps {
  isOpen: boolean;
  onClose: () => void;
  registeredApis: RegisteredExchangeAPI[];
  selectedApiId: string;
  onSelectApi: (id: string) => void;
  botRunning: boolean;
  onToggleBot: () => void;
  orders: TensorOrder[];
  onExecuteSingleCycle: (config: {
    strategy: TensorOrder['strategy'];
    pair: string;
    capitalUsd: number;
    tensorRanks: [number, number, number];
    learningRate: number;
  }) => void;
  latestArbitrage: ArbitrageResult;
}

export const TensorBotMicroModal: React.FC<TensorBotMicroModalProps> = ({
  isOpen,
  onClose,
  registeredApis,
  selectedApiId,
  onSelectApi,
  botRunning,
  onToggleBot,
  orders,
  onExecuteSingleCycle,
  latestArbitrage,
}) => {
  const [strategy, setStrategy] =
    useState<TensorOrder['strategy']>('QAOA Arbitragem');
  const [pair, setPair] = useState<string>('WETH/USDC (Arbitrum)');
  const [capitalUsd, setCapitalUsd] = useState<number>(2500);
  const [tensorRankQubits, setTensorRankQubits] = useState<number>(4);
  const [tensorRankLayers, setTensorRankLayers] = useState<number>(3);
  const [learningRate, setLearningRate] = useState<number>(0.01);
  const [slippageMax, setSlippageMax] = useState<number>(0.5);
  const [tensorMatrix, setTensorMatrix] = useState<number[][]>([
    [0.84, -0.31, 0.92, 0.45],
    [-0.12, 0.77, 0.64, -0.58],
    [0.95, 0.23, -0.41, 0.89],
    [0.38, -0.69, 0.81, 0.72],
  ]);

  // Esc key closes MicroModal cleanly
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Recompute tensor weights when parameters shift or bot is running
  useEffect(() => {
    if (!isOpen) return;
    const rows = tensorRankQubits;
    const cols = 4;
    const next: number[][] = [];
    for (let r = 0; r < rows; r++) {
      const row: number[] = [];
      for (let c = 0; c < cols; c++) {
        const angle =
          (r + 1) * (c + 1) * learningRate * 45 +
          tensorRankLayers * 0.7 +
          (botRunning ? Date.now() * 0.001 : 0);
        row.push(Number(Math.tanh(Math.sin(angle) * 1.4).toFixed(2)));
      }
      next.push(row);
    }
    setTensorMatrix(next);
  }, [tensorRankQubits, tensorRankLayers, learningRate, botRunning, isOpen]);

  if (!isOpen) return null;

  const activeApi =
    registeredApis.find((a) => a.id === selectedApiId) || registeredApis[0];

  const handleTriggerCycle = () => {
    onExecuteSingleCycle({
      strategy,
      pair,
      capitalUsd,
      tensorRanks: [tensorRankQubits, tensorRankLayers, 4],
      learningRate,
    });
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="tensor-micromodal-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-4xl bg-[#0F1420] border border-slate-800 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* MicroModal Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#111827] border-b border-slate-800">
          <div className="flex items-center gap-3">
            <Cpu className="w-5 h-5 text-cyan-400 shrink-0" />
            <div>
              <h2
                id="tensor-micromodal-title"
                className="text-base font-semibold text-slate-100 tracking-tight"
              >
                Tensor MicroModal — Quantum Neural Trading Bot
              </h2>
              <p className="text-xs text-slate-400">
                focuscrawl.si · PennyLane QNode + PyTorch MPS Tensor Contraction
                · API Conectada: {activeApi?.name}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span
              className={`text-xs font-mono font-medium ${
                botRunning ? 'text-emerald-400' : 'text-amber-400'
              }`}
            >
              {botRunning ? '● Autônomo Ativo' : '▲ Standby Manual'}
            </span>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded-lg transition-colors"
              aria-label="Fechar Tensor MicroModal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* MicroModal Body */}
        <div className="p-6 overflow-y-auto grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Bot Configuration & Registered API Routing */}
          <div className="lg:col-span-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                Parâmetros do Tensor & Roteamento de API
              </span>
              <span className="text-xs font-mono text-slate-400">
                Shape: [{tensorRankQubits}, {tensorRankLayers}, 4]
              </span>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  API de Trading Cadastrada (Execução Direta)
                </label>
                <select
                  value={selectedApiId}
                  onChange={(e) => onSelectApi(e.target.value)}
                  className="w-full bg-[#0B0E17] border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 font-mono focus:outline-none focus:border-cyan-500"
                >
                  {registeredApis.map((api) => (
                    <option key={api.id} value={api.id}>
                      {api.name} ({api.apiKeyMasked}) — {api.latencyMs}ms
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Estratégia Quântica
                  </label>
                  <select
                    value={strategy}
                    onChange={(e) =>
                      setStrategy(e.target.value as TensorOrder['strategy'])
                    }
                    className="w-full bg-[#0B0E17] border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-500"
                  >
                    <option value="QAOA Arbitragem">QAOA Arbitragem DEX</option>
                    <option value="VQE Rebalance">VQE Portfolio Rebalance</option>
                    <option value="Black-Scholes Hedge">
                      Black-Scholes Delta Hedge
                    </option>
                    <option value="QML Momentum">
                      PennyLane QNN Momentum
                    </option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Par / Rota Alvo
                  </label>
                  <select
                    value={pair}
                    onChange={(e) => setPair(e.target.value)}
                    className="w-full bg-[#0B0E17] border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 font-mono focus:outline-none focus:border-cyan-500"
                  >
                    <option value="WETH/USDC (Arbitrum)">
                      WETH/USDC (Arbitrum)
                    </option>
                    <option value="BTC/USDT (Binance Prime)">
                      BTC/USDT (Binance Prime)
                    </option>
                    <option value="SOL/USDC (Uniswap V3)">
                      SOL/USDC (Uniswap V3)
                    </option>
                    <option value="ARB/WETH (Curve+1inch)">
                      ARB/WETH (Curve+1inch)
                    </option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Capital por Ciclo (USD)
                  </label>
                  <input
                    type="number"
                    min={100}
                    max={100000}
                    step={100}
                    value={capitalUsd}
                    onChange={(e) =>
                      setCapitalUsd(Math.max(100, Number(e.target.value)))
                    }
                    className="w-full bg-[#0B0E17] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono tabular-nums text-slate-100 focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Slippage Máximo (%)
                  </label>
                  <input
                    type="number"
                    min={0.05}
                    max={5}
                    step={0.05}
                    value={slippageMax}
                    onChange={(e) =>
                      setSlippageMax(Math.max(0.05, Number(e.target.value)))
                    }
                    className="w-full bg-[#0B0E17] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono tabular-nums text-slate-100 focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              {/* Tensor Hyperparameters */}
              <div className="pt-2 space-y-3 border-t border-slate-800/80">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-400">
                      Qubits do Tensor (Wires PennyLane)
                    </span>
                    <span className="font-mono tabular-nums text-cyan-400">
                      {tensorRankQubits} Qubits
                    </span>
                  </div>
                  <input
                    type="range"
                    min={2}
                    max={6}
                    value={tensorRankQubits}
                    onChange={(e) =>
                      setTensorRankQubits(Number(e.target.value))
                    }
                    className="w-full accent-cyan-500 cursor-pointer"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-400">Entanglement Reps</span>
                      <span className="font-mono tabular-nums text-slate-200">
                        L={tensorRankLayers}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={5}
                      value={tensorRankLayers}
                      onChange={(e) =>
                        setTensorRankLayers(Number(e.target.value))
                      }
                      className="w-full accent-cyan-500 cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-400">Adam Learning Rate</span>
                      <span className="font-mono tabular-nums text-slate-200">
                        {learningRate.toFixed(3)}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0.002}
                      max={0.05}
                      step={0.002}
                      value={learningRate}
                      onChange={(e) => setLearningRate(Number(e.target.value))}
                      className="w-full accent-cyan-500 cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-3 flex items-center gap-3">
              <button
                onClick={onToggleBot}
                className={`flex-1 py-2.5 px-4 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0 ${
                  botRunning
                    ? 'bg-rose-600 hover:bg-rose-500 text-white'
                    : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950'
                }`}
              >
                {botRunning ? (
                  <>
                    <Square className="w-3.5 h-3.5 fill-current" />
                    Pausar Bot Autônomo
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-current" />
                    Iniciar Bot Autônomo
                  </>
                )}
              </button>

              <button
                onClick={handleTriggerCycle}
                className="py-2.5 px-4 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
              >
                <Zap className="w-3.5 h-3.5 text-cyan-400" />
                Disparar Ordem Tensor
              </button>
            </div>
          </div>

          {/* Right Column: Live Tensor State Matrix & Execution Feed */}
          <div className="lg:col-span-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-medium text-slate-300 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
                Matriz de Pesos Quânticos ⟨PauliZ | Tensor MPS⟩
              </span>
              <span className="text-xs font-mono text-emerald-400 tabular-nums">
                Score QAOA: {latestArbitrage.quantumEigenvalue.toFixed(4)}
              </span>
            </div>

            {/* Tensor Weight Grid */}
            <div className="bg-[#0B0E17] border border-slate-800 rounded-lg p-3">
              <div className="grid grid-cols-4 gap-1.5 font-mono text-xs tabular-nums">
                {tensorMatrix.map((row, rIdx) =>
                  row.map((val, cIdx) => {
                    const isPositive = val >= 0;
                    return (
                      <div
                        key={`${rIdx}-${cIdx}`}
                        className={`px-2 py-1.5 rounded text-right border ${
                          isPositive
                            ? 'bg-cyan-950/30 border-cyan-800/40 text-cyan-300'
                            : 'bg-slate-900 border-slate-800 text-slate-400'
                        }`}
                      >
                        <div className="text-[10px] text-slate-500 flex justify-between">
                          <span>q{rIdx}</span>
                          <span>θ{cIdx}</span>
                        </div>
                        <div className="font-semibold">
                          {val >= 0 ? `+${val.toFixed(2)}` : val.toFixed(2)}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
              <div className="mt-2.5 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                <span>Ansatz: TwoLocal(RY, CZ)</span>
                <span>·</span>
                <span>Optimizer: Adam + COBYLA</span>
                <span>·</span>
                <span>Guard: Anti-Honeypot QML</span>
              </div>
            </div>

            {/* Recent Bot Orders */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-medium text-slate-300">
                  Últimas Execuções na API ({orders.length})
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  Slippage max {slippageMax}%
                </span>
              </div>

              <div className="bg-[#0B0E17] border border-slate-800 rounded-lg divide-y divide-slate-800/80 max-h-48 overflow-y-auto">
                {orders.slice(0, 6).map((ord) => (
                  <div
                    key={ord.id}
                    className="px-3 py-2 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-medium text-slate-200 flex items-center gap-1.5">
                        <span
                          className={`font-mono font-semibold ${
                            ord.side === 'COMPRA'
                              ? 'text-emerald-400'
                              : ord.side === 'ARBITRAGEM'
                              ? 'text-cyan-400'
                              : 'text-amber-400'
                          }`}
                        >
                          {ord.side}
                        </span>
                        <span>{ord.pair}</span>
                        <span className="text-slate-500">·</span>
                        <span className="text-slate-400 font-mono">
                          {ord.tensorShape}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {ord.strategy} · {ord.exchangeApiName} · {ord.timestamp}
                      </div>
                    </div>

                    <div className="text-right font-mono tabular-nums">
                      <div
                        className={`font-semibold ${
                          ord.pnlUsd >= 0 ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {ord.pnlUsd >= 0 ? '+' : ''}${ord.pnlUsd.toFixed(2)} (
                        {ord.expectedReturnPct >= 0 ? '+' : ''}
                        {ord.expectedReturnPct.toFixed(2)}%)
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Cap: ${ord.capitalUsd.toLocaleString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* MicroModal Footer */}
        <div className="px-6 py-3 bg-[#111827] border-t border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>
              Validação pré-ordem ativa: QML Token Validator bloqueia pools com
              concentração &gt;70%
            </span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition-colors"
            >
              Fechar Janela
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
