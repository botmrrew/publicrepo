import React, { useState, useEffect, useMemo } from 'react';
import {
  Activity,
  Database,
  RefreshCw,
  Filter,
  Search,
  Sliders,
  Download,
  Zap,
  CheckCircle2,
  Layers,
  Terminal,
  Cpu,
  Radio,
} from 'lucide-react';

export interface ScrapedSourceMetric {
  id: string;
  sourceName: string;
  category: 'CEX' | 'DEX' | 'ONCHAIN' | 'SENTIMENT';
  targetUrl: string;
  recordsExtracted: number;
  recordsPerSec: number;
  parseSuccessRate: number;
  latencyMs: number;
  anomaliesDetected: number;
  aggregatedSentiment: number;
  dominantSignal: string;
  status: string;
}

interface DataAnalysisScrapingDashboardProps {
  onSendSignalToTensorBot?: (signalInfo: {
    sourceName: string;
    signal: string;
    sentiment: number;
  }) => void;
  onApiLogUpdate?: (log: {
    endpoint: string;
    status: number;
    timestamp: string;
    payloadPreview: string;
  }) => void;
}

export const DataAnalysisScrapingDashboard: React.FC<
  DataAnalysisScrapingDashboardProps
> = ({ onSendSignalToTensorBot, onApiLogUpdate }) => {
  // Interactive Filter & Telemetry Controls
  const [categoryFilter, setCategoryFilter] = useState<
    'ALL' | 'CEX' | 'DEX' | 'ONCHAIN' | 'SENTIMENT'
  >('ALL');
  const [timeWindow, setTimeWindow] = useState<'1m' | '5m' | '15m' | '1h'>('5m');
  const [crawlerWorkers, setCrawlerWorkers] = useState<number>(24);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [liveStreaming, setLiveStreaming] = useState<boolean>(true);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Selected source for deep-dive JSON schema & field extraction inspection
  const [selectedSourceId, setSelectedSourceId] =
    useState<string>('src-binance-l3');

  // Telemetry & Aggregated Scraping State
  const [summary, setSummary] = useState({
    totalRecordsScraped: 301000,
    throughputRecordsPerSec: 5260.4,
    schemaIntegrityPct: 99.64,
    avgCrawlerLatencyMs: 17,
    deduplicationRatioPct: 99.42,
  });

  const [sources, setSources] = useState<ScrapedSourceMetric[]>([
    {
      id: 'src-binance-l3',
      sourceName: 'Binance Spot & Perp Orderbook Scraper',
      category: 'CEX',
      targetUrl: 'wss://stream.binance.com:9443/ws/!bookTicker',
      recordsExtracted: 98420,
      recordsPerSec: 1920.5,
      parseSuccessRate: 99.96,
      latencyMs: 11,
      anomaliesDetected: 1,
      aggregatedSentiment: 0.72,
      dominantSignal: 'ORDERBOOK_IMBALANCE_BULL',
      status: 'Nominal',
    },
    {
      id: 'src-uniswap-v3',
      sourceName: 'Uniswap V3 Subgraph & Mempool Crawler',
      category: 'DEX',
      targetUrl: 'https://arb1.arbitrum.io/rpc#uniswap-v3-indexer',
      recordsExtracted: 61280,
      recordsPerSec: 1045.2,
      parseSuccessRate: 99.84,
      latencyMs: 16,
      anomaliesDetected: 2,
      aggregatedSentiment: 0.78,
      dominantSignal: 'QAOA_FLASH_SPREAD_READY',
      status: 'Nominal',
    },
    {
      id: 'src-etherscan-whale',
      sourceName: 'Etherscan + Arbitrum Whale Wallet Scraper',
      category: 'ONCHAIN',
      targetUrl: 'https://api.etherscan.io/v2/api?module=account',
      recordsExtracted: 32940,
      recordsPerSec: 540.8,
      parseSuccessRate: 99.52,
      latencyMs: 24,
      anomaliesDetected: 3,
      aggregatedSentiment: 0.58,
      dominantSignal: 'WHALE_ACCUMULATION_SOL',
      status: 'Nominal',
    },
    {
      id: 'src-coingecko-agg',
      sourceName: 'CoinGecko & DEXScreener Liquidity Aggregator',
      category: 'SENTIMENT',
      targetUrl: 'https://api.coingecko.com/api/v3/coins/markets',
      recordsExtracted: 44120,
      recordsPerSec: 785.0,
      parseSuccessRate: 99.91,
      latencyMs: 19,
      anomaliesDetected: 0,
      aggregatedSentiment: 0.81,
      dominantSignal: 'VOLATILITY_BREAKOUT_ARB',
      status: 'Nominal',
    },
    {
      id: 'src-curve-1inch',
      sourceName: 'Curve 3Pool + 1inch Pathfinder Scraper',
      category: 'DEX',
      targetUrl: 'https://api.1inch.dev/swap/v6.0/42161/quote',
      recordsExtracted: 53810,
      recordsPerSec: 912.4,
      parseSuccessRate: 99.38,
      latencyMs: 18,
      anomaliesDetected: 1,
      aggregatedSentiment: 0.67,
      dominantSignal: 'STABLE_PEG_ARBITRAGE',
      status: 'Nominal',
    },
    {
      id: 'src-fin-news-nlp',
      sourceName: 'FocusCrawl Macro & SEC Filing Scraper',
      category: 'SENTIMENT',
      targetUrl: 'https://focuscrawl.si/crawlers/sec-edgar-stream',
      recordsExtracted: 19450,
      recordsPerSec: 348.6,
      parseSuccessRate: 99.74,
      latencyMs: 28,
      anomaliesDetected: 1,
      aggregatedSentiment: 0.64,
      dominantSignal: 'ETF_FLOW_POSITIVE',
      status: 'Nominal',
    },
  ]);

  // Historical time-series points for Dual-Axis Extraction vs Parse Integrity curve
  const [seriesHistory, setSeriesHistory] = useState<
    Array<{
      tickLabel: string;
      recordsPerSec: number;
      integrityPct: number;
      latencyMs: number;
    }>
  >([
    { tickLabel: 'T-25s', recordsPerSec: 4820, integrityPct: 99.5, latencyMs: 18 },
    { tickLabel: 'T-20s', recordsPerSec: 4990, integrityPct: 99.6, latencyMs: 17 },
    { tickLabel: 'T-15s', recordsPerSec: 5140, integrityPct: 99.7, latencyMs: 16 },
    { tickLabel: 'T-10s', recordsPerSec: 5080, integrityPct: 99.6, latencyMs: 18 },
    { tickLabel: 'T-05s', recordsPerSec: 5290, integrityPct: 99.8, latencyMs: 15 },
    { tickLabel: 'AGORA', recordsPerSec: 5360, integrityPct: 99.7, latencyMs: 16 },
  ]);

  const [hoveredPointIdx, setHoveredPointIdx] = useState<number | null>(null);
  const [dispatchBanner, setDispatchBanner] = useState<string | null>(null);

  // Fetch Aggregated Scraping Telemetry from Express API
  const fetchScrapingTelemetry = async (
    cat = categoryFilter,
    win = timeWindow,
    workersCount = crawlerWorkers
  ) => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/borsignature/scraping-analysis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          category: cat,
          window: win,
          workers: workersCount,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setSummary(data.telemetrySummary);
        setSources(data.sources);
        setSeriesHistory((prev) => {
          const nowTime = new Date().toLocaleTimeString('pt-BR', {
            hour12: false,
          });
          const nextPt = {
            tickLabel: nowTime,
            recordsPerSec: data.telemetrySummary.throughputRecordsPerSec,
            integrityPct: data.telemetrySummary.schemaIntegrityPct,
            latencyMs: data.telemetrySummary.avgCrawlerLatencyMs,
          };
          return [...prev.slice(-7), nextPt];
        });
        if (onApiLogUpdate) {
          onApiLogUpdate({
            endpoint: 'POST /api/borsignature/scraping-analysis',
            status: res.status,
            timestamp: data.timestamp,
            payloadPreview: JSON.stringify(data.telemetrySummary, null, 2),
          });
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  // Live streaming telemetry interval
  useEffect(() => {
    if (!liveStreaming) return;
    const interval = setInterval(() => {
      setSources((prev) =>
        prev.map((src) => {
          const deltaRec = Math.floor(120 + Math.random() * 290);
          const nextRps = Number(
            Math.max(
              150,
              src.recordsPerSec + (Math.random() - 0.48) * 42
            ).toFixed(1)
          );
          const nextLat = Math.max(
            7,
            Math.min(45, src.latencyMs + Math.round((Math.random() - 0.5) * 3))
          );
          return {
            ...src,
            recordsExtracted: src.recordsExtracted + deltaRec,
            recordsPerSec: nextRps,
            latencyMs: nextLat,
          };
        })
      );

      setSeriesHistory((prev) => {
        const last = prev[prev.length - 1];
        const nextRps = Number(
          Math.max(
            3200,
            last.recordsPerSec + (Math.random() - 0.47) * 180
          ).toFixed(1)
        );
        const nextInt = Number(
          Math.min(
            99.99,
            Math.max(99.1, last.integrityPct + (Math.random() - 0.49) * 0.08)
          ).toFixed(2)
        );
        const nowStr = new Date().toLocaleTimeString('pt-BR', {
          hour12: false,
        });
        return [
          ...prev.slice(-7),
          {
            tickLabel: nowStr,
            recordsPerSec: nextRps,
            integrityPct: nextInt,
            latencyMs: Math.round(14 + Math.random() * 6),
          },
        ];
      });
    }, 3200);

    return () => clearInterval(interval);
  }, [liveStreaming]);

  // Filtered sources by search and category
  const visibleSources = useMemo(() => {
    return sources.filter((s) => {
      const matchesCat =
        categoryFilter === 'ALL' || s.category === categoryFilter;
      const matchesQuery =
        !searchQuery.trim() ||
        s.sourceName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.dominantSignal.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.targetUrl.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCat && matchesQuery;
    });
  }, [sources, categoryFilter, searchQuery]);

  const activeSource =
    visibleSources.find((s) => s.id === selectedSourceId) ||
    visibleSources[0] ||
    sources[0];

  // Export CSV handler
  const handleExportCsv = () => {
    const headers = [
      'ID',
      'Fonte de Scraping',
      'Categoria',
      'Registros Extraidos',
      'Throughput (rec/s)',
      'Integridade (%)',
      'Latencia (ms)',
      'Sentimento Agregado',
      'Sinal Dominante',
    ];
    const rows = visibleSources.map((s) => [
      s.id,
      `"${s.sourceName}"`,
      s.category,
      s.recordsExtracted,
      s.recordsPerSec,
      s.parseSuccessRate,
      s.latencyMs,
      s.aggregatedSentiment,
      s.dominantSignal,
    ]);
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `focuscrawl_borsignature_scraping_analysis_${timeWindow}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 space-y-6">
      {/* Top Telemetry Header & Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-800">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400">
            <span>DATA ANALYSIS & SCRAPING TELEMETRY</span>
            <span aria-hidden="true">·</span>
            <span>focuscrawl.si × borsignature.com</span>
            <span aria-hidden="true">·</span>
            <span
              className={
                liveStreaming ? 'text-emerald-400' : 'text-amber-400'
              }
            >
              {liveStreaming ? '● STREAMING ATIVO' : '▲ STREAM PAUSADO'}
            </span>
          </div>
          <h3 className="text-xl font-bold text-slate-100 tracking-tight">
            Dashboard de Análise de Extração de Dados de Scraping Agregados
          </h3>
          <p className="text-xs text-slate-400">
            Telemetria em tempo real de coletores L2/L3, subgraphs DEX, carteiras
            baleia on-chain e sentimento macro para análise quantitativa.
          </p>
        </div>

        {/* Interactive Controls */}
        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            onClick={() => setLiveStreaming((s) => !s)}
            className={`px-3 py-2 rounded-lg text-xs font-mono font-medium border transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
              liveStreaming
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                : 'bg-slate-800 border-slate-700 text-slate-300'
            }`}
          >
            {liveStreaming ? '● Live Telemetry ON' : '▲ Live Telemetry OFF'}
          </button>

          <button
            onClick={() =>
              fetchScrapingTelemetry(categoryFilter, timeWindow, crawlerWorkers)
            }
            disabled={isLoading}
            className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`}
            />
            {isLoading ? 'Agregando...' : 'Sincronizar Scraping API'}
          </button>

          <button
            onClick={handleExportCsv}
            className="px-3 py-2 rounded-lg text-xs font-medium bg-[#0B0E17] hover:bg-slate-900 text-slate-200 border border-slate-800 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            Download CSV
          </button>
        </div>
      </div>

      {/* 4-Column Precision Telemetry KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#0B0E17] border border-slate-800 rounded-lg p-4">
          <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400">
            REGISTROS EXTRAÍDOS ({timeWindow})
          </div>
          <div className="mt-1 flex items-baseline">
            <span className="text-2xl font-mono font-bold tabular-nums text-slate-100">
              {visibleSources
                .reduce((acc, s) => acc + s.recordsExtracted, 0)
                .toLocaleString()}
            </span>
            <span className="text-xs uppercase font-mono text-slate-400 ml-1.5">
              DOCS
            </span>
          </div>
          <div className="mt-1 text-xs font-mono text-emerald-400">
            DELTA: +14.2% vs janela anterior
          </div>
        </div>

        <div className="bg-[#0B0E17] border border-slate-800 rounded-lg p-4">
          <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400">
            THROUGHPUT DE SCRAPING AGREGADO
          </div>
          <div className="mt-1 flex items-baseline">
            <span className="text-2xl font-mono font-bold tabular-nums text-cyan-400">
              {visibleSources
                .reduce((acc, s) => acc + s.recordsPerSec, 0)
                .toFixed(1)}
            </span>
            <span className="text-xs uppercase font-mono text-slate-400 ml-1.5">
              REC/S
            </span>
          </div>
          <div className="mt-1 text-xs font-mono text-slate-400">
            Workers Ativos: {crawlerWorkers} nodes
          </div>
        </div>

        <div className="bg-[#0B0E17] border border-slate-800 rounded-lg p-4">
          <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400">
            INTEGRIDADE DE PARSING & SCHEMA
          </div>
          <div className="mt-1 flex items-baseline">
            <span className="text-2xl font-mono font-bold tabular-nums text-emerald-400">
              {summary.schemaIntegrityPct.toFixed(2)}
            </span>
            <span className="text-xs uppercase font-mono text-slate-400 ml-1.5">
              %
            </span>
          </div>
          <div className="mt-1 text-xs font-mono text-slate-400">
            Deduplicação Hash: {summary.deduplicationRatioPct}%
          </div>
        </div>

        <div className="bg-[#0B0E17] border border-slate-800 rounded-lg p-4">
          <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400">
            LATÊNCIA MÉDIA DOS COLETORES
          </div>
          <div className="mt-1 flex items-baseline">
            <span className="text-2xl font-mono font-bold tabular-nums text-slate-100">
              {summary.avgCrawlerLatencyMs}
            </span>
            <span className="text-xs uppercase font-mono text-slate-400 ml-1.5">
              MS
            </span>
          </div>
          <div className="mt-1 text-xs font-mono text-cyan-400">
            ● SLA Sub-25ms Nominal
          </div>
        </div>
      </div>

      {/* Filter & Parameter Calibration Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-[#0B0E17] border border-slate-800 rounded-lg p-3.5">
        {/* Category Segmented Filter */}
        <div className="flex flex-wrap items-center gap-1 bg-[#111827] p-1 rounded-lg border border-slate-800">
          {(['ALL', 'CEX', 'DEX', 'ONCHAIN', 'SENTIMENT'] as const).map(
            (cat) => (
              <button
                key={cat}
                onClick={() => {
                  setCategoryFilter(cat);
                  fetchScrapingTelemetry(cat, timeWindow, crawlerWorkers);
                }}
                className={`px-3 py-1.5 text-xs font-mono font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  categoryFilter === cat
                    ? 'bg-cyan-500 text-slate-950 font-semibold'
                    : 'text-slate-400 hover:text-slate-100'
                }`}
              >
                {cat === 'ALL' ? 'Todas as Fontes (6)' : cat}
              </button>
            )
          )}
        </div>

        {/* Time Window & Crawler Concurrency Controls */}
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Janela de Agregação:</span>
            <div className="flex items-center gap-1 bg-[#111827] p-1 rounded-lg border border-slate-800 font-mono">
              {(['1m', '5m', '15m', '1h'] as const).map((w) => (
                <button
                  key={w}
                  onClick={() => {
                    setTimeWindow(w);
                    fetchScrapingTelemetry(categoryFilter, w, crawlerWorkers);
                  }}
                  className={`px-2 py-1 rounded text-xs transition-colors cursor-pointer ${
                    timeWindow === w
                      ? 'bg-slate-800 text-cyan-400 font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {w}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-400">Workers Paralelos:</span>
            <input
              type="range"
              min={6}
              max={64}
              step={6}
              value={crawlerWorkers}
              onChange={(e) => {
                const val = Number(e.target.value);
                setCrawlerWorkers(val);
              }}
              onMouseUp={() =>
                fetchScrapingTelemetry(
                  categoryFilter,
                  timeWindow,
                  crawlerWorkers
                )
              }
              className="w-24 accent-cyan-500 cursor-pointer"
            />
            <span className="font-mono text-cyan-400 tabular-nums w-8">
              {crawlerWorkers}x
            </span>
          </div>

          {/* Search Input */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filtrar scraper ou sinal..."
              className="bg-[#111827] border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>
      </div>

      {/* Visualizations Row: Dual-Axis Telemetry Curve + Spider/Radar Calibration */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Chart 1: Dual-Axis Extraction Velocity & Schema Integrity Curve */}
        <div className="lg:col-span-7 bg-[#0B0E17] border border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h4 className="text-sm font-semibold text-slate-100">
                Curva de Velocidade de Extração (REC/S) vs. Integridade de
                Schema (%)
              </h4>
              <p className="text-xs text-slate-400">
                Passe o cursor sobre os pontos de telemetria para inspecionar as
                coordenadas exatas (x, y)
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs font-mono">
              <span className="text-cyan-400">── Throughput (rec/s)</span>
              <span className="text-emerald-400">- - Integridade (%)</span>
            </div>
          </div>

          {/* SVG Dual-Axis Chart with Crosshair HUD */}
          <div className="relative pt-2">
            <svg
              viewBox="0 0 560 170"
              className="w-full h-44 overflow-visible cursor-crosshair"
            >
              <defs>
                <linearGradient id="scrapeArea" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#06B6D4" stopOpacity="0.28" />
                  <stop offset="100%" stopColor="#06B6D4" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Horizontal Grid Lines */}
              {[25, 65, 105, 145].map((yPos) => (
                <line
                  key={yPos}
                  x1="30"
                  y1={yPos}
                  x2="540"
                  y2={yPos}
                  stroke="#1E293B"
                  strokeDasharray="3 3"
                />
              ))}

              {(() => {
                const count = seriesHistory.length;
                const minRps = 3000;
                const maxRps = 6500;
                const coords = seriesHistory.map((pt, idx) => {
                  const x =
                    35 + (idx / Math.max(1, count - 1)) * (535 - 35);
                  const normY =
                    (pt.recordsPerSec - minRps) / (maxRps - minRps);
                  const y = 145 - Math.min(1, Math.max(0, normY)) * 115;

                  const normInt = (pt.integrityPct - 98.5) / 1.5;
                  const yInt = 145 - Math.min(1, Math.max(0, normInt)) * 115;
                  return { x, y, yInt, pt, idx };
                });

                const linePoints = coords
                  .map((c) => `${c.x.toFixed(1)},${c.y.toFixed(1)}`)
                  .join(' ');
                const areaPoints = `35,145 ${linePoints} 535,145`;
                const integrityPoints = coords
                  .map((c) => `${c.x.toFixed(1)},${c.yInt.toFixed(1)}`)
                  .join(' ');

                return (
                  <>
                    <polygon points={areaPoints} fill="url(#scrapeArea)" />
                    <polyline
                      fill="none"
                      stroke="#22D3EE"
                      strokeWidth="2.2"
                      points={linePoints}
                    />
                    <polyline
                      fill="none"
                      stroke="#34D399"
                      strokeWidth="1.8"
                      strokeDasharray="5 4"
                      points={integrityPoints}
                    />

                    {coords.map((c) => (
                      <g
                        key={c.idx}
                        onMouseEnter={() => setHoveredPointIdx(c.idx)}
                        onMouseLeave={() => setHoveredPointIdx(null)}
                      >
                        {hoveredPointIdx === c.idx && (
                          <line
                            x1={c.x}
                            y1="15"
                            x2={c.x}
                            y2="145"
                            stroke="#38BDF8"
                            strokeWidth="1"
                            strokeDasharray="2 2"
                          />
                        )}
                        <circle
                          cx={c.x}
                          cy={c.y}
                          r={hoveredPointIdx === c.idx ? 5 : 3.5}
                          fill="#0B0E17"
                          stroke="#22D3EE"
                          strokeWidth="2"
                        />
                        <text
                          x={c.x}
                          y="162"
                          textAnchor="middle"
                          className="fill-slate-500 text-[10px] font-mono"
                        >
                          {c.pt.tickLabel}
                        </text>
                      </g>
                    ))}
                  </>
                );
              })()}
            </svg>

            {/* Crosshair Coordinate Readout HUD */}
            <div className="mt-2 pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between text-xs font-mono text-slate-400">
              {hoveredPointIdx !== null && seriesHistory[hoveredPointIdx] ? (
                <>
                  <span className="text-cyan-400">
                    AMOSTRA [{seriesHistory[hoveredPointIdx].tickLabel}]
                  </span>
                  <span>
                    Throughput:{' '}
                    <strong className="text-slate-100">
                      {seriesHistory[hoveredPointIdx].recordsPerSec} rec/s
                    </strong>
                  </span>
                  <span>
                    Integridade:{' '}
                    <strong className="text-emerald-400">
                      {seriesHistory[hoveredPointIdx].integrityPct}%
                    </strong>
                  </span>
                  <span>
                    Latência:{' '}
                    <strong className="text-slate-100">
                      {seriesHistory[hoveredPointIdx].latencyMs} ms
                    </strong>
                  </span>
                </>
              ) : (
                <>
                  <span>SONDA DE TELEMETRIA ATIVA</span>
                  <span>
                    Última Leitura:{' '}
                    <strong className="text-cyan-400">
                      {seriesHistory[seriesHistory.length - 1]?.recordsPerSec}{' '}
                      rec/s
                    </strong>
                  </span>
                  <span>
                    Schema JSON:{' '}
                    <strong className="text-emerald-400">
                      {seriesHistory[seriesHistory.length - 1]?.integrityPct}%
                    </strong>
                  </span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Chart 2: Spider / Radar Scraping Quality Calibration + Deep JSON Inspector */}
        <div className="lg:col-span-5 bg-[#0B0E17] border border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm font-semibold text-slate-100">
                Calibração Multidimensional & Payload Extraído
              </h4>
              <p className="text-xs text-slate-400 truncate">
                Fonte selecionada: {activeSource.sourceName}
              </p>
            </div>
            <span className="text-xs font-mono text-cyan-400">
              {activeSource.category}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
            {/* Radar / Spider Chart */}
            <div className="sm:col-span-5 flex justify-center">
              <svg
                viewBox="0 0 160 160"
                className="w-36 h-36 overflow-visible"
                aria-label="Radar de qualidade de extração"
              >
                {/* Outer & Inner Pentagons */}
                <polygon
                  points="80,15 142,60 118,132 42,132 18,60"
                  fill="none"
                  stroke="#1E293B"
                  strokeWidth="1"
                />
                <polygon
                  points="80,40 117,67 103,110 57,110 43,67"
                  fill="none"
                  stroke="#1E293B"
                  strokeWidth="1"
                  strokeDasharray="2 2"
                />
                {/* Radial Axes */}
                <line x1="80" y1="80" x2="80" y2="15" stroke="#1E293B" />
                <line x1="80" y1="80" x2="142" y2="60" stroke="#1E293B" />
                <line x1="80" y1="80" x2="118" y2="132" stroke="#1E293B" />
                <line x1="80" y1="80" x2="42" y2="132" stroke="#1E293B" />
                <line x1="80" y1="80" x2="18" y2="60" stroke="#1E293B" />

                {/* Calibrated Data Polygon */}
                <polygon
                  points="80,22 135,62 112,125 46,122 26,62"
                  fill="rgba(6, 182, 212, 0.22)"
                  stroke="#06B6D4"
                  strokeWidth="2"
                />

                <text
                  x="80"
                  y="10"
                  textAnchor="middle"
                  className="fill-slate-400 text-[8px] font-mono"
                >
                  PARSE 99.9%
                </text>
                <text
                  x="148"
                  y="58"
                  textAnchor="start"
                  className="fill-slate-400 text-[8px] font-mono"
                >
                  SPEED
                </text>
                <text
                  x="125"
                  y="144"
                  textAnchor="middle"
                  className="fill-slate-400 text-[8px] font-mono"
                >
                  DEDUP
                </text>
                <text
                  x="35"
                  y="144"
                  textAnchor="middle"
                  className="fill-slate-400 text-[8px] font-mono"
                >
                  UPTIME
                </text>
                <text
                  x="12"
                  y="58"
                  textAnchor="end"
                  className="fill-slate-400 text-[8px] font-mono"
                >
                  SIGNAL
                </text>
              </svg>
            </div>

            {/* Live Normalized Schema Preview of Selected Source */}
            <div className="sm:col-span-7 bg-[#111827] border border-slate-800 rounded-lg p-3 font-mono text-[11px] space-y-1.5">
              <div className="flex items-center justify-between text-slate-400 border-b border-slate-800 pb-1">
                <span>Normalized Record</span>
                <span className="text-emerald-400">
                  ● {activeSource.latencyMs}ms
                </span>
              </div>
              <pre className="text-slate-300 overflow-x-auto leading-relaxed">
                <code>{`{
  "scraper": "${activeSource.id}",
  "cat": "${activeSource.category}",
  "rps": ${activeSource.recordsPerSec},
  "sentiment": ${activeSource.aggregatedSentiment},
  "signal": "${activeSource.dominantSignal}"
}`}</code>
              </pre>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
            <span className="text-slate-400 font-mono truncate max-w-[240px]">
              {activeSource.targetUrl}
            </span>
            <button
              onClick={() => {
                if (onSendSignalToTensorBot) {
                  onSendSignalToTensorBot({
                    sourceName: activeSource.sourceName,
                    signal: activeSource.dominantSignal,
                    sentiment: activeSource.aggregatedSentiment,
                  });
                }
                setDispatchBanner(
                  `Sinal "${activeSource.dominantSignal}" injetado no Tensor MicroModal com peso de sentimento ${(
                    activeSource.aggregatedSentiment * 100
                  ).toFixed(0)}%.`
                );
              }}
              className="px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 font-mono text-xs flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
            >
              <Zap className="w-3.5 h-3.5" />
              Injetar Sinal no Tensor Bot
            </button>
          </div>
        </div>
      </div>

      {dispatchBanner && (
        <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-700/50 flex items-center justify-between text-xs text-emerald-300 font-mono">
          <span>● {dispatchBanner}</span>
          <button
            onClick={() => setDispatchBanner(null)}
            className="text-slate-400 hover:text-slate-200 underline ml-4"
          >
            Ocultar
          </button>
        </div>
      )}

      {/* High-Density Aggregated Scraping Sources Table */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h4 className="text-sm font-semibold text-slate-100">
            Pipelines de Extração de Scraping Agregados ({visibleSources.length}{' '}
            fontes ativas)
          </h4>
          <span className="text-xs font-mono text-slate-400">
            Clique em uma linha para inspecionar o payload normalizado no radar
            acima
          </span>
        </div>

        <div className="overflow-x-auto border border-slate-800 rounded-lg">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-[#0B0E17] text-[11px] font-mono text-slate-400">
                <th className="py-2.5 px-4">Fonte / Pipeline de Scraping</th>
                <th className="py-2.5 px-4">Categoria</th>
                <th className="py-2.5 px-4 text-right">Extraídos</th>
                <th className="py-2.5 px-4 text-right">Velocidade</th>
                <th className="py-2.5 px-4 text-right">Parse OK</th>
                <th className="py-2.5 px-4 text-right">Latência</th>
                <th className="py-2.5 px-4 text-right">Sentimento</th>
                <th className="py-2.5 px-4">Sinal Extraído</th>
                <th className="py-2.5 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 text-xs">
              {visibleSources.map((src) => {
                const isSelected = src.id === activeSource.id;
                return (
                  <tr
                    key={src.id}
                    onClick={() => setSelectedSourceId(src.id)}
                    className={`cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-cyan-950/25 hover:bg-cyan-950/35'
                        : 'hover:bg-slate-900/60'
                    }`}
                  >
                    <td className="py-2.5 px-4">
                      <div className="font-medium text-slate-100">
                        {src.sourceName}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500 truncate max-w-xs">
                        {src.targetUrl}
                      </div>
                    </td>
                    <td className="py-2.5 px-4 font-mono text-cyan-400">
                      {src.category}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-200">
                      {src.recordsExtracted.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums text-cyan-300">
                      {src.recordsPerSec.toFixed(1)}/s
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums text-emerald-400">
                      {src.parseSuccessRate.toFixed(2)}%
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-300">
                      {src.latencyMs} ms
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono tabular-nums">
                      <span
                        className={
                          src.aggregatedSentiment >= 0.65
                            ? 'text-emerald-400 font-semibold'
                            : 'text-amber-400'
                        }
                      >
                        {(src.aggregatedSentiment * 100).toFixed(0)}% Bull
                      </span>
                    </td>
                    <td className="py-2.5 px-4 font-mono text-[11px] text-slate-200">
                      {src.dominantSignal}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono text-emerald-400">
                      ● {src.status}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
