import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Terminal,
  Database,
  Activity,
  Workflow,
  Send,
  LifeBuoy,
  Radio,
  Mail,
  ArrowUpRight,
  CheckCircle2,
  Code2,
  Sliders,
} from 'lucide-react';
import { DataAnalysisScrapingDashboard } from './DataAnalysisScrapingDashboard';

interface BorsignatureInteractiveStudioProps {
  onRegisterApiFromBorsignature?: (apiKey: string, endpoint: string) => void;
  onSendScrapingSignalToBot?: (signalInfo: {
    sourceName: string;
    signal: string;
    sentiment: number;
  }) => void;
}

type ChapterId =
  | 'Data Extraction'
  | 'Market Analysis'
  | 'CLI Integration'
  | 'Automated Workflow';

interface ChapterSpec {
  id: ChapterId;
  indexLabel: string;
  title: ChapterId;
  durationSec: number;
  subtitle: string;
  description: string;
  cliSnippet: string;
  metrics: { label: string; value: string; delta: string }[];
}

const CHAPTERS: ChapterSpec[] = [
  {
    id: 'Data Extraction',
    indexLabel: '01',
    title: 'Data Extraction',
    durationSec: 15,
    subtitle: 'Ingestão determinística de livros de ofertas L2/L3 e mempool DEX',
    description:
      'Extrai snapshots sub-milissegundo de múltiplas bolsas e pools on-chain com normalização automática de esquemas JSON e validação criptográfica.',
    cliSnippet: `borsig extract --sources binance,uniswap-v3,arbitrum \\
  --depth l2_orderbook \\
  --output-stream wss://stream.borsignature.com/v1/extract`,
    metrics: [
      { label: 'THROUGHPUT DE EXTRAÇÃO', value: '148,200', delta: 'msg/s' },
      { label: 'LATÊNCIA P99 INGESTÃO', value: '4.2', delta: 'ms' },
      { label: 'FONTES SIMULTÂNEAS', value: '38', delta: 'Venues' },
    ],
  },
  {
    id: 'Market Analysis',
    indexLabel: '02',
    title: 'Market Analysis',
    durationSec: 15,
    subtitle: 'Correlação em tempo real, superfícies de volatilidade e sinais QAOA',
    description:
      'Processa fluxos de ordens em matrizes de covariância contínuas, identificando desvios de arbitragem e desequilíbrios de liquidez institucional.',
    cliSnippet: `borsig analyze --pair BTC/USDT,ETH/USDC \\
  --model quantum-qaoa-spread \\
  --confidence-threshold 0.92`,
    metrics: [
      { label: 'PRECISÃO DE SINAL', value: '94.8', delta: '%' },
      { label: 'JANELA DE CORRELAÇÃO', value: '250', delta: 'ms' },
      { label: 'SPREAD LÍQUIDO MÉDIO', value: '+1.18', delta: '%' },
    ],
  },
  {
    id: 'CLI Integration',
    indexLabel: '03',
    title: 'CLI Integration',
    durationSec: 15,
    subtitle: 'Controle total via linha de comando e pipelines CI/CD financeiros',
    description:
      'Integre streams do borsignature.com diretamente ao seu terminal Linux/macOS, scripts Python Qiskit ou containers Docker com um único binário.',
    cliSnippet: `npx @borsignature/cli@latest login --key bsig_live_98a74e21
borsig pipe --from realtime-market --to ./tensor_bot_runner.py`,
    metrics: [
      { label: 'TEMPO DE SETUP CLI', value: '12', delta: 'seg' },
      { label: 'BINÁRIO NATIVO', value: 'Zero-Dep', delta: 'Rust/TS' },
      { label: 'FORMATO DE SAÍDA', value: 'JSONL / Arrow', delta: 'Stream' },
    ],
  },
  {
    id: 'Automated Workflow',
    indexLabel: '04',
    title: 'Automated Workflow',
    durationSec: 15,
    subtitle: 'Orquestração autônoma de webhooks, alertas e execução na API',
    description:
      'Dispara rotas de execução, rebalanceamento de carteira ou proteção de risco automaticamente quando condições de mercado são validadas.',
    cliSnippet: `borsig workflow deploy ./workflows/auto_hedger.yaml \\
  --trigger "spread_bps > 45" \\
  --target-api https://arb1.arbitrum.io/rpc`,
    metrics: [
      { label: 'WORKFLOWS ATIVOS', value: '1,420', delta: 'Pipelines' },
      { label: 'EXECUÇÃO DETERMINÍSTICA', value: '99.98', delta: '% SLA' },
      { label: 'TEMPO DE DISPARO API', value: '8.6', delta: 'ms' },
    ],
  },
];

const SUPPORT_LINKS = [
  {
    slug: 'docs-quickstart',
    title: 'Documentation & CLI Quickstart',
    description: 'Guia de instalação do binário borsig e autenticação de chaves.',
    endpointParam: 'CLI Quickstart & Auth',
  },
  {
    slug: 'api-reference',
    title: 'Real-Time WebSocket & REST API Reference',
    description: 'Esquemas de payload L2/L3, rate limits e filtros de símbolos.',
    endpointParam: 'WebSocket & REST Schema Reference',
  },
  {
    slug: 'workflow-webhooks',
    title: 'Automated Workflow & Webhook Signatures',
    description: 'Verificação HMAC-SHA256 e gatilhos de execução automatizada.',
    endpointParam: 'Automated Workflow Webhooks',
  },
  {
    slug: 'status-sla',
    title: 'System Telemetry & Institutional SLA Support',
    description: 'Monitoramento de uptime 99.98% e abertura de chamado técnico.',
    endpointParam: 'Institutional SLA & Status Check',
  },
];

export const BorsignatureInteractiveStudio: React.FC<
  BorsignatureInteractiveStudioProps
> = ({ onRegisterApiFromBorsignature, onSendScrapingSignalToBot }) => {
  // Interactive Video Player State
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [activeChapterIdx, setActiveChapterIdx] = useState<number>(0);
  const [chapterProgress, setChapterProgress] = useState<number>(0); // 0 to 100
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);

  // Live telemetry animated wave points inside the interactive video canvas
  const [waveTick, setWaveTick] = useState<number>(0);

  // Real-Time Data API State
  const [realtimeLoading, setRealtimeLoading] = useState<boolean>(false);
  const [realtimeResponse, setRealtimeResponse] = useState<{
    timestamp: string;
    activeModule: string;
    cliCommand: string;
    feed: Array<{
      pair: string;
      price: number;
      spreadBps: number;
      volume24hUsd: number;
      signal: string;
    }>;
  } | null>(null);

  // Support API State
  const [selectedSupportSlug, setSelectedSupportSlug] =
    useState<string>('docs-quickstart');
  const [supportLoading, setSupportLoading] = useState<boolean>(false);
  const [supportResponse, setSupportResponse] = useState<{
    ticketId: string;
    timestamp: string;
    requestedTopic: string;
    status: string;
  } | null>(null);

  // Newsletter API State (default pre-filled with botsigature@botsignature.com as requested)
  const [newsletterEmail, setNewsletterEmail] = useState<string>(
    'botsigature@botsignature.com'
  );
  const [newsletterLoading, setNewsletterLoading] = useState<boolean>(false);
  const [newsletterResponse, setNewsletterResponse] = useState<{
    subscribedEmail: string;
    confirmationCode: string;
    message: string;
    timestamp: string;
  } | null>(null);

  // Start Free CTA API State
  const [startFreeLoading, setStartFreeLoading] = useState<boolean>(false);
  const [startFreeResponse, setStartFreeResponse] = useState<{
    provisionedApiKey: string;
    cliInitCommand: string;
    accountEmail: string;
  } | null>(null);

  // Unified API Inspector Console Log
  const [lastApiCallLog, setLastApiCallLog] = useState<{
    endpoint: string;
    status: number;
    timestamp: string;
    payloadPreview: string;
  }>({
    endpoint: 'POST /api/borsignature/realtime-data',
    status: 200,
    timestamp: new Date().toISOString(),
    payloadPreview:
      '{"ok":true,"service":"borsignature.com Real-Time Market Intelligence API","status":"READY"}',
  });

  const currentChapter = CHAPTERS[activeChapterIdx];

  // Interactive Video Timeline Loop
  useEffect(() => {
    if (!isPlaying) return;
    const intervalMs = 120;
    const timer = setInterval(() => {
      setWaveTick((t) => t + 1);
      setChapterProgress((prev) => {
        const step = (100 / (currentChapter.durationSec * (1000 / intervalMs))) * playbackSpeed;
        if (prev + step >= 100) {
          setActiveChapterIdx((idx) => (idx + 1) % CHAPTERS.length);
          return 0;
        }
        return prev + step;
      });
    }, intervalMs);

    return () => clearInterval(timer);
  }, [isPlaying, activeChapterIdx, playbackSpeed, currentChapter.durationSec]);

  // Handler 1: Start Free Button -> Calls POST /api/borsignature/start-free
  const handleStartFreeApi = async () => {
    setStartFreeLoading(true);
    try {
      const res = await fetch('/api/borsignature/start-free', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          plan: 'Free Real-Time Intelligence Tier',
          email: newsletterEmail || 'botsigature@botsignature.com',
        }),
      });
      const data = await res.json();
      setStartFreeResponse(data);
      setLastApiCallLog({
        endpoint: 'POST /api/borsignature/start-free',
        status: res.status,
        timestamp: data.timestamp || new Date().toISOString(),
        payloadPreview: JSON.stringify(data, null, 2),
      });
      if (onRegisterApiFromBorsignature && data.provisionedApiKey) {
        onRegisterApiFromBorsignature(
          data.provisionedApiKey,
          'https://api.borsignature.com/v1/realtime'
        );
      }
    } catch (err) {
      console.error(err);
    } finally {
      setStartFreeLoading(false);
    }
  };

  // Handler 2: Real-Time Data Button -> Calls POST /api/borsignature/realtime-data
  const handleTriggerRealtimeApi = async () => {
    setRealtimeLoading(true);
    try {
      const res = await fetch('/api/borsignature/realtime-data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          symbol: 'BTC/USDT,ETH/USDC,SOL/USDC',
          interval: '500ms',
          chapter: currentChapter.title,
        }),
      });
      const data = await res.json();
      setRealtimeResponse(data);
      setLastApiCallLog({
        endpoint: 'POST /api/borsignature/realtime-data',
        status: res.status,
        timestamp: data.timestamp || new Date().toISOString(),
        payloadPreview: JSON.stringify(data, null, 2),
      });
    } catch (err) {
      console.error(err);
    } finally {
      setRealtimeLoading(false);
    }
  };

  // Handler 3: Support Button -> Calls POST /api/borsignature/support
  const handleTriggerSupportApi = async (customTopic?: string, slug?: string) => {
    setSupportLoading(true);
    const chosenLink =
      SUPPORT_LINKS.find((l) => l.slug === (slug || selectedSupportSlug)) ||
      SUPPORT_LINKS[0];
    try {
      const res = await fetch('/api/borsignature/support', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: customTopic || chosenLink.endpointParam,
          linkSlug: chosenLink.slug,
          priority: 'high',
        }),
      });
      const data = await res.json();
      setSupportResponse(data);
      setLastApiCallLog({
        endpoint: 'POST /api/borsignature/support',
        status: res.status,
        timestamp: data.timestamp || new Date().toISOString(),
        payloadPreview: JSON.stringify(data, null, 2),
      });
    } catch (err) {
      console.error(err);
    } finally {
      setSupportLoading(false);
    }
  };

  // Handler 4: Newsletter Subscribe Button -> Calls POST /api/borsignature/newsletter
  const handleSubscribeNewsletterApi = async (e: React.FormEvent) => {
    e.preventDefault();
    setNewsletterLoading(true);
    try {
      const res = await fetch('/api/borsignature/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: newsletterEmail,
          source: 'borsignature.com-interactive-video',
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setNewsletterResponse(data);
      }
      setLastApiCallLog({
        endpoint: 'POST /api/borsignature/newsletter',
        status: res.status,
        timestamp: data.timestamp || new Date().toISOString(),
        payloadPreview: JSON.stringify(data, null, 2),
      });
    } catch (err) {
      console.error(err);
    } finally {
      setNewsletterLoading(false);
    }
  };

  // Initial load of Real-Time Data so the panel is populated on arrival
  useEffect(() => {
    handleTriggerRealtimeApi();
  }, []);

  const overallProgressPercent =
    ((activeChapterIdx * 100 + chapterProgress) / (CHAPTERS.length * 100)) * 100;

  return (
    <div className="space-y-8">
      {/* =====================================================================
          HERO SECTION: "Automate Market Data" + "Real-Time Market Intelligence" + "Start Free"
          + INTERACTIVE VIDEO PLAYER STAGE (borsignature.com)
      ===================================================================== */}
      <section className="bg-[#111827] border border-slate-800 rounded-xl p-6 lg:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left Column: Hero Proposition & Primary Action */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-xs font-mono text-cyan-400">
                <span>borsignature.com</span>
                <span aria-hidden="true">·</span>
                <span>Real-Time Market Intelligence</span>
              </div>

              <h2
                className="text-3xl sm:text-4xl lg:text-[42px] font-bold tracking-tight text-slate-100 leading-[1.12]"
                style={{ textWrap: 'balance' }}
              >
                Automate Market Data
              </h2>

              <p className="text-base font-medium text-cyan-300">
                Real-Time Market Intelligence
              </p>

              <p className="text-sm text-slate-400 leading-relaxed">
                Extraia livros de ofertas em tempo real, execute análises
                quantitativas de mercado, integre via CLI e orquestre fluxos
                automatizados diretamente conectados à API do{' '}
                <span className="text-slate-200 font-mono">
                  borsignature.com
                </span>
                .
              </p>

              {/* Unboxed Metadata Discipline: Recursos list */}
              <div className="pt-2">
                <div className="text-xs text-slate-500 mb-1.5">
                  Recursos Interativos do Vídeo:
                </div>
                <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-slate-300">
                  <span>Data Extraction</span>
                  <span aria-hidden="true" className="text-slate-600">
                    ·
                  </span>
                  <span>Market Analysis</span>
                  <span aria-hidden="true" className="text-slate-600">
                    ·
                  </span>
                  <span>CLI Integration</span>
                  <span aria-hidden="true" className="text-slate-600">
                    ·
                  </span>
                  <span>Automated Workflow</span>
                </div>
              </div>
            </div>

            {/* Hero Primary CTA ("Start Free") + Real-Time Data API Quick Trigger */}
            <div className="space-y-4 pt-4 border-t border-slate-800">
              <div className="flex flex-wrap items-center gap-3">
                <button
                  onClick={handleStartFreeApi}
                  disabled={startFreeLoading}
                  className="px-6 py-3 rounded-lg text-sm font-semibold bg-cyan-400 hover:bg-cyan-300 text-slate-950 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {startFreeLoading ? 'Provisioning API...' : 'Start Free'}
                </button>

                <button
                  onClick={handleTriggerRealtimeApi}
                  disabled={realtimeLoading}
                  className="px-4 py-3 rounded-lg text-xs font-mono font-medium bg-[#0B0E17] hover:bg-slate-900 text-slate-200 border border-slate-800 flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Radio className="w-3.5 h-3.5 text-cyan-400" />
                  {realtimeLoading
                    ? 'Sincronizando...'
                    : 'Real-Time Data API'}
                </button>
              </div>

              {startFreeResponse && (
                <div className="bg-[#0B0E17] border border-cyan-500/40 rounded-lg p-3.5 space-y-1.5 text-xs font-mono">
                  <div className="flex items-center justify-between text-emerald-400">
                    <span>● Start Free API Key Gerada</span>
                    <span>{startFreeResponse.accountEmail}</span>
                  </div>
                  <div className="text-slate-200 truncate">
                    Key: {startFreeResponse.provisionedApiKey}
                  </div>
                  <div className="text-slate-400 truncate">
                    $ {startFreeResponse.cliInitCommand}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Interactive Video Player Canvas (16:9 Stage) */}
          <div className="lg:col-span-7 flex flex-col justify-between bg-[#0B0E17] border border-slate-800 rounded-xl overflow-hidden">
            {/* Video Top HUD Bar */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-800 bg-[#0F1420]">
              <div className="flex items-center gap-2 text-xs font-mono">
                <span className="text-cyan-400 font-semibold">
                  {currentChapter.indexLabel}. {currentChapter.title}
                </span>
                <span className="text-slate-600">·</span>
                <span className="text-slate-400">
                  borsignature.com Interactive Video
                </span>
              </div>

              <div className="flex items-center gap-2">
                {[1, 1.5, 2].map((spd) => (
                  <button
                    key={spd}
                    onClick={() => setPlaybackSpeed(spd)}
                    className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors ${
                      playbackSpeed === spd
                        ? 'bg-cyan-500 text-slate-950 font-semibold'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {spd}x
                  </button>
                ))}
              </div>
            </div>

            {/* Interactive Video Main Stage */}
            <div className="p-6 flex-1 flex flex-col justify-between space-y-5 relative">
              {/* Chapter Header & Live Interactive Hotspots */}
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="space-y-1 max-w-xl">
                  <div className="text-xs font-mono text-slate-400">
                    CAPÍTULO INTERATIVO {currentChapter.indexLabel} / 04
                  </div>
                  <h3 className="text-xl font-bold text-slate-100">
                    {currentChapter.title} — {currentChapter.subtitle}
                  </h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {currentChapter.description}
                  </p>
                </div>

                <button
                  onClick={handleTriggerRealtimeApi}
                  className="px-3 py-1.5 rounded-lg bg-cyan-950/50 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-900/50 text-xs font-mono flex items-center gap-1.5 shrink-0 transition-colors"
                >
                  <Activity className="w-3.5 h-3.5" />
                  Testar {currentChapter.title} na API
                </button>
              </div>

              {/* Animated SVG Telemetry Stream + Interactive CLI Overlay inside Video */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
                {/* Live SVG Market Waveform */}
                <div className="md:col-span-6 bg-[#111827] border border-slate-800 rounded-lg p-3.5 space-y-2">
                  <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                    <span>STREAM: {currentChapter.title.toUpperCase()}</span>
                    <span className="text-emerald-400">● LIVE 60FPS</span>
                  </div>
                  <svg
                    viewBox="0 0 320 96"
                    className="w-full h-24 overflow-visible"
                    aria-label="Gráfico interativo de telemetria de mercado"
                  >
                    <defs>
                      <linearGradient
                        id="borsigGrad"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="0%"
                          stopColor="#06B6D4"
                          stopOpacity="0.35"
                        />
                        <stop
                          offset="100%"
                          stopColor="#06B6D4"
                          stopOpacity="0.0"
                        />
                      </linearGradient>
                    </defs>
                    {/* Grid lines */}
                    <line
                      x1="0"
                      y1="24"
                      x2="320"
                      y2="24"
                      stroke="#1E293B"
                      strokeDasharray="3 3"
                    />
                    <line
                      x1="0"
                      y1="48"
                      x2="320"
                      y2="48"
                      stroke="#1E293B"
                      strokeDasharray="3 3"
                    />
                    <line
                      x1="0"
                      y1="72"
                      x2="320"
                      y2="72"
                      stroke="#1E293B"
                      strokeDasharray="3 3"
                    />
                    {(() => {
                      const pts: string[] = [];
                      for (let x = 0; x <= 320; x += 16) {
                        const phase =
                          waveTick * 0.35 +
                          x * 0.045 +
                          activeChapterIdx * 1.4;
                        const y =
                          48 +
                          Math.sin(phase) * 22 +
                          Math.cos(phase * 0.6) * 10;
                        pts.push(`${x},${y.toFixed(1)}`);
                      }
                      const polylineStr = pts.join(' ');
                      const areaStr = `0,96 ${polylineStr} 320,96`;
                      return (
                        <>
                          <polygon points={areaStr} fill="url(#borsigGrad)" />
                          <polyline
                            fill="none"
                            stroke="#22D3EE"
                            strokeWidth="2"
                            points={polylineStr}
                          />
                        </>
                      );
                    })()}
                  </svg>
                </div>

                {/* Live CLI Terminal Frame synchronized to Video Chapter */}
                <div className="md:col-span-6 bg-[#111827] border border-slate-800 rounded-lg p-3.5 font-mono text-xs space-y-2">
                  <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800 pb-1.5">
                    <span>borsignature-cli — bash</span>
                    <span className="text-cyan-400">v2.4.0</span>
                  </div>
                  <pre className="text-[11px] text-slate-200 overflow-x-auto leading-relaxed">
                    <code>{currentChapter.cliSnippet}</code>
                  </pre>
                </div>
              </div>

              {/* 3 Chapter KPI Readouts inside Video Stage */}
              <div className="grid grid-cols-3 gap-3 pt-2">
                {currentChapter.metrics.map((m) => (
                  <div
                    key={m.label}
                    className="bg-[#111827] border border-slate-800 rounded-lg p-3"
                  >
                    <div className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                      {m.label}
                    </div>
                    <div className="mt-1 flex items-baseline gap-1.5">
                      <span className="text-lg font-mono font-bold text-slate-100 tabular-nums">
                        {m.value}
                      </span>
                      <span className="text-[11px] font-mono text-cyan-400">
                        {m.delta}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Interactive Video Scrubbing & Chapter Controls Bar */}
            <div className="bg-[#0F1420] border-t border-slate-800 p-4 space-y-3">
              {/* Scrubber Progress Bar */}
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-cyan-400 transition-all duration-150"
                  style={{ width: `${overallProgressPercent}%` }}
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsPlaying((p) => !p)}
                    className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {isPlaying ? (
                      <>
                        <Pause className="w-3.5 h-3.5 fill-current" />
                        Pausar Vídeo
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5 fill-current" />
                        Reproduzir Vídeo
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => {
                      setActiveChapterIdx(0);
                      setChapterProgress(0);
                      setIsPlaying(true);
                    }}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
                    title="Reiniciar Vídeo Interativo"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Direct Chapter Jump Buttons */}
                <div className="flex flex-wrap items-center gap-1.5">
                  {CHAPTERS.map((chap, idx) => {
                    const active = idx === activeChapterIdx;
                    return (
                      <button
                        key={chap.id}
                        onClick={() => {
                          setActiveChapterIdx(idx);
                          setChapterProgress(0);
                        }}
                        className={`px-2.5 py-1 rounded text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                          active
                            ? 'bg-slate-800 text-cyan-400 border border-cyan-500/40'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {chap.indexLabel}. {chap.title}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================================
          RECURSOS SECTION: Data Extraction · Market Analysis · CLI Integration · Automated Workflow
      ===================================================================== */}
      <section className="space-y-4">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h3 className="text-xl font-bold text-slate-100">
              Recursos da Plataforma borsignature.com
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Clique em qualquer módulo para saltar imediatamente no vídeo
              interativo e sincronizar o endpoint da API
            </p>
          </div>
          <div className="text-xs font-mono text-slate-400">
            Data Extraction · Market Analysis · CLI Integration · Automated
            Workflow
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {CHAPTERS.map((chap, idx) => {
            const isCurrent = idx === activeChapterIdx;
            return (
              <div
                key={chap.id}
                onClick={() => {
                  setActiveChapterIdx(idx);
                  setChapterProgress(0);
                }}
                className={`p-5 rounded-xl border transition-colors cursor-pointer flex flex-col justify-between ${
                  isCurrent
                    ? 'bg-[#111827] border-cyan-500/70'
                    : 'bg-[#111827]/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-cyan-400 font-semibold">
                      {chap.indexLabel}. {chap.title}
                    </span>
                    <span className="text-slate-500">{chap.durationSec}s</span>
                  </div>
                  <p className="text-xs font-medium text-slate-200">
                    {chap.subtitle}
                  </p>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {chap.description}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-400">
                    {chap.metrics[0].value} {chap.metrics[0].delta}
                  </span>
                  <span className="text-cyan-400 flex items-center gap-1">
                    {isCurrent ? '● Em reprodução' : 'Carregar cena'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Interactive Real-Time Scraping & Data Analysis Dashboard anchored at the Data Analysis position */}
        <div className="pt-2">
          <DataAnalysisScrapingDashboard
            onSendSignalToTensorBot={onSendScrapingSignalToBot}
            onApiLogUpdate={(log) => setLastApiCallLog(log)}
          />
        </div>
      </section>

      {/* =====================================================================
          3 API-CONNECTED MODULES:
          1. Real-Time Data (button -> API)
          2. Support Lista de Links (button -> API)
          3. Newsletter botsigature@botsignature.com + Subscribe (button -> API)
      ===================================================================== */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* 1. REAL-TIME DATA PANEL + API BUTTON */}
        <div className="lg:col-span-4 bg-[#111827] border border-slate-800 rounded-xl p-6 flex flex-col justify-between space-y-5">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-semibold text-slate-100">
                  Real-Time Data
                </h3>
                <p className="text-xs text-slate-400">
                  Endpoint: <code className="text-cyan-400">/api/borsignature/realtime-data</code>
                </p>
              </div>
              <Radio className="w-4 h-4 text-cyan-400 shrink-0" />
            </div>

            <div className="bg-[#0B0E17] border border-slate-800 rounded-lg divide-y divide-slate-800/80">
              {realtimeResponse?.feed ? (
                realtimeResponse.feed.map((item) => (
                  <div
                    key={item.pair}
                    className="p-3 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-mono font-semibold text-slate-100">
                        {item.pair}
                      </div>
                      <div className="text-[11px] font-mono text-cyan-400">
                        {item.signal}
                      </div>
                    </div>
                    <div className="text-right font-mono tabular-nums">
                      <div className="font-bold text-emerald-400">
                        ${item.price.toLocaleString()}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        Spread: {item.spreadBps} bps
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-4 text-xs text-slate-400">
                  Clique no botão abaixo para requisitar dados em tempo real da
                  API.
                </div>
              )}
            </div>
          </div>

          <div className="space-y-2 pt-3 border-t border-slate-800">
            <button
              onClick={handleTriggerRealtimeApi}
              disabled={realtimeLoading}
              className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Radio className="w-3.5 h-3.5" />
              {realtimeLoading
                ? 'Requisitando API Real-Time...'
                : 'Fetch Real-Time Data via API'}
            </button>
            {realtimeResponse && (
              <div className="text-[11px] font-mono text-slate-400 truncate">
                Última sincronização: {realtimeResponse.timestamp}
              </div>
            )}
          </div>
        </div>

        {/* 2. SUPPORT (LISTA DE LINKS) + API BUTTON */}
        <div className="lg:col-span-4 bg-[#111827] border border-slate-800 rounded-xl p-6 flex flex-col justify-between space-y-5">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-semibold text-slate-100">
                  Support & Developer Links
                </h3>
                <p className="text-xs text-slate-400">
                  Endpoint: <code className="text-cyan-400">/api/borsignature/support</code>
                </p>
              </div>
              <LifeBuoy className="w-4 h-4 text-cyan-400 shrink-0" />
            </div>

            {/* Support Links List */}
            <ul className="space-y-2">
              {SUPPORT_LINKS.map((link) => {
                const isSelected = selectedSupportSlug === link.slug;
                return (
                  <li key={link.slug}>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedSupportSlug(link.slug);
                        handleTriggerSupportApi(link.endpointParam, link.slug);
                      }}
                      className={`w-full text-left p-2.5 rounded-lg border transition-colors flex items-start justify-between gap-2 cursor-pointer ${
                        isSelected
                          ? 'bg-[#0B0E17] border-cyan-500/60 text-slate-100'
                          : 'bg-[#0B0E17]/60 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div>
                        <div className="text-xs font-medium text-cyan-400 hover:underline">
                          {link.title}
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5">
                          {link.description}
                        </div>
                      </div>
                      <ArrowUpRight className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>

          <div className="space-y-2 pt-3 border-t border-slate-800">
            <button
              onClick={() => handleTriggerSupportApi()}
              disabled={supportLoading}
              className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <LifeBuoy className="w-3.5 h-3.5 text-cyan-400" />
              {supportLoading
                ? 'Conectando Support API...'
                : 'Connect Support API'}
            </button>
            {supportResponse && (
              <div className="text-[11px] font-mono text-emerald-400 truncate">
                ● Ticket {supportResponse.ticketId}:{' '}
                {supportResponse.requestedTopic}
              </div>
            )}
          </div>
        </div>

        {/* 3. NEWSLETTER (botsigature@botsignature.com + Subscribe) + API BUTTON */}
        <div className="lg:col-span-4 bg-[#111827] border border-slate-800 rounded-xl p-6 flex flex-col justify-between space-y-5">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-semibold text-slate-100">
                  Newsletter & Intelligence Dispatch
                </h3>
                <p className="text-xs text-slate-400">
                  Endpoint: <code className="text-cyan-400">/api/borsignature/newsletter</code>
                </p>
              </div>
              <Mail className="w-4 h-4 text-cyan-400 shrink-0" />
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Receba alertas automatizados de anomalias de liquidez, relatórios
              de arbitragem QAOA e atualizações da CLI do{' '}
              <span className="text-slate-200 font-mono">
                borsignature.com
              </span>{' '}
              diretamente via API.
            </p>

            <form
              onSubmit={handleSubscribeNewsletterApi}
              className="space-y-3"
            >
              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  E-mail Oficial Cadastrado para Dispatch
                </label>
                <input
                  type="email"
                  required
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder="botsigature@botsignature.com"
                  className="w-full bg-[#0B0E17] border border-slate-800 rounded-lg px-3 py-2.5 text-xs font-mono text-slate-100 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono">
                <span>Contato padrão:</span>
                <button
                  type="button"
                  onClick={() =>
                    setNewsletterEmail('botsigature@botsignature.com')
                  }
                  className="text-cyan-400 hover:underline"
                >
                  botsigature@botsignature.com
                </button>
              </div>

              <button
                type="submit"
                disabled={newsletterLoading}
                className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                {newsletterLoading ? 'Subscribing via API...' : 'Subscribe'}
              </button>
            </form>
          </div>

          <div className="pt-3 border-t border-slate-800">
            {newsletterResponse ? (
              <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-800/50 text-xs space-y-1">
                <div className="font-mono font-semibold text-emerald-400">
                  ● API 200 OK — {newsletterResponse.confirmationCode}
                </div>
                <div className="text-slate-300 text-[11px]">
                  {newsletterResponse.message}
                </div>
              </div>
            ) : (
              <div className="text-[11px] font-mono text-slate-400">
                Pronto para disparo POST em{' '}
                <span className="text-slate-200">
                  /api/borsignature/newsletter
                </span>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Live API Response Inspector Console */}
      <section className="bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs font-mono">
            <Code2 className="w-4 h-4 text-cyan-400" />
            <span className="text-slate-200 font-semibold">
              borsignature.com Live API Response Console
            </span>
            <span className="text-slate-500">·</span>
            <span className="text-cyan-400">{lastApiCallLog.endpoint}</span>
          </div>
          <div className="text-xs font-mono text-emerald-400">
            HTTP {lastApiCallLog.status} · {lastApiCallLog.timestamp}
          </div>
        </div>
        <pre className="bg-[#0B0E17] border border-slate-800 rounded-lg p-3.5 text-xs font-mono text-slate-300 overflow-x-auto max-h-48">
          <code>{lastApiCallLog.payloadPreview}</code>
        </pre>
      </section>
    </div>
  );
};
