import React, { useState, useEffect, useMemo } from 'react';
import {
  Cpu,
  Play,
  Square,
  Sliders,
  KeyRound,
  Plus,
  Check,
  Copy,
  RefreshCw,
  ArrowUpRight,
  ShieldAlert,
  ShieldCheck,
  Terminal,
  Layers,
  Zap,
  TrendingUp,
  Activity,
} from 'lucide-react';
import {
  ArbitragePool,
  PortfolioAsset,
  RegisteredExchangeAPI,
  TensorOrder,
  TokenAuditData,
} from './types/quantum';
import {
  DEFAULT_ARBITRAGE_POOLS,
  INITIAL_PORTFOLIO_ASSETS,
  INITIAL_REGISTERED_APIS,
  DEFAULT_AUDIT_TOKENS,
  solveQAOAArbitrage,
  optimizePortfolioVQE,
  computeQuantumBlackScholes,
  validateTokenWithQML,
  normCDF,
} from './utils/quantumMath';
import { TensorBotMicroModal } from './components/TensorBotMicroModal';
import { BorsignatureInteractiveStudio } from './components/BorsignatureInteractiveStudio';
import { DataAnalysisScrapingDashboard } from './components/DataAnalysisScrapingDashboard';

export default function App() {
  // Navigation & MicroModal state
  const [activeSection, setActiveSection] = useState<
    | 'borsignature'
    | 'dataanalysis'
    | 'arbitrage'
    | 'portfolio'
    | 'blackscholes'
    | 'validator'
    | 'apis'
    | 'python'
  >('borsignature');
  const [isTensorModalOpen, setIsTensorModalOpen] = useState<boolean>(false);

  // Registered Trading APIs State (cadastradas no focuscrawl.si)
  const [registeredApis, setRegisteredApis] = useState<RegisteredExchangeAPI[]>(
    INITIAL_REGISTERED_APIS
  );
  const [selectedApiId, setSelectedApiId] = useState<string>(
    INITIAL_REGISTERED_APIS[0].id
  );
  const [newApiName, setNewApiName] = useState<string>('');
  const [newApiExchange, setNewApiExchange] = useState<string>(
    'Uniswap V3 + Arbitrum RPC'
  );
  const [newApiEndpoint, setNewApiEndpoint] = useState<string>(
    'https://arb1.arbitrum.io/rpc'
  );
  const [newApiKeyInput, setNewApiKeyInput] = useState<string>('');
  const [newApiLimit, setNewApiLimit] = useState<number>(250000);
  const [apiPingFeedback, setApiPingFeedback] = useState<string | null>(null);

  // Trading Bot Autonomous Engine State
  const [botRunning, setBotRunning] = useState<boolean>(true);
  const [orders, setOrders] = useState<TensorOrder[]>([
    {
      id: 'ord-901',
      timestamp: '09:14:22 UTC',
      strategy: 'QAOA Arbitragem',
      pair: 'USDC → WETH → DAI → USDC',
      exchangeApiName: 'Uniswap V3 + Arbitrum RPC Router',
      side: 'ARBITRAGEM',
      capitalUsd: 5000,
      entryPrice: 1.0042,
      expectedReturnPct: 1.24,
      pnlUsd: 62.15,
      tensorShape: '[4, 3, 4]',
      quantumConfidence: 0.94,
      status: 'Liquidada',
    },
    {
      id: 'ord-900',
      timestamp: '09:11:05 UTC',
      strategy: 'VQE Rebalance',
      pair: 'SOL/USDC (Accumulate)',
      exchangeApiName: 'Binance Institutional Prime API',
      side: 'COMPRA',
      capitalUsd: 3200,
      entryPrice: 214.2,
      expectedReturnPct: 0.86,
      pnlUsd: 27.52,
      tensorShape: '[5, 2, 4]',
      quantumConfidence: 0.91,
      status: 'Executada',
    },
    {
      id: 'ord-899',
      timestamp: '09:06:48 UTC',
      strategy: 'Black-Scholes Hedge',
      pair: 'ETH Call K=$3200 Delta Hedge',
      exchangeApiName: 'Binance Institutional Prime API',
      side: 'VENDA',
      capitalUsd: 2500,
      entryPrice: 3185.0,
      expectedReturnPct: 0.64,
      pnlUsd: 16.0,
      tensorShape: '[4, 4, 4]',
      quantumConfidence: 0.89,
      status: 'Protegida',
    },
  ]);

  // 1. QAOA Arbitrage State
  const [pools, setPools] = useState<ArbitragePool[]>(DEFAULT_ARBITRAGE_POOLS);
  const [arbCapital, setArbCapital] = useState<number>(5000);
  const [qaoaReps, setQaoaReps] = useState<number>(2);
  const [gasGwei, setGasGwei] = useState<number>(24);

  const arbitrageResult = useMemo(
    () => solveQAOAArbitrage(pools, arbCapital, qaoaReps, gasGwei),
    [pools, arbCapital, qaoaReps, gasGwei]
  );

  // 2. VQE Portfolio State
  const [portfolioAssets, setPortfolioAssets] = useState<PortfolioAsset[]>(
    INITIAL_PORTFOLIO_ASSETS
  );
  const [riskLambda, setRiskLambda] = useState<number>(0.32);
  const [budgetCount, setBudgetCount] = useState<number>(3);
  const [maxAssetAlloc, setMaxAssetAlloc] = useState<number>(0.42);

  const vqePortfolioResult = useMemo(
    () =>
      optimizePortfolioVQE(
        portfolioAssets,
        riskLambda,
        budgetCount,
        0.05,
        maxAssetAlloc
      ),
    [portfolioAssets, riskLambda, budgetCount, maxAssetAlloc]
  );

  // 3. Black-Scholes Quantum State
  const [bsSpot, setBsSpot] = useState<number>(100);
  const [bsStrike, setBsStrike] = useState<number>(105);
  const [bsTime, setBsTime] = useState<number>(0.25);
  const [bsRate, setBsRate] = useState<number>(0.05);
  const [bsSigma, setBsSigma] = useState<number>(0.22);
  const [bsQubits, setBsQubits] = useState<number>(4);

  const bsResult = useMemo(
    () =>
      computeQuantumBlackScholes(
        bsSpot,
        bsStrike,
        bsTime,
        bsRate,
        bsSigma,
        bsQubits
      ),
    [bsSpot, bsStrike, bsTime, bsRate, bsSigma, bsQubits]
  );

  // 4. QML Token Validator State
  const [auditTokens, setAuditTokens] =
    useState<TokenAuditData[]>(DEFAULT_AUDIT_TOKENS);
  const [customTokenSymbol, setCustomTokenSymbol] = useState<string>('NEXUSQ');
  const [customConcentration, setCustomConcentration] = useState<number>(0.22);
  const [customTxCount, setCustomTxCount] = useState<number>(6400);
  const [customPriceChange, setCustomPriceChange] = useState<number>(12.5);
  const [customAgeDays, setCustomAgeDays] = useState<number>(64);

  const auditedTokens = useMemo(
    () => auditTokens.map((t) => validateTokenWithQML(t)),
    [auditTokens]
  );

  // Python Script Explorer state
  const [activePythonFile, setActivePythonFile] = useState<
    'arbitrage.py' | 'portfolio.py' | 'black_scholes.py' | 'validator.py'
  >('arbitrage.py');
  const [copiedScript, setCopiedScript] = useState<boolean>(false);

  // Execute a Tensor Bot cycle
  const executeSingleCycle = (config: {
    strategy: TensorOrder['strategy'];
    pair: string;
    capitalUsd: number;
    tensorRanks: [number, number, number];
    learningRate: number;
  }) => {
    const activeApi =
      registeredApis.find((a) => a.id === selectedApiId) || registeredApis[0];
    const returnPct =
      config.strategy === 'QAOA Arbitragem'
        ? Math.max(0.42, arbitrageResult.profitPercent)
        : config.strategy === 'VQE Rebalance'
        ? 0.65 + config.learningRate * 12
        : 0.54 + (config.tensorRanks[0] * 0.08);
    const pnlUsd = (config.capitalUsd * returnPct) / 100;

    const now = new Date();
    const timeStr = `${String(now.getUTCHours()).padStart(2, '0')}:${String(
      now.getUTCMinutes()
    ).padStart(2, '0')}:${String(now.getUTCSeconds()).padStart(2, '0')} UTC`;

    const newOrder: TensorOrder = {
      id: `ord-${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: timeStr,
      strategy: config.strategy,
      pair: config.pair,
      exchangeApiName: activeApi.name,
      side:
        config.strategy === 'QAOA Arbitragem'
          ? 'ARBITRAGEM'
          : config.strategy === 'Black-Scholes Hedge'
          ? 'VENDA'
          : 'COMPRA',
      capitalUsd: config.capitalUsd,
      entryPrice: bsSpot,
      expectedReturnPct: returnPct,
      pnlUsd,
      tensorShape: `[${config.tensorRanks.join(', ')}]`,
      quantumConfidence: 0.91,
      status: 'Liquidada',
    };

    setOrders((prev) => [newOrder, ...prev.slice(0, 19)]);
    setRegisteredApis((prev) =>
      prev.map((api) =>
        api.id === activeApi.id
          ? { ...api, usedVolumeUsd: api.usedVolumeUsd + config.capitalUsd }
          : api
      )
    );
  };

  // Autonomous bot interval when active
  useEffect(() => {
    if (!botRunning) return;
    const timer = setInterval(() => {
      // Slightly fluctuate DEX rates & execute profitable cycles
      setPools((prev) =>
        prev.map((p, idx) => {
          const delta = (Math.sin(Date.now() * 0.001 + idx) * 0.0008);
          return {
            ...p,
            rate: Number(Math.max(0.996, p.rate + delta).toFixed(4)),
          };
        })
      );
    }, 5000);
    return () => clearInterval(timer);
  }, [botRunning]);

  // Register a new Exchange / RPC API
  const handleRegisterNewApi = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newApiName.trim()) return;
    const rawKey = newApiKeyInput.trim() || 'fc_quant_88a190bc73e9';
    const masked =
      rawKey.length > 8
        ? `${rawKey.slice(0, 6)}...${rawKey.slice(-4)}`
        : `${rawKey}...9f2a`;

    const created: RegisteredExchangeAPI = {
      id: `api-${Date.now()}`,
      name: newApiName.trim(),
      exchange: newApiExchange,
      network: 'Mainnet + Quantum Bridge',
      endpointUrl: newApiEndpoint.trim() || 'https://arb1.arbitrum.io/rpc',
      apiKeyMasked: masked,
      status: 'Nominal',
      permissions: ['Spot Execution', 'QAOA Flash Route', 'Tensor Bot Signer'],
      latencyMs: Math.floor(8 + Math.random() * 18),
      dailyVolumeLimitUsd: newApiLimit,
      usedVolumeUsd: 0,
      registeredAt: 'Agora mesmo',
    };

    setRegisteredApis((prev) => [created, ...prev]);
    setSelectedApiId(created.id);
    setNewApiName('');
    setNewApiKeyInput('');
    setApiPingFeedback(`API "${created.name}" cadastrada e autenticada com sucesso.`);
  };

  // Add custom token to QML audit list
  const handleAuditCustomToken = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTokenSymbol.trim()) return;
    const newToken: TokenAuditData = {
      symbol: customTokenSymbol.trim().toUpperCase(),
      name: `${customTokenSymbol.trim().toUpperCase()} Protocol`,
      contractAddress: `0x${Math.floor(100 + Math.random() * 899)}...${Math.floor(
        1000 + Math.random() * 8999
      )}`,
      network: 'Arbitrum / Ethereum',
      holderCount: Math.round(5000 * (1 - customConcentration) + 120),
      holderConcentration: customConcentration,
      transactionCount24h: customTxCount,
      uniqueFrom24h: Math.max(40, Math.round(customTxCount * 0.12)),
      priceChange24h: customPriceChange,
      volumeChange24h: Math.abs(customPriceChange * 3.2),
      ageDays: customAgeDays,
      burnedPercent: 0.05,
    };
    setAuditTokens((prev) => [newToken, ...prev]);
  };

  const totalPnlUsd = orders.reduce((acc, o) => acc + o.pnlUsd, 0);
  const activeApiObj =
    registeredApis.find((a) => a.id === selectedApiId) || registeredApis[0];

  const pythonSnippets: Record<typeof activePythonFile, string> = {
    'arbitrage.py': `# focuscrawl.si — QuantumArbitrageEngine (QAOA + Uniswap V3 / SushiSwap / Curve)
import numpy as np
from qiskit.algorithms import QAOA
from qiskit.algorithms.optimizers import COBYLA
from qiskit.primitives import Sampler
from qiskit.quantum_info import SparsePauliOp

class QuantumArbitrageEngine:
    def __init__(self, dex_pools: dict):
        self.dex_pools = dex_pools
        self.num_pools = len(dex_pools)
        self.pool_names = list(dex_pools.keys())

    def create_hamiltonian(self, capital: float = ${arbCapital}) -> SparsePauliOp:
        coefficients = []
        for i, (pool_name, rate) in enumerate(self.dex_pools.items()):
            gain = np.log(max(rate, 0.001) + 1)
            z_str = (i * "I" + "Z" + (self.num_pools - i - 1) * "I")
            coefficients.append((z_str, gain))
        for i in range(self.num_pools - 1):
            zz_str = i * "I" + "ZZ" + (self.num_pools - i - 2) * "I"
            coefficients.append((zz_str, -0.5))
        return SparsePauliOp.from_list(coefficients)

    def find_arbitrage_route(self):
        H = self.create_hamiltonian()
        qaoa = QAOA(sampler=Sampler(), optimizer=COBYLA(maxiter=80), reps=${qaoaReps})
        result = qaoa.compute_minimum_eigenvalue(H)
        return result.eigenvalue.real`,
    'portfolio.py': `# focuscrawl.si — VQE Portfolio Optimization (TwoLocal RY/CZ Ansatz)
import numpy as np
from qiskit.algorithms import VQE
from qiskit.algorithms.optimizers import COBYLA
from qiskit.circuit.library import TwoLocal
from qiskit.primitives import Estimator

assets = ${JSON.stringify(portfolioAssets.map((a) => a.symbol))}
returns = np.array(${JSON.stringify(portfolioAssets.map((a) => a.expectedReturn))})
budget = ${budgetCount}
risk_lambda = ${riskLambda}

ansatz = TwoLocal(len(assets), 'ry', 'cz', entanglement='linear', reps=2)
optimizer = COBYLA(maxiter=120)
vqe = VQE(Estimator(), ansatz, optimizer)
# Sharpe Ratio calculado: ${vqePortfolioResult.sharpeRatio.toFixed(2)}`,
    'black_scholes.py': `# focuscrawl.si — Quantum Black-Scholes & VQE Option Pricing
import numpy as np
from scipy.stats import norm
from qiskit import QuantumCircuit

S, K, T, r, sigma = ${bsSpot}, ${bsStrike}, ${bsTime}, ${bsRate}, ${bsSigma}
d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
d2 = d1 - sigma * np.sqrt(T)
call_classic = S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)

qc = QuantumCircuit(${bsQubits}, name="FocusCrawl_BlackScholes")
qc.ry(d1 * 0.5, 0)
qc.ry(d2 * 0.5, 1)
qc.ry(np.arcsin(norm.cdf(d1)), 2)
for i in range(${bsQubits - 1}):
    qc.cx(i, i + 1)
qc.measure_all()
# Call Quântico Estimado: $${bsResult.callQuantumVqe.toFixed(2)}`,
    'validator.py': `# focuscrawl.si — PennyLane QML Token Validator & Anti-Scam Neural Guard
import pennylane as qml
import numpy as np

dev = qml.device('default.qubit', wires=4)

@qml.qnode(dev)
def quantum_validator_circuit(features, weights):
    for i in range(4):
        qml.RX(features[i], wires=i)
    for i in range(4):
        qml.RY(weights[i], wires=i)
    for i in range(3):
        qml.CNOT(wires=[i, i + 1])
    return qml.expval(qml.PauliZ(0))`,
  };

  return (
    <div className="min-h-screen bg-[#0B0E17] text-slate-100 flex flex-col">
      {/* Top Bar Contract: 3 zones separated by gap-8 */}
      <header className="flex items-center justify-between gap-8 px-6 py-4 border-b border-slate-800 bg-[#0B0E17]/95 sticky top-0 z-30">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setActiveSection('borsignature');
          }}
          className="text-lg font-bold tracking-tight text-slate-100 whitespace-nowrap shrink-0"
        >
          borsignature.com
        </a>

        {/* Zone 2: 5 clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-400">
          <button
            onClick={() => setActiveSection('borsignature')}
            className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 ${
              activeSection === 'borsignature'
                ? 'text-cyan-400 underline underline-offset-8'
                : ''
            }`}
          >
            Interactive Video
          </button>
          <button
            onClick={() => setActiveSection('dataanalysis')}
            className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 ${
              activeSection === 'dataanalysis'
                ? 'text-cyan-400 underline underline-offset-8'
                : ''
            }`}
          >
            Data Analysis
          </button>
          <button
            onClick={() => setActiveSection('arbitrage')}
            className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 ${
              activeSection === 'arbitrage'
                ? 'text-cyan-400 underline underline-offset-8'
                : ''
            }`}
          >
            Arbitragem QAOA
          </button>
          <button
            onClick={() => setActiveSection('portfolio')}
            className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 ${
              activeSection === 'portfolio'
                ? 'text-cyan-400 underline underline-offset-8'
                : ''
            }`}
          >
            Portfólio VQE
          </button>
          <button
            onClick={() => setActiveSection('apis')}
            className={`hover:text-slate-100 transition-colors whitespace-nowrap shrink-0 ${
              activeSection === 'apis'
                ? 'text-cyan-400 underline underline-offset-8'
                : ''
            }`}
          >
            APIs Cadastradas
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setIsTensorModalOpen(true)}
            className="px-4 py-2 text-xs font-semibold text-slate-950 bg-cyan-400 rounded-lg hover:bg-cyan-300 transition-colors whitespace-nowrap shrink-0"
          >
            Abrir Tensor Bot
          </button>
        </div>
      </header>

      {/* Main Content Container (1440px baseline) */}
      <main className="flex-1 max-w-[1440px] w-full mx-auto px-6 py-6 space-y-6">
        {/* Top Executive Summary Strip & Quick Workspace Controls */}
        <section className="bg-[#111827] border border-slate-800 rounded-xl p-6">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-slate-800">
            <div className="space-y-1.5 max-w-2xl">
              <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
                <span>FocusCrawl Quantum Finance</span>
                <span aria-hidden="true">·</span>
                <span>API Ativa: {activeApiObj.name}</span>
                <span aria-hidden="true">·</span>
                <span
                  className={
                    botRunning ? 'text-emerald-400' : 'text-amber-400'
                  }
                >
                  {botRunning ? '● Tensor Bot Online' : '▲ Tensor Bot Pausado'}
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-100">
                Infraestrutura Quântica de Trading & Tensor MicroModal
              </h1>
              <p className="text-sm text-slate-400 leading-relaxed">
                Otimização de rotas de arbitragem DEX via QAOA, alocação de
                portfólio com VQE (TwoLocal Ansatz), precificação de derivativos
                Black-Scholes e proteção anti-fraude PennyLane QML integrada às
                suas chaves de API cadastradas.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3 shrink-0">
              <button
                onClick={() => setIsTensorModalOpen(true)}
                className="px-4 py-2.5 rounded-lg text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
              >
                <Cpu className="w-4 h-4" />
                Configurar Tensor MicroModal
              </button>
              <button
                onClick={() =>
                  executeSingleCycle({
                    strategy: 'QAOA Arbitragem',
                    pair: arbitrageResult.routePools
                      .map((p) => p.pair.split(' ')[0])
                      .join(' → '),
                    capitalUsd: arbCapital,
                    tensorRanks: [4, qaoaReps, 4],
                    learningRate: 0.01,
                  })
                }
                className="px-4 py-2.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
              >
                <Zap className="w-4 h-4 text-cyan-400" />
                Executar Ciclo na API
              </button>
              <button
                onClick={() => setActiveSection('python')}
                className="px-4 py-2.5 rounded-lg text-xs font-medium bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
              >
                <Terminal className="w-4 h-4 text-slate-400" />
                Scripts Qiskit & PennyLane
              </button>
            </div>
          </div>

          {/* 4-Column Quantitative Telemetry Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pt-6">
            <div>
              <div className="text-xs text-slate-400">
                Lucro Líquido Acumulado (Tensor Bot)
              </div>
              <div className="mt-1 flex items-baseline gap-2">
                <span className="text-2xl font-mono font-bold tabular-nums text-emerald-400">
                  +${totalPnlUsd.toFixed(2)}
                </span>
                <span className="text-xs font-mono text-slate-400">USD</span>
              </div>
              <div className="mt-1 text-xs font-mono text-slate-500">
                {orders.length} ordens liquidadas via API
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-400">
                Melhor Rota QAOA (Spread Líquido)
              </div>
              <div className="mt-1 flex items-baseline gap-2">
                <span className="text-2xl font-mono font-bold tabular-nums text-cyan-400">
                  +{arbitrageResult.profitPercent.toFixed(2)}%
                </span>
                <span className="text-xs font-mono text-slate-400">
                  (+${arbitrageResult.netProfitUsd.toFixed(2)})
                </span>
              </div>
              <div className="mt-1 text-xs font-mono text-slate-500">
                Eigenvalue H: {arbitrageResult.quantumEigenvalue.toFixed(4)}
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-400">
                Portfólio VQE (Sharpe Ratio Otimizado)
              </div>
              <div className="mt-1 flex items-baseline gap-2">
                <span className="text-2xl font-mono font-bold tabular-nums text-slate-100">
                  {vqePortfolioResult.sharpeRatio.toFixed(2)}
                </span>
                <span className="text-xs font-mono text-emerald-400">
                  Retorno Esp. {(vqePortfolioResult.expectedAnnualReturn * 100).toFixed(1)}%
                </span>
              </div>
              <div className="mt-1 text-xs font-mono text-slate-500">
                Risco Anual: {(vqePortfolioResult.portfolioVolatility * 100).toFixed(1)}%
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-400">
                APIs de Trading Cadastradas
              </div>
              <div className="mt-1 flex items-baseline gap-2">
                <span className="text-2xl font-mono font-bold tabular-nums text-slate-100">
                  {registeredApis.length}
                </span>
                <span className="text-xs font-mono text-emerald-400">
                  ● Nominal ({activeApiObj.latencyMs}ms)
                </span>
              </div>
              <div className="mt-1 text-xs font-mono text-slate-500">
                Chave ativa: {activeApiObj.apiKeyMasked}
              </div>
            </div>
          </div>
        </section>

        {/* Interactive Module Switcher Bar (Mobile & Desktop quick tabs) */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-1 p-1 bg-[#111827] border border-slate-800 rounded-lg overflow-x-auto">
            {[
              { id: 'borsignature', label: '00. Vídeo Interativo borsignature.com' },
              { id: 'dataanalysis', label: '01. Data Analysis & Scraping Telemetry' },
              { id: 'arbitrage', label: '02. Arbitragem DEX (QAOA)' },
              { id: 'portfolio', label: '03. Portfólio Crypto (VQE)' },
              { id: 'blackscholes', label: '04. Black-Scholes Quântico' },
              { id: 'validator', label: '05. Validador Anti-Scam (QML)' },
              { id: 'apis', label: '06. APIs de Trading Cadastradas' },
              { id: 'python', label: '07. Código Fonte Quântico' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() =>
                  setActiveSection(tab.id as typeof activeSection)
                }
                className={`px-3.5 py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  activeSection === tab.id
                    ? 'bg-cyan-500 text-slate-950 font-semibold'
                    : 'text-slate-400 hover:text-slate-100'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span>API de Execução:</span>
            <select
              value={selectedApiId}
              onChange={(e) => setSelectedApiId(e.target.value)}
              className="bg-[#111827] border border-slate-800 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              {registeredApis.map((api) => (
                <option key={api.id} value={api.id}>
                  {api.name} ({api.apiKeyMasked})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* ===================================================================
            MODULE 0: BORSIGNATURE.COM INTERACTIVE VIDEO & API HUB
        =================================================================== */}
        {activeSection === 'borsignature' && (
          <BorsignatureInteractiveStudio
            onRegisterApiFromBorsignature={(apiKey, endpointUrl) => {
              const masked = `${apiKey.slice(0, 10)}...${apiKey.slice(-4)}`;
              const created: RegisteredExchangeAPI = {
                id: `api-borsig-${Date.now()}`,
                name: 'borsignature.com Real-Time Intelligence API',
                exchange: 'BorSignature Stream Gateway',
                network: 'WebSocket L2/L3 + CLI Pipe',
                endpointUrl,
                apiKeyMasked: masked,
                status: 'Nominal',
                permissions: [
                  'Data Extraction',
                  'Market Analysis',
                  'CLI Integration',
                  'Automated Workflow',
                ],
                latencyMs: 6,
                dailyVolumeLimitUsd: 1000000,
                usedVolumeUsd: 0,
                registeredAt: 'Provisionado via Start Free',
              };
              setRegisteredApis((prev) => [created, ...prev]);
              setSelectedApiId(created.id);
            }}
            onSendScrapingSignalToBot={({ sourceName, signal, sentiment }) => {
              executeSingleCycle({
                strategy: 'QML Momentum',
                pair: `${signal} (${sourceName.split(' ')[0]})`,
                capitalUsd: Math.round(2500 * (0.5 + sentiment)),
                tensorRanks: [4, 3, 4],
                learningRate: 0.012,
              });
            }}
          />
        )}

        {/* ===================================================================
            MODULE 0.5: DATA ANALYSIS & REAL-TIME SCRAPING TELEMETRY DASHBOARD
        =================================================================== */}
        {activeSection === 'dataanalysis' && (
          <DataAnalysisScrapingDashboard
            onSendSignalToTensorBot={({ sourceName, signal, sentiment }) => {
              executeSingleCycle({
                strategy: 'QML Momentum',
                pair: `${signal} (${sourceName.split(' ')[0]})`,
                capitalUsd: Math.round(2500 * (0.5 + sentiment)),
                tensorRanks: [4, 3, 4],
                learningRate: 0.012,
              });
            }}
          />
        )}

        {/* ===================================================================
            MODULE 1: QAOA DEX ARBITRAGE ENGINE
        =================================================================== */}
        {activeSection === 'arbitrage' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            {/* Left Parameter Column */}
            <div className="lg:col-span-4 bg-[#111827] border border-slate-800 rounded-xl p-6 flex flex-col justify-between space-y-6">
              <div className="space-y-5">
                <div>
                  <h2 className="text-lg font-semibold text-slate-100">
                    01. Quantum Arbitrage Engine (QAOA)
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Codifica taxas de pools DEX em um Hamiltoniano SparsePauliOp
                    para identificar ciclos de lucro máximo com penalidade de
                    gas.
                  </p>
                </div>

                <div className="space-y-4 pt-2 border-t border-slate-800">
                  <div>
                    <div className="flex justify-between text-xs mb-1.5">
                      <span className="text-slate-300">
                        Capital Inicial da Ordem (USD)
                      </span>
                      <span className="font-mono tabular-nums text-cyan-400 font-semibold">
                        ${arbCapital.toLocaleString()}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={500}
                      max={50000}
                      step={500}
                      value={arbCapital}
                      onChange={(e) => setArbCapital(Number(e.target.value))}
                      className="w-full accent-cyan-500 cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1.5">
                      <span className="text-slate-300">
                        Camadas QAOA (Circuit Reps p)
                      </span>
                      <span className="font-mono tabular-nums text-slate-200">
                        reps = {qaoaReps}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={5}
                      step={1}
                      value={qaoaReps}
                      onChange={(e) => setQaoaReps(Number(e.target.value))}
                      className="w-full accent-cyan-500 cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1.5">
                      <span className="text-slate-300">
                        Custo de Gas Estimado (Gwei)
                      </span>
                      <span className="font-mono tabular-nums text-slate-200">
                        {gasGwei} Gwei (${arbitrageResult.gasCostUsd.toFixed(2)})
                      </span>
                    </div>
                    <input
                      type="range"
                      min={5}
                      max={80}
                      step={1}
                      value={gasGwei}
                      onChange={(e) => setGasGwei(Number(e.target.value))}
                      className="w-full accent-cyan-500 cursor-pointer"
                    />
                  </div>
                </div>

                <div className="bg-[#0B0E17] border border-slate-800 rounded-lg p-4 space-y-2">
                  <div className="text-xs text-slate-400">
                    Hamiltoniano QUBO / Ising Ativo
                  </div>
                  <div className="font-mono text-xs text-cyan-300 break-all">
                    H = Σ log(rate_i)·Z_i - 0.5·Σ Z_i·Z_(i+1)
                  </div>
                  <div className="flex justify-between text-xs font-mono text-slate-400 pt-2 border-t border-slate-800/80">
                    <span>Eigenvalue Mínimo:</span>
                    <span className="text-slate-100 tabular-nums">
                      {arbitrageResult.quantumEigenvalue.toFixed(5)}
                    </span>
                  </div>
                  <div className="flex justify-between text-xs font-mono text-slate-400">
                    <span>Tempo Sampler QAOA:</span>
                    <span className="text-slate-100 tabular-nums">
                      {arbitrageResult.executionTimeMs} ms
                    </span>
                  </div>
                </div>
              </div>

              <div className="space-y-2.5 pt-4 border-t border-slate-800">
                <button
                  onClick={() =>
                    executeSingleCycle({
                      strategy: 'QAOA Arbitragem',
                      pair: arbitrageResult.routePools
                        .map((p) => p.pair.split(' ')[0])
                        .join(' → '),
                      capitalUsd: arbCapital,
                      tensorRanks: [6, qaoaReps, 4],
                      learningRate: 0.012,
                    })
                  }
                  className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 flex items-center justify-center gap-2 transition-colors"
                >
                  <Zap className="w-4 h-4" />
                  Executar Rota Ótima via {activeApiObj.exchange}
                </button>
                <button
                  onClick={() => setIsTensorModalOpen(true)}
                  className="w-full py-2 px-4 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                >
                  Inspecionar Pesos no Tensor MicroModal
                </button>
              </div>
            </div>

            {/* Right Main Viewport: DEX Pools Table & Route Topology */}
            <div className="lg:col-span-8 bg-[#111827] border border-slate-800 rounded-xl p-6 flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <h3 className="text-base font-semibold text-slate-100">
                      Topologia de Liquidez DEX & Seleção de Rota Quântica
                    </h3>
                    <p className="text-xs text-slate-400">
                      Pools monitorados em tempo real (Uniswap V3, SushiSwap,
                      Curve, 1inch, Balancer, QuickSwap)
                    </p>
                  </div>
                  <button
                    onClick={() =>
                      setPools((prev) =>
                        prev.map((p) => ({
                          ...p,
                          rate: Number(
                            (
                              1.001 +
                              Math.random() * 0.0075
                            ).toFixed(4)
                          ),
                        }))
                      )
                    }
                    className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center gap-1.5 transition-colors"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
                    Atualizar Oráculos DEX
                  </button>
                </div>

                {/* Selected Optimal Route Banner */}
                <div className="bg-[#0B0E17] border border-slate-800 rounded-lg p-4">
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div className="space-y-1">
                      <div className="text-xs text-slate-400">
                        Rota Ótima Selecionada pelo QAOA Sampler
                      </div>
                      <div className="flex flex-wrap items-center gap-2 text-sm font-mono font-semibold text-cyan-400">
                        {arbitrageResult.routePools.map((p, idx) => (
                          <React.Fragment key={p.id}>
                            <span>
                              {p.pair} ({p.dex.split(' ')[0]})
                            </span>
                            {idx < arbitrageResult.routePools.length - 1 && (
                              <span className="text-slate-500">→</span>
                            )}
                          </React.Fragment>
                        ))}
                      </div>
                    </div>

                    <div className="text-right font-mono tabular-nums">
                      <div className="text-xs text-slate-400">
                        Retorno Final Estimado
                      </div>
                      <div className="text-lg font-bold text-emerald-400">
                        ${arbitrageResult.finalCapital.toFixed(2)} (+
                        {arbitrageResult.profitPercent.toFixed(2)}%)
                      </div>
                    </div>
                  </div>
                </div>

                {/* High-Density DEX Pool Table */}
                <div className="overflow-x-auto border border-slate-800 rounded-lg">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-800 bg-[#0B0E17] text-[11px] font-mono text-slate-400">
                        <th className="py-2.5 px-4">Operador Pauli</th>
                        <th className="py-2.5 px-4">Par de Liquidez</th>
                        <th className="py-2.5 px-4">Protocolo DEX</th>
                        <th className="py-2.5 px-4 text-right">Taxa / Ratio</th>
                        <th className="py-2.5 px-4 text-right">Fee Pool</th>
                        <th className="py-2.5 px-4 text-right">TVL (USD)</th>
                        <th className="py-2.5 px-4 text-right">Estado QAOA</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/70 text-xs">
                      {pools.map((pool, idx) => {
                        const isSelected =
                          arbitrageResult.routeIndices.includes(idx);
                        return (
                          <tr
                            key={pool.id}
                            className={`transition-colors ${
                              isSelected
                                ? 'bg-cyan-950/20 hover:bg-cyan-950/30'
                                : 'hover:bg-slate-900/60'
                            }`}
                          >
                            <td className="py-2.5 px-4 font-mono text-cyan-400">
                              {pool.pauliTerm}
                            </td>
                            <td className="py-2.5 px-4 font-medium text-slate-100">
                              {pool.pair}
                            </td>
                            <td className="py-2.5 px-4 text-slate-400">
                              {pool.dex}
                            </td>
                            <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-200">
                              {pool.rate.toFixed(4)}
                            </td>
                            <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-400">
                              {pool.feePercent.toFixed(2)}%
                            </td>
                            <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-300">
                              ${(pool.liquidityUsd / 1e6).toFixed(1)}M
                            </td>
                            <td className="py-2.5 px-4 text-right font-mono">
                              {isSelected ? (
                                <span className="text-emerald-400 font-semibold">
                                  ● Ativo |1⟩
                                </span>
                              ) : (
                                <span className="text-slate-500">Inativo |0⟩</span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Live Order Execution Log Footer inside Module 1 */}
              <div className="pt-4 border-t border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-slate-300">
                    Livro de Execuções Recentes (Tensor Trading Bot)
                  </span>
                  <span className="text-xs font-mono text-slate-400">
                    API: {activeApiObj.endpointUrl}
                  </span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {orders.slice(0, 3).map((ord) => (
                    <div
                      key={ord.id}
                      className="bg-[#0B0E17] border border-slate-800 rounded-lg p-3 text-xs flex flex-col justify-between"
                    >
                      <div className="flex items-center justify-between text-slate-400 font-mono text-[11px]">
                        <span>{ord.id}</span>
                        <span>{ord.timestamp}</span>
                      </div>
                      <div className="my-1.5 font-medium text-slate-200 truncate">
                        {ord.pair}
                      </div>
                      <div className="flex items-center justify-between font-mono tabular-nums">
                        <span className="text-slate-400">
                          ${ord.capitalUsd.toLocaleString()}
                        </span>
                        <span className="text-emerald-400 font-semibold">
                          +${ord.pnlUsd.toFixed(2)} (+
                          {ord.expectedReturnPct.toFixed(2)}%)
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            MODULE 2: VQE PORTFOLIO OPTIMIZATION
        =================================================================== */}
        {activeSection === 'portfolio' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            <div className="lg:col-span-4 bg-[#111827] border border-slate-800 rounded-xl p-6 flex flex-col justify-between space-y-6">
              <div className="space-y-5">
                <div>
                  <h2 className="text-lg font-semibold text-slate-100">
                    02. Otimizador de Portfólio VQE
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Variational Quantum Eigensolver com circuito TwoLocal (RY +
                    CZ linear entanglement) e otimizador COBYLA para maximizar o
                    Índice de Sharpe.
                  </p>
                </div>

                <div className="space-y-4 pt-2 border-t border-slate-800">
                  <div>
                    <div className="flex justify-between text-xs mb-1.5">
                      <span className="text-slate-300">
                        Aversão ao Risco (λ Covariância)
                      </span>
                      <span className="font-mono tabular-nums text-cyan-400">
                        λ = {riskLambda.toFixed(2)}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0.05}
                      max={0.95}
                      step={0.05}
                      value={riskLambda}
                      onChange={(e) => setRiskLambda(Number(e.target.value))}
                      className="w-full accent-cyan-500 cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1.5">
                      <span className="text-slate-300">
                        Budget de Ativos Dominantes (QUBO)
                      </span>
                      <span className="font-mono tabular-nums text-slate-200">
                        {budgetCount} de {portfolioAssets.length} ativos
                      </span>
                    </div>
                    <input
                      type="range"
                      min={2}
                      max={5}
                      step={1}
                      value={budgetCount}
                      onChange={(e) => setBudgetCount(Number(e.target.value))}
                      className="w-full accent-cyan-500 cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1.5">
                      <span className="text-slate-300">
                        Alocação Máxima por Ativo
                      </span>
                      <span className="font-mono tabular-nums text-slate-200">
                        {(maxAssetAlloc * 100).toFixed(0)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0.25}
                      max={0.65}
                      step={0.05}
                      value={maxAssetAlloc}
                      onChange={(e) => setMaxAssetAlloc(Number(e.target.value))}
                      className="w-full accent-cyan-500 cursor-pointer"
                    />
                  </div>
                </div>

                <div className="bg-[#0B0E17] border border-slate-800 rounded-lg p-4 space-y-2 text-xs font-mono">
                  <div className="flex justify-between text-slate-400">
                    <span>VQE Eigenvalue:</span>
                    <span className="text-cyan-400 tabular-nums">
                      {vqePortfolioResult.vqeEigenvalue.toFixed(4)}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Retorno Anual Esperado:</span>
                    <span className="text-emerald-400 tabular-nums">
                      +{(vqePortfolioResult.expectedAnnualReturn * 100).toFixed(2)}%
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Volatilidade da Carteira:</span>
                    <span className="text-slate-200 tabular-nums">
                      {(vqePortfolioResult.portfolioVolatility * 100).toFixed(2)}%
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Sharpe Ratio Quântico:</span>
                    <span className="text-slate-100 font-bold tabular-nums">
                      {vqePortfolioResult.sharpeRatio.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={() =>
                  executeSingleCycle({
                    strategy: 'VQE Rebalance',
                    pair: 'Basket BTC/ETH/SOL/ARB',
                    capitalUsd: 10000,
                    tensorRanks: [5, 2, 4],
                    learningRate: 0.01,
                  })
                }
                className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 flex items-center justify-center gap-2 transition-colors"
              >
                <TrendingUp className="w-4 h-4" />
                Rebalancear Portfólio via API Cadastrada
              </button>
            </div>

            <div className="lg:col-span-8 bg-[#111827] border border-slate-800 rounded-xl p-6 space-y-6">
              <div>
                <h3 className="text-base font-semibold text-slate-100">
                  Pesos Ótimos de Alocação (VQE + QuadraticProgramToQubo)
                </h3>
                <p className="text-xs text-slate-400">
                  Distribuição calculada pelo ansatz TwoLocal(ry, cz) respeitando
                  covariância histórica entre os ativos
                </p>
              </div>

              <div className="overflow-x-auto border border-slate-800 rounded-lg">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 bg-[#0B0E17] text-[11px] font-mono text-slate-400">
                      <th className="py-2.5 px-4">Ativo</th>
                      <th className="py-2.5 px-4 text-right">Preço Spot</th>
                      <th className="py-2.5 px-4 text-right">24h (%)</th>
                      <th className="py-2.5 px-4 text-right">
                        Retorno Esperado (μ)
                      </th>
                      <th className="py-2.5 px-4 text-right">
                        Volatilidade (σ)
                      </th>
                      <th className="py-2.5 px-4 text-right">
                        Peso Quântico VQE
                      </th>
                      <th className="py-2.5 px-4">Barra de Alocação</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/70 text-xs">
                    {vqePortfolioResult.updatedAssets.map((asset) => {
                      const pct = asset.allocationWeight * 100;
                      return (
                        <tr
                          key={asset.symbol}
                          className="hover:bg-slate-900/60 transition-colors"
                        >
                          <td className="py-3 px-4">
                            <div className="font-semibold text-slate-100">
                              {asset.symbol}
                            </div>
                            <div className="text-[11px] text-slate-500">
                              {asset.name}
                            </div>
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-200">
                            ${asset.priceUsd.toLocaleString()}
                          </td>
                          <td
                            className={`py-3 px-4 text-right font-mono tabular-nums ${
                              asset.change24h >= 0
                                ? 'text-emerald-400'
                                : 'text-rose-400'
                            }`}
                          >
                            {asset.change24h >= 0 ? '+' : ''}
                            {asset.change24h.toFixed(2)}%
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-300">
                            {(asset.expectedReturn * 100).toFixed(1)}%
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-400">
                            {(asset.volatility * 100).toFixed(1)}%
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-cyan-400">
                            {pct.toFixed(1)}%
                          </td>
                          <td className="py-3 px-4 w-44">
                            <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                              <div
                                className="h-full bg-cyan-400 rounded-full"
                                style={{ width: `${Math.min(100, pct * 1.8)}%` }}
                              />
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Multi-Period Rebalance Preview */}
              <div className="bg-[#0B0E17] border border-slate-800 rounded-lg p-4 flex flex-wrap items-center justify-between gap-4 text-xs">
                <div>
                  <div className="font-medium text-slate-200">
                    Simulação Multi-Período (IBM + Vanguard Dynamic Rebalancing)
                  </div>
                  <div className="text-slate-400 mt-0.5">
                    Rebalanceamento trimestral (T=1..4) reduz drawdown estimado
                    em 28.4% comparado à carteira estática.
                  </div>
                </div>
                <div className="font-mono text-cyan-400">
                  Ansatz: TwoLocal(5 qubits, RY, CZ, reps=2)
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            MODULE 3: QUANTUM BLACK-SCHOLES OPTION PRICING
        =================================================================== */}
        {activeSection === 'blackscholes' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            <div className="lg:col-span-4 bg-[#111827] border border-slate-800 rounded-xl p-6 flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <div>
                  <h2 className="text-lg font-semibold text-slate-100">
                    03. Black-Scholes Quântico & VQE
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Precificação de opções europeias Call e Put comparando a
                    fórmula analítica clássica com o circuito quântico de
                    amplitude e VQE.
                  </p>
                </div>

                <div className="space-y-3 pt-2 border-t border-slate-800">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">
                        Spot Price S₀ ($)
                      </label>
                      <input
                        type="number"
                        min={10}
                        max={100000}
                        value={bsSpot}
                        onChange={(e) =>
                          setBsSpot(Math.max(1, Number(e.target.value)))
                        }
                        className="w-full bg-[#0B0E17] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono tabular-nums text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">
                        Strike Price K ($)
                      </label>
                      <input
                        type="number"
                        min={10}
                        max={100000}
                        value={bsStrike}
                        onChange={(e) =>
                          setBsStrike(Math.max(1, Number(e.target.value)))
                        }
                        className="w-full bg-[#0B0E17] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono tabular-nums text-slate-100"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-400">
                        Tempo até Vencimento T (Anos)
                      </span>
                      <span className="font-mono text-slate-200 tabular-nums">
                        {bsTime.toFixed(2)} anos
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0.05}
                      max={2.0}
                      step={0.05}
                      value={bsTime}
                      onChange={(e) => setBsTime(Number(e.target.value))}
                      className="w-full accent-cyan-500 cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-400">
                        Volatilidade Implicita (σ)
                      </span>
                      <span className="font-mono text-cyan-400 tabular-nums">
                        {(bsSigma * 100).toFixed(0)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0.05}
                      max={1.2}
                      step={0.02}
                      value={bsSigma}
                      onChange={(e) => setBsSigma(Number(e.target.value))}
                      className="w-full accent-cyan-500 cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-400">
                        Taxa Livre de Risco (r)
                      </span>
                      <span className="font-mono text-slate-200 tabular-nums">
                        {(bsRate * 100).toFixed(1)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0.01}
                      max={0.15}
                      step={0.005}
                      value={bsRate}
                      onChange={(e) => setBsRate(Number(e.target.value))}
                      className="w-full accent-cyan-500 cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              <button
                onClick={() =>
                  executeSingleCycle({
                    strategy: 'Black-Scholes Hedge',
                    pair: `Option K=$${bsStrike} (Δ=${bsResult.deltaCall.toFixed(
                      2
                    )})`,
                    capitalUsd: Math.round(bsSpot * 25),
                    tensorRanks: [bsQubits, 3, 4],
                    learningRate: 0.01,
                  })
                }
                className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 flex items-center justify-center gap-2 transition-colors"
              >
                <Activity className="w-4 h-4" />
                Executar Delta Hedge na API
              </button>
            </div>

            <div className="lg:col-span-8 bg-[#111827] border border-slate-800 rounded-xl p-6 space-y-6">
              {/* Comparison Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-[#0B0E17] border border-slate-800 rounded-lg p-4">
                  <div className="text-xs text-slate-400">
                    Call Clássico Black-Scholes
                  </div>
                  <div className="text-2xl font-mono font-bold text-slate-100 tabular-nums mt-1">
                    ${bsResult.callClassic.toFixed(2)}
                  </div>
                  <div className="text-[11px] font-mono text-slate-500 mt-1">
                    N(d₁) = { normCDF(bsResult.d1).toFixed(4) }
                  </div>
                </div>

                <div className="bg-[#0B0E17] border border-slate-800 rounded-lg p-4">
                  <div className="text-xs text-cyan-400">
                    Call Quântico (VQE + Aer)
                  </div>
                  <div className="text-2xl font-mono font-bold text-cyan-400 tabular-nums mt-1">
                    ${bsResult.callQuantumVqe.toFixed(2)}
                  </div>
                  <div className="text-[11px] font-mono text-slate-500 mt-1">
                    Δ Conv: $
                    {Math.abs(
                      bsResult.callClassic - bsResult.callQuantumVqe
                    ).toFixed(3)}
                  </div>
                </div>

                <div className="bg-[#0B0E17] border border-slate-800 rounded-lg p-4">
                  <div className="text-xs text-slate-400">
                    Put Clássico Black-Scholes
                  </div>
                  <div className="text-2xl font-mono font-bold text-slate-100 tabular-nums mt-1">
                    ${bsResult.putClassic.toFixed(2)}
                  </div>
                  <div className="text-[11px] font-mono text-slate-500 mt-1">
                    N(-d₂) = { normCDF(-bsResult.d2).toFixed(4) }
                  </div>
                </div>

                <div className="bg-[#0B0E17] border border-slate-800 rounded-lg p-4">
                  <div className="text-xs text-emerald-400">
                    Put Quântico (VQE + Aer)
                  </div>
                  <div className="text-2xl font-mono font-bold text-emerald-400 tabular-nums mt-1">
                    ${bsResult.putQuantumVqe.toFixed(2)}
                  </div>
                  <div className="text-[11px] font-mono text-slate-500 mt-1">
                    1024 Shots Qiskit Sampler
                  </div>
                </div>
              </div>

              {/* Greeks Strip */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-[#0B0E17] border border-slate-800 rounded-lg p-4 font-mono text-xs tabular-nums">
                <div>
                  <span className="text-slate-500 block">Delta (Δ Call)</span>
                  <span className="text-slate-100 font-semibold text-sm">
                    {bsResult.deltaCall.toFixed(4)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Gamma (Γ)</span>
                  <span className="text-slate-100 font-semibold text-sm">
                    {bsResult.gamma.toFixed(4)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Vega (ν / 1% vol)</span>
                  <span className="text-slate-100 font-semibold text-sm">
                    {bsResult.vega.toFixed(4)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Theta Diário (Θ)</span>
                  <span className="text-rose-400 font-semibold text-sm">
                    {bsResult.thetaCall.toFixed(4)}
                  </span>
                </div>
              </div>

              {/* Quantum State Histogram (1024 shots) */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-300">
                    Distribuição de Estados Quânticos Medidos (1024 Shots —
                    RY/RZ + CNOT Ring)
                  </span>
                  <span className="text-xs font-mono text-slate-400">
                    d₁ = {bsResult.d1.toFixed(3)} · d₂ = {bsResult.d2.toFixed(3)}
                  </span>
                </div>
                <div className="space-y-2 bg-[#0B0E17] border border-slate-800 rounded-lg p-4">
                  {bsResult.stateProbabilities.map((st) => (
                    <div
                      key={st.state}
                      className="flex items-center gap-3 text-xs font-mono tabular-nums"
                    >
                      <span className="w-16 text-cyan-400">{st.state}</span>
                      <div className="flex-1 h-2.5 bg-slate-800 rounded overflow-hidden">
                        <div
                          className="h-full bg-cyan-400"
                          style={{ width: `${st.probability * 100}%` }}
                        />
                      </div>
                      <span className="w-28 text-right text-slate-300">
                        {st.count} shots ({(st.probability * 100).toFixed(1)}%)
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            MODULE 4: PENNYLANE QML TOKEN VALIDATOR (ANTI-SCAM)
        =================================================================== */}
        {activeSection === 'validator' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            <div className="lg:col-span-4 bg-[#111827] border border-slate-800 rounded-xl p-6 space-y-5">
              <div>
                <h2 className="text-lg font-semibold text-slate-100">
                  04. PennyLane QML Token Validator
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Classificador variacional quântico que analisa concentração de
                  holders, volume on-chain e wash trading para bloquear rug
                  pulls antes do Tensor Bot operar.
                </p>
              </div>

              <form
                onSubmit={handleAuditCustomToken}
                className="space-y-3 pt-2 border-t border-slate-800"
              >
                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Símbolo do Token para Auditoria QML
                  </label>
                  <input
                    type="text"
                    value={customTokenSymbol}
                    onChange={(e) => setCustomTokenSymbol(e.target.value)}
                    placeholder="Ex: PEPEQ"
                    className="w-full bg-[#0B0E17] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-100"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-400">
                      Concentração Top Holders
                    </span>
                    <span className="font-mono text-cyan-400 tabular-nums">
                      {(customConcentration * 100).toFixed(0)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.05}
                    max={0.98}
                    step={0.01}
                    value={customConcentration}
                    onChange={(e) =>
                      setCustomConcentration(Number(e.target.value))
                    }
                    className="w-full accent-cyan-500 cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-400">Transações 24h</span>
                    <span className="font-mono text-slate-200 tabular-nums">
                      {customTxCount.toLocaleString()} txs
                    </span>
                  </div>
                  <input
                    type="range"
                    min={200}
                    max={95000}
                    step={500}
                    value={customTxCount}
                    onChange={(e) => setCustomTxCount(Number(e.target.value))}
                    className="w-full accent-cyan-500 cursor-pointer"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">
                      Variação 24h (%)
                    </label>
                    <input
                      type="number"
                      value={customPriceChange}
                      onChange={(e) =>
                        setCustomPriceChange(Number(e.target.value))
                      }
                      className="w-full bg-[#0B0E17] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono tabular-nums text-slate-100"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">
                      Idade (Dias)
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={customAgeDays}
                      onChange={(e) =>
                        setCustomAgeDays(Math.max(1, Number(e.target.value)))
                      }
                      className="w-full bg-[#0B0E17] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono tabular-nums text-slate-100"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors"
                >
                  Executar Circuito QML no Token
                </button>
              </form>
            </div>

            <div className="lg:col-span-8 bg-[#111827] border border-slate-800 rounded-xl p-6 space-y-4">
              <div>
                <h3 className="text-base font-semibold text-slate-100">
                  Relatório de Validação Quântica de Contratos (⟨PauliZ₀⟩ +
                  Heurística On-Chain)
                </h3>
                <p className="text-xs text-slate-400">
                  Tokens classificados como SCAM são automaticamente bloqueados
                  nas rotas do Tensor Trading Bot
                </p>
              </div>

              <div className="overflow-x-auto border border-slate-800 rounded-lg">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 bg-[#0B0E17] text-[11px] font-mono text-slate-400">
                      <th className="py-2.5 px-4">Token</th>
                      <th className="py-2.5 px-4 text-right">Holders Top %</th>
                      <th className="py-2.5 px-4 text-right">Txs 24h</th>
                      <th className="py-2.5 px-4 text-right">QNode ⟨Z₀⟩</th>
                      <th className="py-2.5 px-4 text-right">Score Final</th>
                      <th className="py-2.5 px-4">Veredito QML</th>
                      <th className="py-2.5 px-4">Diagnóstico On-Chain</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/70 text-xs">
                    {auditedTokens.map((item) => (
                      <tr
                        key={item.symbol}
                        className="hover:bg-slate-900/60 transition-colors"
                      >
                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-100">
                            {item.symbol}
                          </div>
                          <div className="font-mono text-[11px] text-slate-500">
                            {item.contractAddress} · {item.ageDays}d
                          </div>
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-300">
                          {(item.holderConcentration * 100).toFixed(0)}%
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-300">
                          {item.transactionCount24h.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-cyan-400">
                          {item.qmlExpectationZ.toFixed(3)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-slate-100">
                          {item.finalScore.toFixed(3)}
                        </td>
                        <td className="py-3 px-4 font-mono font-semibold">
                          {item.verdict === 'SEGURO' && (
                            <span className="text-emerald-400">● SEGURO</span>
                          )}
                          {item.verdict === 'VERIFICAR' && (
                            <span className="text-amber-400">▲ VERIFICAR</span>
                          )}
                          {item.verdict === 'SCAM' && (
                            <span className="text-rose-400">✖ SCAM</span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-slate-400">
                          {item.reasons.join(' · ')}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            MODULE 5: REGISTERED TRADING APIs MANAGEMENT
        =================================================================== */}
        {activeSection === 'apis' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            {/* Left Form to Register New Trading API */}
            <div className="lg:col-span-4 bg-[#111827] border border-slate-800 rounded-xl p-6 space-y-5">
              <div>
                <h2 className="text-lg font-semibold text-slate-100 flex items-center gap-2">
                  <KeyRound className="w-4 h-4 text-cyan-400" />
                  Cadastrar Nova API de Trading
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Adicione endpoints DEX RPC, chaves institucionais CEX ou
                  canais IBM Quantum Runtime para uso imediato no Tensor Bot.
                </p>
              </div>

              <form
                onSubmit={handleRegisterNewApi}
                className="space-y-3 pt-2 border-t border-slate-800"
              >
                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Identificador da API
                  </label>
                  <input
                    type="text"
                    required
                    value={newApiName}
                    onChange={(e) => setNewApiName(e.target.value)}
                    placeholder="Ex: QuickSwap Polygon RPC"
                    className="w-full bg-[#0B0E17] border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Provedor / Exchange
                  </label>
                  <select
                    value={newApiExchange}
                    onChange={(e) => setNewApiExchange(e.target.value)}
                    className="w-full bg-[#0B0E17] border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100"
                  >
                    <option value="Uniswap V3 + Arbitrum RPC">
                      Uniswap V3 + Arbitrum RPC
                    </option>
                    <option value="Binance Spot & Futures API">
                      Binance Spot & Futures API
                    </option>
                    <option value="1inch Fusion + Optimism RPC">
                      1inch Fusion + Optimism RPC
                    </option>
                    <option value="IBM Quantum Qiskit Runtime">
                      IBM Quantum Qiskit Runtime
                    </option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Endpoint RPC / REST URL
                  </label>
                  <input
                    type="url"
                    value={newApiEndpoint}
                    onChange={(e) => setNewApiEndpoint(e.target.value)}
                    className="w-full bg-[#0B0E17] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Token / Chave de API (Armazenada com Máscara)
                  </label>
                  <input
                    type="password"
                    value={newApiKeyInput}
                    onChange={(e) => setNewApiKeyInput(e.target.value)}
                    placeholder="fc_live_..."
                    className="w-full bg-[#0B0E17] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Limite Diário de Volume (USD)
                  </label>
                  <input
                    type="number"
                    min={1000}
                    step={5000}
                    value={newApiLimit}
                    onChange={(e) => setNewApiLimit(Number(e.target.value))}
                    className="w-full bg-[#0B0E17] border border-slate-800 rounded-lg px-3 py-2 text-xs font-mono tabular-nums text-slate-100"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  Cadastrar e Conectar ao Tensor Bot
                </button>
              </form>

              {apiPingFeedback && (
                <div className="p-3 rounded-lg bg-emerald-950/30 border border-emerald-800/50 text-xs text-emerald-300">
                  {apiPingFeedback}
                </div>
              )}
            </div>

            {/* Right List of Registered Trading APIs */}
            <div className="lg:col-span-8 bg-[#111827] border border-slate-800 rounded-xl p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-semibold text-slate-100">
                    Credenciais & APIs de Trading Cadastradas no focuscrawl.si
                  </h3>
                  <p className="text-xs text-slate-400">
                    Selecione qual credencial o Tensor MicroModal deve utilizar
                    para assinar e rotear ordens
                  </p>
                </div>
              </div>

              <div className="space-y-3">
                {registeredApis.map((api) => {
                  const isCurrent = api.id === selectedApiId;
                  const usagePct = Math.min(
                    100,
                    (api.usedVolumeUsd / api.dailyVolumeLimitUsd) * 100
                  );
                  return (
                    <div
                      key={api.id}
                      className={`p-4 rounded-lg border transition-colors ${
                        isCurrent
                          ? 'bg-[#0B0E17] border-cyan-500/60'
                          : 'bg-[#0B0E17]/60 border-slate-800'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between gap-4">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold text-slate-100">
                              {api.name}
                            </span>
                            <span className="text-xs font-mono text-emerald-400">
                              ● {api.status} ({api.latencyMs}ms)
                            </span>
                          </div>
                          <div className="text-xs text-slate-400 font-mono mt-0.5">
                            {api.exchange} · {api.endpointUrl} · Key:{' '}
                            <span className="text-slate-200">
                              {api.apiKeyMasked}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              setSelectedApiId(api.id);
                              setApiPingFeedback(
                                `Roteamento principal alterado para ${api.name} (${api.latencyMs}ms).`
                              );
                            }}
                            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                              isCurrent
                                ? 'bg-cyan-500 text-slate-950 font-semibold'
                                : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                            }`}
                          >
                            {isCurrent
                              ? 'Conectada ao Bot'
                              : 'Usar no Tensor Bot'}
                          </button>
                        </div>
                      </div>

                      <div className="mt-3 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-4 text-xs">
                        <div className="text-slate-400">
                          Escopos: {api.permissions.join(' · ')}
                        </div>
                        <div className="font-mono tabular-nums text-slate-300">
                          Volume 24h: ${api.usedVolumeUsd.toLocaleString()} / $
                          {api.dailyVolumeLimitUsd.toLocaleString()} (
                          {usagePct.toFixed(1)}%)
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            MODULE 6: PYTHON QUANTUM CRYPTO MASTER CODEBASE
        =================================================================== */}
        {activeSection === 'python' && (
          <div className="bg-[#111827] border border-slate-800 rounded-xl p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-semibold text-slate-100">
                  06. Repositório Quantum Crypto Master (Scripts Sincronizados)
                </h2>
                <p className="text-xs text-slate-400">
                  Os parâmetros que você ajusta na interface atualizam
                  automaticamente o código Qiskit e PennyLane abaixo.
                </p>
              </div>

              <div className="flex items-center gap-2">
                {(
                  [
                    'arbitrage.py',
                    'portfolio.py',
                    'black_scholes.py',
                    'validator.py',
                  ] as const
                ).map((file) => (
                  <button
                    key={file}
                    onClick={() => setActivePythonFile(file)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-colors ${
                      activePythonFile === file
                        ? 'bg-cyan-500 text-slate-950 font-semibold'
                        : 'bg-[#0B0E17] text-slate-400 hover:text-slate-200 border border-slate-800'
                    }`}
                  >
                    {file}
                  </button>
                ))}

                <button
                  onClick={() => {
                    navigator.clipboard.writeText(
                      pythonSnippets[activePythonFile]
                    );
                    setCopiedScript(true);
                    setTimeout(() => setCopiedScript(false), 2000);
                  }}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-100 flex items-center gap-1.5"
                >
                  {copiedScript ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      Copiado
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      Copiar Script
                    </>
                  )}
                </button>
              </div>
            </div>

            <pre className="bg-[#0B0E17] border border-slate-800 rounded-lg p-4 overflow-x-auto text-xs font-mono text-slate-200 leading-relaxed">
              <code>{pythonSnippets[activePythonFile]}</code>
            </pre>
          </div>
        )}
      </main>

      {/* Quiet Footer */}
      <footer className="border-t border-slate-800/80 py-4 px-6 text-xs text-slate-500 max-w-[1440px] w-full mx-auto flex flex-wrap items-center justify-between gap-4">
        <div>
          focuscrawl.si · Quantum Finance & Tensor Neural Trading Infrastructure
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={() => setIsTensorModalOpen(true)}
            className="hover:text-slate-300 transition-colors"
          >
            Tensor MicroModal
          </button>
          <span>·</span>
          <button
            onClick={() => setActiveSection('apis')}
            className="hover:text-slate-300 transition-colors"
          >
            Gerenciar APIs
          </button>
          <span>·</span>
          <button
            onClick={() => setActiveSection('python')}
            className="hover:text-slate-300 transition-colors"
          >
            Documentação Qiskit
          </button>
        </div>
      </footer>

      {/* Tensor Trading Bot MicroModal */}
      <TensorBotMicroModal
        isOpen={isTensorModalOpen}
        onClose={() => setIsTensorModalOpen(false)}
        registeredApis={registeredApis}
        selectedApiId={selectedApiId}
        onSelectApi={setSelectedApiId}
        botRunning={botRunning}
        onToggleBot={() => setBotRunning((r) => !r)}
        orders={orders}
        onExecuteSingleCycle={executeSingleCycle}
        latestArbitrage={arbitrageResult}
      />
    </div>
  );
}
