export interface RegisteredExchangeAPI {
  id: string;
  name: string;
  exchange: string;
  network: string;
  endpointUrl: string;
  apiKeyMasked: string;
  status: 'Nominal' | 'Drifting' | 'Disconnected';
  permissions: string[];
  latencyMs: number;
  dailyVolumeLimitUsd: number;
  usedVolumeUsd: number;
  registeredAt: string;
}

export interface ArbitragePool {
  id: string;
  pair: string;
  dex: string;
  rate: number;
  feePercent: number;
  liquidityUsd: number;
  pauliTerm: string;
}

export interface ArbitrageResult {
  routeIndices: number[];
  routePools: ArbitragePool[];
  initialCapital: number;
  finalCapital: number;
  grossProfitUsd: number;
  gasCostUsd: number;
  netProfitUsd: number;
  profitPercent: number;
  quantumEigenvalue: number;
  qaoaReps: number;
  executionTimeMs: number;
}

export interface PortfolioAsset {
  symbol: string;
  name: string;
  priceUsd: number;
  change24h: number;
  expectedReturn: number;
  volatility: number;
  allocationWeight: number;
}

export interface BlackScholesOutput {
  spotPrice: number;
  strikePrice: number;
  timeYears: number;
  riskFreeRate: number;
  volatility: number;
  d1: number;
  d2: number;
  callClassic: number;
  putClassic: number;
  callQuantumVqe: number;
  putQuantumVqe: number;
  deltaCall: number;
  gamma: number;
  vega: number;
  thetaCall: number;
  stateProbabilities: { state: string; probability: number; count: number }[];
}

export interface TokenAuditData {
  symbol: string;
  name: string;
  contractAddress: string;
  network: string;
  holderCount: number;
  holderConcentration: number; // 0 to 1
  transactionCount24h: number;
  uniqueFrom24h: number;
  priceChange24h: number;
  volumeChange24h: number;
  ageDays: number;
  burnedPercent: number;
}

export interface TokenAuditResult extends TokenAuditData {
  qmlExpectationZ: number;
  heuristicRiskScore: number;
  finalScore: number;
  verdict: 'SEGURO' | 'VERIFICAR' | 'SCAM';
  confidence: number;
  reasons: string[];
  rxAngles: number[];
}

export interface TensorOrder {
  id: string;
  timestamp: string;
  strategy: 'QAOA Arbitragem' | 'VQE Rebalance' | 'Black-Scholes Hedge' | 'QML Momentum';
  pair: string;
  exchangeApiName: string;
  side: 'COMPRA' | 'VENDA' | 'ARBITRAGEM';
  capitalUsd: number;
  entryPrice: number;
  expectedReturnPct: number;
  pnlUsd: number;
  tensorShape: string;
  quantumConfidence: number;
  status: 'Executada' | 'Liquidada' | 'Protegida';
}
