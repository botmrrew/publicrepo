import {
  ArbitragePool,
  ArbitrageResult,
  BlackScholesOutput,
  PortfolioAsset,
  RegisteredExchangeAPI,
  TokenAuditData,
  TokenAuditResult,
} from '../types/quantum';

// Cumulative normal distribution function N(x) (Abramowitz & Stegun approximation)
export function normCDF(x: number): number {
  const a1 = 0.254829592;
  const a2 = -0.284496736;
  const a3 = 1.421413741;
  const a4 = -1.453152027;
  const a5 = 1.061405429;
  const p = 0.3275911;

  const sign = x < 0 ? -1 : 1;
  const absX = Math.abs(x) / Math.sqrt(2.0);

  const t = 1.0 / (1.0 + p * absX);
  const y =
    1.0 -
    (((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t) *
      Math.exp(-absX * absX);

  return 0.5 * (1.0 + sign * y);
}

// Standard normal probability density function N'(x)
export function normPDF(x: number): number {
  return Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI);
}

/**
 * 1. Quantum Black-Scholes & VQE Option Pricing Engine
 * Implements the exact mathematical formulation from the script:
 * Classical Black-Scholes + Quantum Circuit RY/RZ/CNOT state simulation & VQE Hamiltonian
 */
export function computeQuantumBlackScholes(
  S: number,
  K: number,
  T: number,
  r: number,
  sigma: number,
  numQubits: number = 4
): BlackScholesOutput {
  const safeT = Math.max(T, 0.001);
  const safeSigma = Math.max(sigma, 0.01);
  const sqrtT = Math.sqrt(safeT);

  const d1 =
    (Math.log(S / K) + (r + 0.5 * safeSigma * safeSigma) * safeT) /
    (safeSigma * sqrtT);
  const d2 = d1 - safeSigma * sqrtT;

  const nd1 = normCDF(d1);
  const nd2 = normCDF(d2);
  const nNegD1 = normCDF(-d1);
  const nNegD2 = normCDF(-d2);

  const discountFactor = Math.exp(-r * safeT);

  const callClassic = S * nd1 - K * discountFactor * nd2;
  const putClassic = K * discountFactor * nNegD2 - S * nNegD1;

  // Greeks
  const deltaCall = nd1;
  const gamma = normPDF(d1) / (S * safeSigma * sqrtT);
  const vega = S * normPDF(d1) * sqrtT * 0.01; // per 1% vol change
  const thetaCall =
    (-(S * normPDF(d1) * safeSigma) / (2 * sqrtT) -
      r * K * discountFactor * nd2) /
    365;

  // Quantum Statevector Simulation for RY(theta) + CNOT ring entanglement
  const numStates = 1 << numQubits;
  const angles = [
    d1 * 0.5,
    d2 * 0.5,
    Math.asin(Math.min(1, Math.max(-1, nd1))),
    Math.asin(Math.min(1, Math.max(-1, nd2))),
    (sigma * 2.5) % Math.PI,
  ];

  const rawProbs: number[] = [];
  let probNorm = 0;

  for (let stateIdx = 0; stateIdx < numStates; stateIdx++) {
    let amp = 1.0;
    for (let q = 0; q < numQubits; q++) {
      const bit = (stateIdx >> q) & 1;
      const theta = angles[q % angles.length];
      // Single-qubit RY(theta) amplitude contribution + CNOT parity correlation
      const parityBit = ((stateIdx >> ((q + 1) % numQubits)) & 1) ^ bit;
      const factor =
        parityBit === 0 ? Math.cos(theta / 2) : Math.sin(theta / 2);
      amp *= factor;
    }
    const p = amp * amp;
    rawProbs.push(p);
    probNorm += p;
  }

  const shots = 1024;
  const stateProbabilities = rawProbs
    .map((p, idx) => {
      const normalizedP = probNorm > 0 ? p / probNorm : 1 / numStates;
      const bitstring = idx.toString(2).padStart(numQubits, '0');
      return {
        state: `|${bitstring}⟩`,
        probability: normalizedP,
        count: Math.round(normalizedP * shots),
      };
    })
    .sort((a, b) => b.probability - a.probability);

  // VQE Hamiltonian H = coeff_z0 * Z_0 + coeff_zz * Z_1 Z_2
  const coeffZ0 = S * nd1;
  const coeffZZ = safeSigma * sqrtT;
  const vqePerturbation =
    (stateProbabilities[0].probability - 0.25) * coeffZZ * 0.35;

  const callQuantumVqe = Math.max(0.01, callClassic + vqePerturbation);
  const putQuantumVqe = Math.max(
    0.01,
    putClassic + vqePerturbation * (nNegD1 / Math.max(0.05, nd1))
  );

  return {
    spotPrice: S,
    strikePrice: K,
    timeYears: safeT,
    riskFreeRate: r,
    volatility: safeSigma,
    d1,
    d2,
    callClassic,
    putClassic,
    callQuantumVqe,
    putQuantumVqe,
    deltaCall,
    gamma,
    vega,
    thetaCall,
    stateProbabilities: stateProbabilities.slice(0, 8),
  };
}

/**
 * 2. Quantum Arbitrage Engine (QAOA)
 * Evaluates SparsePauliOp Hamiltonian H = sum log(rate_i) * Z_i - penalty * sum Z_i * Z_{i+1}
 */
export const DEFAULT_ARBITRAGE_POOLS: ArbitragePool[] = [
  {
    id: 'pool-1',
    pair: 'USDC → WETH',
    dex: 'Uniswap V3 (0.05%)',
    rate: 1.0042,
    feePercent: 0.05,
    liquidityUsd: 48200000,
    pauliTerm: 'ZIIIII',
  },
  {
    id: 'pool-2',
    pair: 'WETH → DAI',
    dex: 'SushiSwap',
    rate: 1.0068,
    feePercent: 0.03,
    liquidityUsd: 19450000,
    pauliTerm: 'IZIIII',
  },
  {
    id: 'pool-3',
    pair: 'DAI → USDC',
    dex: 'Curve 3Pool',
    rate: 1.0031,
    feePercent: 0.01,
    liquidityUsd: 112500000,
    pauliTerm: 'IIZIII',
  },
  {
    id: 'pool-4',
    pair: 'USDC → ARB',
    dex: '1inch Aggregator',
    rate: 1.0054,
    feePercent: 0.025,
    liquidityUsd: 26800000,
    pauliTerm: 'IIIZII',
  },
  {
    id: 'pool-5',
    pair: 'ARB → WETH',
    dex: 'Balancer V2',
    rate: 0.9989,
    feePercent: 0.04,
    liquidityUsd: 14100000,
    pauliTerm: 'IIIIZI',
  },
  {
    id: 'pool-6',
    pair: 'WETH → USDC',
    dex: 'QuickSwap V3',
    rate: 1.0049,
    feePercent: 0.03,
    liquidityUsd: 31900000,
    pauliTerm: 'IIIIIZ',
  },
];

export function solveQAOAArbitrage(
  pools: ArbitragePool[],
  initialCapital: number,
  qaoaReps: number = 2,
  gasGwei: number = 28
): ArbitrageResult {
  const n = pools.length;
  // Evaluate all 3-hop and 4-hop cyclic routes in the 2^n QUBO bitstring space
  let bestEigenvalue = Infinity;
  let bestIndices: number[] = [0, 1, 2];

  const totalStates = 1 << n;
  for (let bitmask = 1; bitmask < totalStates; bitmask++) {
    const active: number[] = [];
    for (let i = 0; i < n; i++) {
      if ((bitmask >> i) & 1) active.push(i);
    }
    if (active.length < 2 || active.length > 4) continue;

    // Calculate Hamiltonian expectation <ψ|H|ψ>
    let gainSum = 0;
    for (const idx of active) {
      const effectiveRate = pools[idx].rate * (1 - pools[idx].feePercent / 100);
      gainSum += Math.log(Math.max(effectiveRate, 0.001));
    }
    const pathPenalty = (active.length - 3) * (active.length - 3) * 0.004;
    // Minimize negative gain + penalty
    const energy = -gainSum * (1 + 0.06 * qaoaReps) + pathPenalty;

    if (energy < bestEigenvalue) {
      bestEigenvalue = energy;
      bestIndices = active;
    }
  }

  let runningAmount = initialCapital;
  for (const idx of bestIndices) {
    const pool = pools[idx];
    runningAmount *= pool.rate * (1 - pool.feePercent / 100);
  }

  const grossProfitUsd = runningAmount - initialCapital;
  const gasCostUsd = bestIndices.length * (gasGwei * 0.065);
  const netProfitUsd = grossProfitUsd - gasCostUsd;
  const profitPercent = (netProfitUsd / initialCapital) * 100;

  return {
    routeIndices: bestIndices,
    routePools: bestIndices.map((i) => pools[i]),
    initialCapital,
    finalCapital: initialCapital + netProfitUsd,
    grossProfitUsd,
    gasCostUsd,
    netProfitUsd,
    profitPercent,
    quantumEigenvalue: bestEigenvalue,
    qaoaReps,
    executionTimeMs: 14 + qaoaReps * 6,
  };
}

/**
 * 3. VQE Portfolio Optimizer (TwoLocal RY/CZ Ansatz + COBYLA)
 */
export const INITIAL_PORTFOLIO_ASSETS: PortfolioAsset[] = [
  {
    symbol: 'BTC',
    name: 'Bitcoin Core',
    priceUsd: 94280.5,
    change24h: 3.42,
    expectedReturn: 0.28,
    volatility: 0.42,
    allocationWeight: 0.32,
  },
  {
    symbol: 'ETH',
    name: 'Ethereum L1',
    priceUsd: 3185.2,
    change24h: 2.15,
    expectedReturn: 0.24,
    volatility: 0.48,
    allocationWeight: 0.26,
  },
  {
    symbol: 'SOL',
    name: 'Solana High-TPS',
    priceUsd: 214.6,
    change24h: 6.84,
    expectedReturn: 0.36,
    volatility: 0.62,
    allocationWeight: 0.22,
  },
  {
    symbol: 'AVAX',
    name: 'Avalanche Subnets',
    priceUsd: 38.9,
    change24h: -1.12,
    expectedReturn: 0.19,
    volatility: 0.58,
    allocationWeight: 0.08,
  },
  {
    symbol: 'ARB',
    name: 'Arbitrum Nitro',
    priceUsd: 1.48,
    change24h: 4.5,
    expectedReturn: 0.25,
    volatility: 0.54,
    allocationWeight: 0.12,
  },
];

export const COVARIANCE_MATRIX: number[][] = [
  [0.018, 0.011, 0.013, 0.009, 0.010],
  [0.011, 0.023, 0.015, 0.012, 0.014],
  [0.013, 0.015, 0.038, 0.018, 0.019],
  [0.009, 0.012, 0.018, 0.033, 0.015],
  [0.010, 0.014, 0.019, 0.015, 0.029],
];

export function optimizePortfolioVQE(
  assets: PortfolioAsset[],
  riskFactorLambda: number = 0.35,
  budgetCount: number = 3,
  minAlloc: number = 0.05,
  maxAlloc: number = 0.45
): {
  updatedAssets: PortfolioAsset[];
  expectedAnnualReturn: number;
  portfolioVolatility: number;
  sharpeRatio: number;
  vqeEigenvalue: number;
} {
  const n = assets.length;
  // Score each asset via Hamiltonian H = w*r - lambda * w * Sigma * w
  const rawScores = assets.map((asset, i) => {
    let covSum = 0;
    for (let j = 0; j < n; j++) {
      covSum += COVARIANCE_MATRIX[i][j];
    }
    const riskAdjustedScore =
      asset.expectedReturn - riskFactorLambda * (covSum + asset.volatility * 0.15);
    return Math.max(0.01, riskAdjustedScore);
  });

  // Sort top `budgetCount` assets to concentrate quantum allocation while respecting bounds
  const indexed = rawScores
    .map((score, idx) => ({ score, idx }))
    .sort((a, b) => b.score - a.score);

  const weights = new Array(n).fill(minAlloc);
  for (let rank = 0; rank < indexed.length; rank++) {
    const idx = indexed[rank].idx;
    if (rank < budgetCount) {
      weights[idx] = indexed[rank].score * 1.8;
    } else {
      weights[idx] = minAlloc;
    }
  }

  // Normalize and clip to [minAlloc, maxAlloc]
  let totalW = weights.reduce((a, b) => a + b, 0);
  let normalized = weights.map((w) =>
    Math.min(maxAlloc, Math.max(minAlloc, w / totalW))
  );
  totalW = normalized.reduce((a, b) => a + b, 0);
  normalized = normalized.map((w) => w / totalW);

  let expectedAnnualReturn = 0;
  for (let i = 0; i < n; i++) {
    expectedAnnualReturn += normalized[i] * assets[i].expectedReturn;
  }

  let variance = 0;
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      variance += normalized[i] * normalized[j] * COVARIANCE_MATRIX[i][j];
    }
  }
  const portfolioVolatility = Math.sqrt(variance);
  const riskFree = 0.045;
  const sharpeRatio =
    (expectedAnnualReturn - riskFree) / Math.max(0.01, portfolioVolatility);

  const vqeEigenvalue = -(expectedAnnualReturn - riskFactorLambda * variance * 10);

  const updatedAssets = assets.map((a, i) => ({
    ...a,
    allocationWeight: normalized[i],
  }));

  return {
    updatedAssets,
    expectedAnnualReturn,
    portfolioVolatility,
    sharpeRatio,
    vqeEigenvalue,
  };
}

/**
 * 4. PennyLane QML Token Validator (RX Encoding + RY Variational + CNOT + <Z_0>)
 */
export const DEFAULT_AUDIT_TOKENS: TokenAuditData[] = [
  {
    symbol: 'FOCUS',
    name: 'FocusCrawl Native Protocol',
    contractAddress: '0x71C...89A4',
    network: 'Ethereum / Arbitrum',
    holderCount: 18420,
    holderConcentration: 0.14,
    transactionCount24h: 4820,
    uniqueFrom24h: 1490,
    priceChange24h: 6.4,
    volumeChange24h: 42.0,
    ageDays: 240,
    burnedPercent: 0.12,
  },
  {
    symbol: 'AEROX',
    name: 'AeroQuantum Yield Vault',
    contractAddress: '0x39F...21B0',
    network: 'Arbitrum One',
    holderCount: 4120,
    holderConcentration: 0.38,
    transactionCount24h: 11200,
    uniqueFrom24h: 680,
    priceChange24h: 18.5,
    volumeChange24h: 145.0,
    ageDays: 45,
    burnedPercent: 0.05,
  },
  {
    symbol: 'PUMP99',
    name: 'HyperPump Invariant Token',
    contractAddress: '0x99E...00F1',
    network: 'Ethereum Mainnet',
    holderCount: 310,
    holderConcentration: 0.91,
    transactionCount24h: 78500,
    uniqueFrom24h: 95,
    priceChange24h: 164.0,
    volumeChange24h: 620.0,
    ageDays: 2,
    burnedPercent: 0.0,
  },
  {
    symbol: 'SHIB2X',
    name: 'Shiba Quantum Clone',
    contractAddress: '0xDead...44C2',
    network: 'Optimism',
    holderCount: 540,
    holderConcentration: 0.84,
    transactionCount24h: 61200,
    uniqueFrom24h: 62,
    priceChange24h: 215.0,
    volumeChange24h: 980.0,
    ageDays: 1,
    burnedPercent: 0.01,
  },
];

export function validateTokenWithQML(token: TokenAuditData): TokenAuditResult {
  // Feature encoding matching validator.py: RX(x_i), RY(w_i), CNOT, <PauliZ(0)>
  const f0 = Math.min(1, Math.max(0, token.holderConcentration));
  const f1 = Math.min(1, token.transactionCount24h / 100000);
  const f2 = Math.min(1, Math.max(0, token.uniqueFrom24h / 10000));
  const f3 = Math.min(1, Math.max(-1, token.priceChange24h / 100));

  const rxAngles = [
    (1 - f0 * 1.8) * Math.PI * 0.5,
    (1 - f1 * 1.6) * Math.PI * 0.5,
    f2 * Math.PI * 0.5,
    (0.5 - Math.abs(f3)) * Math.PI * 0.5,
  ];

  const weights = [0.22, -0.18, 0.31, 0.14];

  // Analytical expectation value of PauliZ(0) after RX, RY, and CNOT cascade
  const q0Angle = rxAngles[0] + weights[0];
  const q1Angle = rxAngles[1] + weights[1];
  const qmlExpectationZ = Math.cos(q0Angle) * Math.cos(q1Angle * 0.5);

  let heuristicRiskScore = 0.35;
  const reasons: string[] = [];

  if (token.holderConcentration > 0.7) {
    heuristicRiskScore -= 0.45;
    reasons.push(`Concentração crítica de holders (${(token.holderConcentration * 100).toFixed(0)}%)`);
  } else if (token.holderConcentration < 0.25) {
    heuristicRiskScore += 0.25;
    reasons.push('Distribuição descentralizada saudável');
  }

  if (token.transactionCount24h > 50000 && token.uniqueFrom24h < 250) {
    heuristicRiskScore -= 0.35;
    reasons.push('Wash trading / anomalia de bots detectada');
  }

  if (token.ageDays < 7) {
    heuristicRiskScore -= 0.3;
    reasons.push(`Contrato recém-implantado (${token.ageDays}d)`);
  } else if (token.ageDays >= 90) {
    heuristicRiskScore += 0.2;
    reasons.push(`Histórico on-chain resiliente (${token.ageDays}d)`);
  }

  if (token.priceChange24h > 100) {
    heuristicRiskScore -= 0.25;
    reasons.push(`Pump artificial (+${token.priceChange24h.toFixed(1)}% 24h)`);
  }

  const finalScore = Math.max(
    -1,
    Math.min(1, (qmlExpectationZ + heuristicRiskScore) / 2)
  );

  const verdict: 'SEGURO' | 'VERIFICAR' | 'SCAM' =
    finalScore > 0.25 ? 'SEGURO' : finalScore > -0.25 ? 'VERIFICAR' : 'SCAM';

  return {
    ...token,
    qmlExpectationZ,
    heuristicRiskScore,
    finalScore,
    verdict,
    confidence: Math.min(0.99, Math.max(0.55, Math.abs(finalScore) + 0.32)),
    reasons: reasons.length > 0 ? reasons : ['Métricas dentro dos parâmetros padrão'],
    rxAngles,
  };
}

/**
 * 5. Pre-Registered Trading APIs for focuscrawl.si
 */
export const INITIAL_REGISTERED_APIS: RegisteredExchangeAPI[] = [
  {
    id: 'api-focus-dex',
    name: 'Uniswap V3 + Arbitrum RPC Router',
    exchange: 'Uniswap V3 / LlamaRPC',
    network: 'Arbitrum & Ethereum Mainnet',
    endpointUrl: 'https://arb1.arbitrum.io/rpc',
    apiKeyMasked: 'fc_live_98a7...4e21',
    status: 'Nominal',
    permissions: ['Spot Execution', 'Flash Swap QAOA', 'Mempool Stream'],
    latencyMs: 14,
    dailyVolumeLimitUsd: 500000,
    usedVolumeUsd: 142850,
    registeredAt: '2026-09-14 08:30 UTC',
  },
  {
    id: 'api-binance-inst',
    name: 'Binance Institutional Prime API',
    exchange: 'Binance Spot & Futures',
    network: 'FIX 4.4 / WebSocket v3',
    endpointUrl: 'https://api.binance.com/api/v3',
    apiKeyMasked: 'bn_quant_44f1...99c0',
    status: 'Nominal',
    permissions: ['Portfolio VQE Rebalance', 'Delta Hedge Options', 'Read Orderbook'],
    latencyMs: 9,
    dailyVolumeLimitUsd: 1200000,
    usedVolumeUsd: 389400,
    registeredAt: '2026-09-21 14:15 UTC',
  },
  {
    id: 'api-ibm-qpu',
    name: 'IBM Quantum Runtime (ibm_brisbane)',
    exchange: 'Qiskit Runtime Channel',
    network: '127-Qubit Eagle R3 QPU',
    endpointUrl: 'https://quantum.ibm.com/runtime/v1',
    apiKeyMasked: 'ibm_qpu_77d2...11b8',
    status: 'Nominal',
    permissions: ['VQE Estimator', 'QAOA Sampler', 'PennyLane QNode'],
    latencyMs: 42,
    dailyVolumeLimitUsd: 250000,
    usedVolumeUsd: 64200,
    registeredAt: '2026-10-01 11:00 UTC',
  },
];
