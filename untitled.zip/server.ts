import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // In-memory state for borsignature.com / focuscrawl.si API calls
  const apiLogs: Array<{
    id: string;
    endpoint: string;
    method: string;
    timestamp: string;
    status: number;
    summary: string;
  }> = [];

  const newsletterSubscribers = new Set<string>([
    'botsigature@botsignature.com',
  ]);

  // 1. Real-Time Data API Endpoint
  app.post('/api/borsignature/realtime-data', (req, res) => {
    const { symbol = 'BTC/USD', interval = '1s', chapter = 'Data Extraction' } = req.body || {};
    const now = new Date().toISOString();

    const payload = {
      ok: true,
      service: 'borsignature.com Real-Time Market Intelligence API',
      endpoint: '/api/borsignature/realtime-data',
      timestamp: now,
      symbol,
      interval,
      activeModule: chapter,
      feed: [
        {
          pair: 'BTC/USDT',
          price: Number((94280 + (Math.random() - 0.48) * 180).toFixed(2)),
          spreadBps: 1.2,
          volume24hUsd: 42890100,
          signal: 'QAOA_LONG_ARBITRAGE',
        },
        {
          pair: 'ETH/USDC',
          price: Number((3185 + (Math.random() - 0.48) * 14).toFixed(2)),
          spreadBps: 0.8,
          volume24hUsd: 19450000,
          signal: 'VQE_OPTIMAL_WEIGHT',
        },
        {
          pair: 'SOL/USDC',
          price: Number((214.6 + (Math.random() - 0.48) * 3.2).toFixed(2)),
          spreadBps: 1.5,
          volume24hUsd: 11200400,
          signal: 'TENSOR_MOMENTUM_BUY',
        },
      ],
      cliCommand: `borsig stream --pairs BTC/USDT,ETH/USDC,SOL/USDC --interval ${interval} --format json`,
    };

    apiLogs.unshift({
      id: `req-${Date.now()}`,
      endpoint: '/api/borsignature/realtime-data',
      method: 'POST',
      timestamp: now,
      status: 200,
      summary: `Streamed 3 real-time market intelligence pairs (${chapter})`,
    });

    res.status(200).json(payload);
  });

  // 2. Support API Endpoint
  app.post('/api/borsignature/support', (req, res) => {
    const { topic = 'API Documentation & CLI Setup', priority = 'normal', linkSlug = 'docs-cli' } =
      req.body || {};
    const now = new Date().toISOString();

    const payload = {
      ok: true,
      service: 'borsignature.com Developer Support & SLA Gateway',
      endpoint: '/api/borsignature/support',
      ticketId: `BSIG-${Math.floor(10000 + Math.random() * 89999)}`,
      timestamp: now,
      requestedTopic: topic,
      linkSlug,
      priority,
      status: 'Assigned to Quantum Engineering Desk',
      resources: [
        { title: 'CLI Quickstart Guide', url: 'https://borsignature.com/docs/cli' },
        { title: 'WebSocket Market Stream Reference', url: 'https://borsignature.com/docs/realtime-ws' },
        { title: 'Webhook Signature Verification', url: 'https://borsignature.com/docs/webhooks' },
        { title: 'System Status & SLA Telemetry', url: 'https://borsignature.com/status' },
      ],
    };

    apiLogs.unshift({
      id: `req-${Date.now()}`,
      endpoint: '/api/borsignature/support',
      method: 'POST',
      timestamp: now,
      status: 200,
      summary: `Support API dispatched for "${topic}" (${payload.ticketId})`,
    });

    res.status(200).json(payload);
  });

  // 3. Newsletter Subscribe API Endpoint
  app.post('/api/borsignature/newsletter', (req, res) => {
    const { email = 'botsigature@botsignature.com', source = 'interactive-video-hub' } =
      req.body || {};
    const cleanEmail = String(email).trim().toLowerCase();

    if (!cleanEmail || !cleanEmail.includes('@')) {
      res.status(400).json({
        ok: false,
        error: 'E-mail inválido. Informe um endereço válido como botsigature@botsignature.com.',
      });
      return;
    }

    newsletterSubscribers.add(cleanEmail);
    const now = new Date().toISOString();

    const payload = {
      ok: true,
      service: 'borsignature.com Market Intelligence Dispatch API',
      endpoint: '/api/borsignature/newsletter',
      subscribedEmail: cleanEmail,
      source,
      timestamp: now,
      totalSubscribers: newsletterSubscribers.size,
      confirmationCode: `SUB-${Math.floor(100000 + Math.random() * 899999)}`,
      message: `Inscrição confirmada na API para ${cleanEmail}. Relatórios de Real-Time Market Intelligence ativados.`,
    };

    apiLogs.unshift({
      id: `req-${Date.now()}`,
      endpoint: '/api/borsignature/newsletter',
      method: 'POST',
      timestamp: now,
      status: 200,
      summary: `Newsletter API subscribed: ${cleanEmail}`,
    });

    res.status(200).json(payload);
  });

  // 4. Start Free Onboarding API Endpoint
  app.post('/api/borsignature/start-free', (req, res) => {
    const { plan = 'Free Developer Tier', email = 'botsigature@botsignature.com' } =
      req.body || {};
    const now = new Date().toISOString();

    const payload = {
      ok: true,
      service: 'borsignature.com Provisioning API',
      endpoint: '/api/borsignature/start-free',
      plan,
      accountEmail: email,
      provisionedApiKey: `bsig_live_${Math.random().toString(36).substring(2, 10)}_99x`,
      cliInitCommand: `npx @borsignature/cli init --key bsig_live_99x --stream realtime`,
      timestamp: now,
    };

    apiLogs.unshift({
      id: `req-${Date.now()}`,
      endpoint: '/api/borsignature/start-free',
      method: 'POST',
      timestamp: now,
      status: 200,
      summary: `Provisioned Start Free workspace & CLI token for ${email}`,
    });

    res.status(200).json(payload);
  });

  // 4.5. Aggregated Scraping Extraction & Data Analysis Telemetry Endpoint
  app.post('/api/borsignature/scraping-analysis', (req, res) => {
    const {
      category = 'ALL',
      window = '5m',
      workers = 24,
      targetSource = 'All Venues',
    } = req.body || {};
    const now = new Date().toISOString();

    const baseSources = [
      {
        id: 'src-binance-l3',
        sourceName: 'Binance Spot & Perp Orderbook Scraper',
        category: 'CEX',
        targetUrl: 'wss://stream.binance.com:9443/ws/!bookTicker',
        recordsExtracted: Math.floor(48200 + Math.random() * 4500) * (workers / 12),
        recordsPerSec: Number((1840 + Math.random() * 210).toFixed(1)),
        parseSuccessRate: Number((99.92 + Math.random() * 0.07).toFixed(2)),
        latencyMs: Math.floor(9 + Math.random() * 6),
        anomaliesDetected: Math.floor(Math.random() * 3),
        aggregatedSentiment: Number((0.68 + (Math.random() - 0.5) * 0.12).toFixed(2)),
        dominantSignal: 'ORDERBOOK_IMBALANCE_BULL',
        status: 'Nominal',
      },
      {
        id: 'src-uniswap-v3',
        sourceName: 'Uniswap V3 Subgraph & Mempool Crawler',
        category: 'DEX',
        targetUrl: 'https://arb1.arbitrum.io/rpc#uniswap-v3-indexer',
        recordsExtracted: Math.floor(29400 + Math.random() * 3200) * (workers / 12),
        recordsPerSec: Number((960 + Math.random() * 140).toFixed(1)),
        parseSuccessRate: Number((99.78 + Math.random() * 0.18).toFixed(2)),
        latencyMs: Math.floor(14 + Math.random() * 9),
        anomaliesDetected: Math.floor(Math.random() * 4),
        aggregatedSentiment: Number((0.74 + (Math.random() - 0.5) * 0.14).toFixed(2)),
        dominantSignal: 'QAOA_FLASH_SPREAD_READY',
        status: 'Nominal',
      },
      {
        id: 'src-etherscan-whale',
        sourceName: 'Etherscan + Arbitrum Whale Wallet Scraper',
        category: 'ONCHAIN',
        targetUrl: 'https://api.etherscan.io/v2/api?module=account',
        recordsExtracted: Math.floor(15800 + Math.random() * 1900) * (workers / 12),
        recordsPerSec: Number((510 + Math.random() * 85).toFixed(1)),
        parseSuccessRate: Number((99.45 + Math.random() * 0.4).toFixed(2)),
        latencyMs: Math.floor(22 + Math.random() * 12),
        anomaliesDetected: Math.floor(1 + Math.random() * 5),
        aggregatedSentiment: Number((0.52 + (Math.random() - 0.5) * 0.2).toFixed(2)),
        dominantSignal: 'WHALE_ACCUMULATION_SOL',
        status: 'Nominal',
      },
      {
        id: 'src-coingecko-agg',
        sourceName: 'CoinGecko & DEXScreener Liquidity Aggregator',
        category: 'SENTIMENT',
        targetUrl: 'https://api.coingecko.com/api/v3/coins/markets',
        recordsExtracted: Math.floor(21600 + Math.random() * 2400) * (workers / 12),
        recordsPerSec: Number((740 + Math.random() * 95).toFixed(1)),
        parseSuccessRate: Number((99.85 + Math.random() * 0.12).toFixed(2)),
        latencyMs: Math.floor(18 + Math.random() * 10),
        anomaliesDetected: Math.floor(Math.random() * 2),
        aggregatedSentiment: Number((0.79 + (Math.random() - 0.5) * 0.1).toFixed(2)),
        dominantSignal: 'VOLATILITY_BREAKOUT_ARB',
        status: 'Nominal',
      },
      {
        id: 'src-curve-1inch',
        sourceName: 'Curve 3Pool + 1inch Pathfinder Scraper',
        category: 'DEX',
        targetUrl: 'https://api.1inch.dev/swap/v6.0/42161/quote',
        recordsExtracted: Math.floor(26100 + Math.random() * 2800) * (workers / 12),
        recordsPerSec: Number((890 + Math.random() * 110).toFixed(1)),
        parseSuccessRate: Number((98.95 + Math.random() * 0.8).toFixed(2)),
        latencyMs: Math.floor(16 + Math.random() * 11),
        anomaliesDetected: Math.floor(Math.random() * 3),
        aggregatedSentiment: Number((0.64 + (Math.random() - 0.5) * 0.15).toFixed(2)),
        dominantSignal: 'STABLE_PEG_ARBITRAGE',
        status: 'Nominal',
      },
      {
        id: 'src-fin-news-nlp',
        sourceName: 'FocusCrawl Macro & SEC Filing Scraper',
        category: 'SENTIMENT',
        targetUrl: 'https://focuscrawl.si/crawlers/sec-edgar-stream',
        recordsExtracted: Math.floor(9400 + Math.random() * 1200) * (workers / 12),
        recordsPerSec: Number((320 + Math.random() * 55).toFixed(1)),
        parseSuccessRate: Number((99.6 + Math.random() * 0.3).toFixed(2)),
        latencyMs: Math.floor(27 + Math.random() * 14),
        anomaliesDetected: Math.floor(Math.random() * 2),
        aggregatedSentiment: Number((0.61 + (Math.random() - 0.5) * 0.16).toFixed(2)),
        dominantSignal: 'ETF_FLOW_POSITIVE',
        status: 'Nominal',
      },
    ];

    const filteredSources =
      category === 'ALL'
        ? baseSources
        : baseSources.filter((s) => s.category === category);

    const totalRecords = filteredSources.reduce(
      (acc, s) => acc + Math.round(s.recordsExtracted),
      0
    );
    const totalThroughput = filteredSources.reduce(
      (acc, s) => acc + s.recordsPerSec,
      0
    );
    const avgParseRate =
      filteredSources.reduce((acc, s) => acc + s.parseSuccessRate, 0) /
      Math.max(1, filteredSources.length);
    const avgLatency = Math.round(
      filteredSources.reduce((acc, s) => acc + s.latencyMs, 0) /
        Math.max(1, filteredSources.length)
    );

    const payload = {
      ok: true,
      service: 'borsignature.com Aggregated Scraping & Data Analysis Engine',
      endpoint: '/api/borsignature/scraping-analysis',
      timestamp: now,
      window,
      activeWorkers: workers,
      categoryFilter: category,
      targetSource,
      telemetrySummary: {
        totalRecordsScraped: totalRecords,
        throughputRecordsPerSec: Number(totalThroughput.toFixed(1)),
        schemaIntegrityPct: Number(avgParseRate.toFixed(2)),
        avgCrawlerLatencyMs: avgLatency,
        deduplicationRatioPct: 99.42,
      },
      sources: filteredSources.map((s) => ({
        ...s,
        recordsExtracted: Math.round(s.recordsExtracted),
      })),
    };

    apiLogs.unshift({
      id: `req-${Date.now()}`,
      endpoint: '/api/borsignature/scraping-analysis',
      method: 'POST',
      timestamp: now,
      status: 200,
      summary: `Scraped & aggregated ${totalRecords.toLocaleString()} records across ${filteredSources.length} pipelines (${category})`,
    });

    res.status(200).json(payload);
  });

  // 5. Inspect recent API calls
  app.get('/api/borsignature/logs', (_req, res) => {
    res.json({
      ok: true,
      logs: apiLogs.slice(0, 15),
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
