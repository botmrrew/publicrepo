# Bot Signature — Dashboard Administrativo & Data Analyser

Aplicação administrativa completa em português brasileiro construída a partir do projeto Data Analyser, preservando sua identidade visual, componentes analíticos e suporte a relatórios executivos em PDF/JSON.

---

## 1. Áreas Implementadas e Alterações Documentadas

1. **Visão geral (`/api/admin/overview`)**
   - Exibe contadores de tarefas **pendentes**, **em processamento**, **concluídas** e **com falha**.
   - Calcula em tempo real o **armazenamento utilizado** em disco (`/output/scraping` e `/output/originals`) e o **horário da última atualização**.
   - Sinaliza explicitamente quando há **Dados de exemplo** ao lado de dados reais.

2. **Pipeline de coleta (`/v1/scraping/jobs`)**
   - Implementa e reaproveita os contratos REST:
     - `POST /v1/scraping/jobs`: Cadastro de URL, identificação, formato e limite de tentativas.
     - `GET /v1/scraping/jobs`: Listagem e filtragem por estado da tarefa.
     - `GET /v1/scraping/jobs/{job_id}`: Inspeção detalhada de tentativas, erros HTTP, cabeçalhos e prévia do conteúdo.
     - `GET /v1/scraping/jobs/{job_id}/download`: Download autenticado do artefato com cabeçalho `X-Artifact-SHA256`.

3. **Analisador de dados (`/api/datasets/*`)**
   - Suporte nativo para importação de arquivos **CSV** e **XLSX** (Excel).
   - **Preservação integral dos arquivos originais**: cada arquivo importado é salvo intacto em `/output/originals` com hash **SHA-256** e pode ser baixado a qualquer momento sem alterações.
   - Diagnóstico automático de **valores ausentes** (por coluna e por linha) e **registros duplicados**.
   - Filtros compostos não destrutivos e construtor de gráficos interativos em SVG (**Barras**, **Linhas**, **Dispersão** e **Proporção/Pizza**).

4. **Monitor financeiro (`/api/finance/*`)**
   - Apresenta ativos, fonte, preço, variação 24h e horário da observação.
   - Diferencia visualmente e por filtro:
     - **Dados coletados** (obtidos em tempo real de APIs públicas como AwesomeAPI e BCB SGS ou via pipeline de scraping);
     - **Snapshots importados** (originados de planilhas CSV/XLSX do Analisador de Dados);
     - **Itens aguardando coleta** (cadastrados na fila para próxima execução).

5. **Integrações (`/api/integrations/status`)**
   - Exibe a configuração e o estado verificado de cada serviço no servidor.
   - Quando uma variável ou credencial externa não está configurada (ex: `VERTEX_PROJECT_ID`, `GCS_BUCKET_NAME`, `CLOUDFLARE_R2_BUCKET`), apresenta explicitamente **“Configuração pendente”**.

6. **Assistente de análise (`/api/ai/analyze-on-demand` e `/api/analyze`)**
   - Mantém a camada de IA desacoplada da interface (`server/lib/aiService.ts` e `server/lib/agentClient.ts`), com provedor (`AI_PROVIDER=gemini|vertex|managed-agent`) e modelo (`AI_MODEL`) configuráveis no servidor.
   - **Chamadas de IA ocorrem somente quando o administrador solicita explicitamente uma análise**. Atualizações comuns do dashboard consultam apenas os dados armazenados.
   - Preserva integralmente o modo de **Sandbox Python Autônomo** e a exportação executiva em PDF/JSON.

---

## 2. Segurança e Centralização de API

- **Autenticação obrigatória**: Todas as rotas administrativas (`/api/admin/*`, `/v1/scraping/*`, `/api/datasets/*`, `/api/finance/*`, `/api/integrations/*`, `/api/ai/*`, `/api/analyze`, `/api/upload`) são protegidas pelo middleware `requireAdminAuth` via token HMAC assinado no servidor (`Authorization: Bearer <token>`).
- **Credenciais exclusivas no servidor**: Nenhuma chave (`GEMINI_API_KEY`, `BOT_SIGNATURE_ADMIN_PASSWORD`, `UPSTREAM_SCRAPING_API_TOKEN`) é exposta ao cliente.
- **Endereço da API centralizado**: Todas as chamadas do frontend passam por `src/config/api.ts` (`VITE_API_BASE_URL`).

---

## 3. Como Executar Localmente

1. Instale as dependências:
   ```bash
   npm install
   ```

2. Configure as variáveis de ambiente copiando `.env.example` para `.env.local`:
   ```bash
   cp .env.example .env.local
   ```
   Edite `.env.local` para definir `BOT_SIGNATURE_ADMIN_EMAIL`, `BOT_SIGNATURE_ADMIN_PASSWORD` e `GEMINI_API_KEY`.

3. Inicie o servidor de desenvolvimento (Express + Vite na porta 3000):
   ```bash
   npm run dev
   ```

4. Para gerar o build de produção:
   ```bash
   npm run build
   npm start
   ```

---

## 4. Preparação para Publicação na Cloudflare

O projeto inclui o arquivo `wrangler.toml` pré-configurado para publicação do frontend e integração com recursos de borda da Cloudflare:

1. **Build dos ativos estáticos**:
   ```bash
   npm run build
   ```
   O diretório `dist/` conterá o bundle otimizado do SPA.

2. **Configuração de Segredos no Cloudflare Workers / Pages**:
   Nunca armazene senhas ou chaves no `wrangler.toml`. Utilize o CLI do Wrangler:
   ```bash
   npx wrangler secret put BOT_SIGNATURE_ADMIN_PASSWORD
   npx wrangler secret put BOT_SIGNATURE_SESSION_SECRET
   npx wrangler secret put GEMINI_API_KEY
   ```

3. **Publicação no Cloudflare Pages**:
   ```bash
   npx wrangler pages deploy dist --project-name bot-signature-admin-dashboard
   ```

4. **Backend API & Armazenamento (R2 / D1)**:
   - Caso o backend Node/Express seja hospedado em um serviço externo (ex: Cloud Run / container Cloudflare), defina `VITE_API_BASE_URL="https://api.seudominio.com.br"` antes do `npm run build`.
   - Para vincular buckets **Cloudflare R2** (artefatos de scraping e planilhas originais) e **Cloudflare D1** (metadados de jobs), descomente os blocos `[[r2_buckets]]` e `[[d1_databases]]` em `wrangler.toml` e informe `CLOUDFLARE_ACCOUNT_ID`, `CLOUDFLARE_R2_BUCKET` e `CLOUDFLARE_D1_DATABASE_ID` nas variáveis do servidor.
