import React, { useState, useEffect, useCallback } from 'react';
import type { FinancialObservation, FinancialOriginType } from '../types';
import { API_CONFIG, apiFetch } from '../config/api';
import { formatDateTimePtBR } from './OverviewSection';
import {
  RefreshCw,
  Plus,
  TrendingUp,
  TrendingDown,
  Clock,
  CheckCircle2,
  FileSpreadsheet,
  Loader2,
  AlertCircle,
} from 'lucide-react';

interface FinancialMonitorSectionProps {
  onFinanceChanged?: () => void;
}

function originMeta(origin: FinancialOriginType): {
  label: string;
  description: string;
  textClass: string;
} {
  switch (origin) {
    case 'collected':
      return {
        label: 'Dados coletados',
        description: 'Obtido diretamente da fonte via coletor HTTP / API',
        textClass: 'text-emerald-700 font-semibold',
      };
    case 'imported_snapshot':
      return {
        label: 'Snapshot importado',
        description: 'Registro estático importado de planilha CSV/XLSX',
        textClass: 'text-io-blue font-semibold',
      };
    case 'awaiting_collection':
      return {
        label: 'Aguardando coleta',
        description: 'Ativo cadastrado na fila aguardando execução do coletor',
        textClass: 'text-amber-700 font-semibold',
      };
  }
}

export const FinancialMonitorSection: React.FC<FinancialMonitorSectionProps> = ({
  onFinanceChanged,
}) => {
  const [assets, setAssets] = useState<FinancialObservation[]>([]);
  const [loading, setLoading] = useState(true);
  const [collecting, setCollecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [originFilter, setOriginFilter] = useState<'all' | FinancialOriginType>('all');

  // Form state for adding new monitored asset
  const [symbol, setSymbol] = useState('');
  const [name, setName] = useState('');
  const [source, setSource] = useState('AwesomeAPI / B3 Feed');
  const [priceInput, setPriceInput] = useState('');
  const [originInput, setOriginInput] = useState<FinancialOriginType>('awaiting_collection');
  const [adding, setAdding] = useState(false);

  const fetchAssets = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<{ assets: FinancialObservation[] }>(
        API_CONFIG.endpoints.financeAssets,
      );
      setAssets(res.assets || []);
    } catch (err: any) {
      setError(err?.message || 'Erro ao carregar ativos do Monitor Financeiro.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAssets();
  }, [fetchAssets]);

  const handleCollectLiveQuotes = async () => {
    setCollecting(true);
    setError(null);
    try {
      const res = await apiFetch<{
        message: string;
        updatedCount: number;
        assets: FinancialObservation[];
      }>(API_CONFIG.endpoints.financeCollect, {
        method: 'POST',
      });
      setAssets(res.assets || []);
      setToast(res.message);
      setTimeout(() => setToast(null), 4500);
      onFinanceChanged?.();
    } catch (err: any) {
      setError(err?.message || 'Falha ao coletar cotações em tempo real.');
    } finally {
      setCollecting(false);
    }
  };

  const handleAddAsset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!symbol.trim()) return;
    setAdding(true);
    setError(null);
    try {
      const res = await apiFetch<{ assets: FinancialObservation[] }>(
        API_CONFIG.endpoints.financeAssets,
        {
          method: 'POST',
          body: JSON.stringify({
            symbol: symbol.trim(),
            name: name.trim() || symbol.trim(),
            source: source.trim(),
            price: priceInput.trim() ? Number(priceInput) : null,
            originType: originInput,
          }),
        },
      );
      setAssets(res.assets || []);
      setSymbol('');
      setName('');
      setPriceInput('');
      setToast('Ativo registrado no Monitor Financeiro.');
      setTimeout(() => setToast(null), 3500);
      onFinanceChanged?.();
    } catch (err: any) {
      setError(err?.message || 'Erro ao adicionar ativo.');
    } finally {
      setAdding(false);
    }
  };

  const collectedCount = assets.filter((a) => a.originType === 'collected').length;
  const snapshotCount = assets.filter((a) => a.originType === 'imported_snapshot').length;
  const awaitingCount = assets.filter((a) => a.originType === 'awaiting_collection').length;

  const filteredAssets = assets.filter((a) =>
    originFilter === 'all' ? true : a.originType === originFilter,
  );

  return (
    <div className="space-y-6">
      {/* Cabeçalho e Ação de Coleta Real */}
      <section className="rounded-2xl border border-neutral-200 bg-white p-5 sm:p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-500">
              <span>Rastreabilidade de Origem</span>
              <span aria-hidden="true">·</span>
              <span>Dados coletados vs. Snapshots importados vs. Aguardando coleta</span>
            </div>
            <h1 className="mt-1.5 text-2xl sm:text-3xl font-semibold tracking-tight text-neutral-900">
              Monitor financeiro
            </h1>
            <p className="mt-1 text-sm text-neutral-600 max-w-2xl">
              Monitore ativos, câmbio, taxas e índices com identificação explícita da fonte, preço observado e carimbo de tempo da coleta ou importação.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={fetchAssets}
              disabled={loading}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl border border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-xs font-semibold text-neutral-800 transition cursor-pointer"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
              Recarregar
            </button>
            <button
              type="button"
              onClick={handleCollectLiveQuotes}
              disabled={collecting}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold transition cursor-pointer disabled:opacity-50"
            >
              {collecting ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <TrendingUp className="h-3.5 w-3.5 text-io-green" />
              )}
              Coletar cotações reais agora (AwesomeAPI / BCB)
            </button>
          </div>
        </div>

        {toast && (
          <div className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs font-medium text-emerald-900 flex items-center justify-between">
            <span>{toast}</span>
            <button
              onClick={() => setToast(null)}
              className="text-emerald-700 font-semibold ml-4 cursor-pointer"
            >
              Fechar
            </button>
          </div>
        )}

        {error && (
          <div className="mt-4 rounded-xl border border-io-red/30 bg-red-50 px-4 py-2.5 text-xs font-medium text-io-red flex items-center gap-2">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </section>

      {/* Cards de Diferenciação de Origem */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-2xl border border-neutral-200 bg-white p-5">
          <div className="flex items-center justify-between text-xs text-neutral-500">
            <span className="font-semibold text-emerald-700">1. Dados coletados</span>
            <CheckCircle2 className="h-4 w-4 text-emerald-600" />
          </div>
          <div className="my-2 text-3xl font-semibold font-mono tabular-nums text-neutral-900">
            {collectedCount}
          </div>
          <p className="text-xs text-neutral-500">
            Ativos com preço obtido diretamente pelo coletor HTTP ou pipeline de scraping com horário verificado.
          </p>
        </div>

        <div className="rounded-2xl border border-neutral-200 bg-white p-5">
          <div className="flex items-center justify-between text-xs text-neutral-500">
            <span className="font-semibold text-io-blue">2. Snapshots importados</span>
            <FileSpreadsheet className="h-4 w-4 text-io-blue" />
          </div>
          <div className="my-2 text-3xl font-semibold font-mono tabular-nums text-neutral-900">
            {snapshotCount}
          </div>
          <p className="text-xs text-neutral-500">
            Registros originados de planilhas CSV/XLSX importadas no Analisador de Dados ou inseridos como fotografia estática.
          </p>
        </div>

        <div className="rounded-2xl border border-neutral-200 bg-white p-5">
          <div className="flex items-center justify-between text-xs text-neutral-500">
            <span className="font-semibold text-amber-700">3. Itens aguardando coleta</span>
            <Clock className="h-4 w-4 text-amber-600" />
          </div>
          <div className="my-2 text-3xl font-semibold font-mono tabular-nums text-neutral-900">
            {awaitingCount}
          </div>
          <p className="text-xs text-neutral-500">
            Ativos monitorados na fila que ainda aguardam execução da próxima janela de coleta.
          </p>
        </div>
      </section>

      {/* Formulário rápido para adicionar item ao Monitor */}
      <section className="rounded-2xl border border-neutral-200 bg-white p-5 sm:p-6">
        <h2 className="text-base font-semibold text-neutral-900 mb-3">
          Adicionar ativo ao monitor
        </h2>
        <form onSubmit={handleAddAsset} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3">
          <div className="lg:col-span-2">
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Símbolo / Ticker *
            </label>
            <input
              type="text"
              required
              value={symbol}
              onChange={(e) => setSymbol(e.target.value)}
              placeholder="Ex: BBAS3"
              className="w-full px-3 py-2 text-xs rounded-xl border border-neutral-300 focus:border-io-blue outline-none font-mono uppercase"
            />
          </div>

          <div className="lg:col-span-3">
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Nome do ativo
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Ex: Banco do Brasil ON"
              className="w-full px-3 py-2 text-xs rounded-xl border border-neutral-300 focus:border-io-blue outline-none"
            />
          </div>

          <div className="lg:col-span-3">
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Fonte declarada
            </label>
            <input
              type="text"
              value={source}
              onChange={(e) => setSource(e.target.value)}
              placeholder="Ex: B3 Feed / Planilha Conciliação"
              className="w-full px-3 py-2 text-xs rounded-xl border border-neutral-300 focus:border-io-blue outline-none"
            />
          </div>

          <div className="lg:col-span-2">
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Classificação de origem
            </label>
            <select
              value={originInput}
              onChange={(e) => setOriginInput(e.target.value as FinancialOriginType)}
              className="w-full px-2.5 py-2 text-xs rounded-xl border border-neutral-300 bg-white outline-none"
            >
              <option value="awaiting_collection">Aguardando coleta</option>
              <option value="imported_snapshot">Snapshot importado</option>
              <option value="collected">Dado coletado</option>
            </select>
          </div>

          <div className="lg:col-span-2 flex items-end gap-2">
            <div className="flex-1">
              <label className="block text-xs font-medium text-neutral-700 mb-1">
                Preço (opcional)
              </label>
              <input
                type="number"
                step="any"
                value={priceInput}
                onChange={(e) => setPriceInput(e.target.value)}
                placeholder="0.00"
                className="w-full px-3 py-2 text-xs rounded-xl border border-neutral-300 focus:border-io-blue outline-none font-mono"
              />
            </div>
            <button
              type="submit"
              disabled={adding}
              className="px-3.5 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
            >
              <Plus className="h-3.5 w-3.5" />
              Incluir
            </button>
          </div>
        </form>
      </section>

      {/* Tabela Principal do Monitor Financeiro */}
      <section className="rounded-2xl border border-neutral-200 bg-white overflow-hidden">
        <div className="px-5 py-4 border-b border-neutral-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-neutral-900">
              Ativos e observações ({filteredAssets.length})
            </h2>
            <p className="text-xs text-neutral-500">
              Filtre por natureza do registro para auditar dados coletados, snapshots importados ou itens na fila.
            </p>
          </div>

          <div className="flex items-center gap-1 p-1 bg-neutral-100 rounded-xl self-start sm:self-center">
            {(
              [
                { id: 'all', label: `Todos (${assets.length})` },
                { id: 'collected', label: `Dados coletados (${collectedCount})` },
                { id: 'imported_snapshot', label: `Snapshots importados (${snapshotCount})` },
                { id: 'awaiting_collection', label: `Aguardando coleta (${awaitingCount})` },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setOriginFilter(tab.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition whitespace-nowrap cursor-pointer ${
                  originFilter === tab.id
                    ? 'bg-white text-neutral-900 shadow-2xs'
                    : 'text-neutral-600 hover:text-neutral-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-600">
              <tr>
                <th className="py-3 px-4 font-semibold">Ativo</th>
                <th className="py-3 px-3 font-semibold">Classificação / Origem</th>
                <th className="py-3 px-3 font-semibold">Fonte</th>
                <th className="py-3 px-3 font-semibold text-right">Preço Observado</th>
                <th className="py-3 px-3 font-semibold text-right">Variação 24h</th>
                <th className="py-3 px-4 font-semibold text-right">Horário da Observação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {loading && assets.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-10 text-center text-neutral-500">
                    Carregando monitor financeiro...
                  </td>
                </tr>
              ) : filteredAssets.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-10 text-center text-neutral-500">
                    Nenhum ativo encontrado para esta categoria.
                  </td>
                </tr>
              ) : (
                filteredAssets.map((item) => {
                  const meta = originMeta(item.originType);
                  return (
                    <tr key={item.id} className="hover:bg-neutral-50/80 transition">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono font-semibold text-neutral-900">
                            {item.symbol}
                          </span>
                          <span className="text-neutral-400">·</span>
                          <span className="text-neutral-700 font-medium">
                            {item.name}
                          </span>
                        </div>
                        <div className="text-[11px] text-neutral-400 mt-0.5">
                          {item.category}
                          {item.is_sample ? ' · Dados de exemplo' : ' · Registro verificado'}
                        </div>
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap">
                        <div className={meta.textClass}>{meta.label}</div>
                        <div className="text-[11px] text-neutral-400">
                          {item.notes || meta.description}
                        </div>
                      </td>

                      <td className="py-3 px-3 text-neutral-700 max-w-[220px] truncate">
                        {item.source}
                      </td>

                      <td className="py-3 px-3 text-right font-mono tabular-nums whitespace-nowrap">
                        {item.price !== null ? (
                          <span className="font-semibold text-neutral-900">
                            {item.currency === 'BRL' ? 'R$ ' : ''}
                            {item.price.toLocaleString('pt-BR', {
                              minimumFractionDigits: item.price < 10 ? 3 : 2,
                              maximumFractionDigits: 4,
                            })}
                            {item.currency === 'PCT' ? '% a.a.' : ''}
                          </span>
                        ) : (
                          <span className="text-amber-700 italic">
                            Aguardando coleta
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-3 text-right font-mono tabular-nums whitespace-nowrap">
                        {item.changePercent24h !== null ? (
                          <span
                            className={`inline-flex items-center gap-0.5 font-medium ${
                              item.changePercent24h > 0
                                ? 'text-emerald-700'
                                : item.changePercent24h < 0
                                  ? 'text-io-red'
                                  : 'text-neutral-600'
                            }`}
                          >
                            {item.changePercent24h > 0 ? (
                              <TrendingUp className="h-3 w-3" />
                            ) : item.changePercent24h < 0 ? (
                              <TrendingDown className="h-3 w-3" />
                            ) : null}
                            {item.changePercent24h > 0 ? '+' : ''}
                            {item.changePercent24h.toFixed(2)}%
                          </span>
                        ) : (
                          <span className="text-neutral-400">—</span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right font-mono tabular-nums text-neutral-600 whitespace-nowrap">
                        {item.observedAt
                          ? formatDateTimePtBR(item.observedAt)
                          : 'Pendente na fila'}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
