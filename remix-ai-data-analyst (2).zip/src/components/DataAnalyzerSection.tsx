import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import type { StoredDatasetMeta } from '../types';
import {
  API_CONFIG,
  apiFetch,
  downloadAuthenticatedBlob,
  getStoredAdminToken,
  resolveApiUrl,
} from '../config/api';
import { formatBytes, formatDateTimePtBR } from './OverviewSection';
import {
  Upload,
  FileSpreadsheet,
  Download,
  Filter,
  BarChart3,
  AlertTriangle,
  Copy,
  CheckCircle2,
  Loader2,
  Sparkles,
  TrendingUp,
} from 'lucide-react';

interface DataAnalyzerSectionProps {
  onDatasetsChanged?: () => void;
  onOpenInAssistant?: (dataset: StoredDatasetMeta, csvContent: string) => void;
  onSendToFinanceMonitor?: () => void;
}

type FilterOperator =
  | 'all'
  | 'contains'
  | 'equals'
  | 'gt'
  | 'lt'
  | 'missing_only'
  | 'non_missing';

type ChartType = 'bar' | 'line' | 'scatter' | 'pie';
type AggregationFn = 'sum' | 'avg' | 'count' | 'max' | 'min';

export const DataAnalyzerSection: React.FC<DataAnalyzerSectionProps> = ({
  onDatasetsChanged,
  onOpenInAssistant,
  onSendToFinanceMonitor,
}) => {
  const [datasets, setDatasets] = useState<StoredDatasetMeta[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loadingList, setLoadingList] = useState(true);
  const [loadingDataset, setLoadingDataset] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  // Active dataset content
  const [activeMeta, setActiveMeta] = useState<StoredDatasetMeta | null>(null);
  const [columns, setColumns] = useState<string[]>([]);
  const [rows, setRows] = useState<Array<Record<string, any>>>([]);
  const [rawCsvContent, setRawCsvContent] = useState<string>('');

  // Table & Quality Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [filterColumn, setFilterColumn] = useState<string>('');
  const [filterOp, setFilterOp] = useState<FilterOperator>('all');
  const [filterVal, setFilterVal] = useState('');
  const [duplicateMode, setDuplicateMode] = useState<'all' | 'only_duplicates' | 'hide_duplicates'>('all');
  const [missingRowMode, setMissingRowMode] = useState<'all' | 'only_missing' | 'hide_missing'>('all');

  // Chart Builder State
  const [chartType, setChartType] = useState<ChartType>('bar');
  const [chartXCol, setChartXCol] = useState<string>('');
  const [chartYCol, setChartYCol] = useState<string>('');
  const [chartAgg, setChartAgg] = useState<AggregationFn>('sum');

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const loadDatasetsList = useCallback(async () => {
    setLoadingList(true);
    try {
      const res = await apiFetch<{ datasets: StoredDatasetMeta[] }>(
        API_CONFIG.endpoints.datasets,
      );
      const list = res.datasets || [];
      setDatasets(list);
      if (list.length > 0 && !selectedId) {
        setSelectedId(list[0].id);
      }
    } catch (err: any) {
      setError(err?.message || 'Erro ao listar arquivos do Analisador.');
    } finally {
      setLoadingList(false);
    }
  }, [selectedId]);

  useEffect(() => {
    loadDatasetsList();
  }, [loadDatasetsList]);

  const loadDatasetDetail = useCallback(async (id: string) => {
    setLoadingDataset(true);
    setError(null);
    try {
      const res = await apiFetch<{
        dataset: StoredDatasetMeta;
        columns: string[];
        rows: Array<Record<string, any>>;
        csvContent: string;
      }>(API_CONFIG.endpoints.datasetDetail(id));

      setActiveMeta(res.dataset);
      setColumns(res.columns || []);
      setRows(res.rows || []);
      setRawCsvContent(res.csvContent || '');

      if (res.columns && res.columns.length > 0) {
        setFilterColumn(res.columns[0]);
        setChartXCol(res.columns[0]);
        // Pick first numeric column for Y axis
        const numCol = res.columns.find((col) =>
          res.rows.some((r) => r[col] !== null && !isNaN(Number(r[col]))),
        );
        setChartYCol(numCol || res.columns[Math.min(1, res.columns.length - 1)]);
      }
    } catch (err: any) {
      setError(err?.message || 'Falha ao carregar dados da planilha.');
    } finally {
      setLoadingDataset(false);
    }
  }, []);

  useEffect(() => {
    if (selectedId) {
      loadDatasetDetail(selectedId);
    }
  }, [selectedId, loadDatasetDetail]);

  const handleFileUpload = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    const file = fileList[0];
    if (!/\.(csv|xlsx|xls)$/i.test(file.name)) {
      setError('Selecione um arquivo com extensão .CSV ou .XLSX.');
      return;
    }

    setUploading(true);
    setError(null);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const token = getStoredAdminToken();
      const response = await fetch(
        resolveApiUrl(API_CONFIG.endpoints.datasetUpload),
        {
          method: 'POST',
          headers: token ? { Authorization: `Bearer ${token}` } : undefined,
          body: formData,
        },
      );

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `Falha no upload (${response.status})`);
      }

      const data = await response.json();
      const uploadedMeta: StoredDatasetMeta = data.dataset;
      setToast(
        `Arquivo "${uploadedMeta.originalName}" importado e preservado com SHA-256 (${formatBytes(
          uploadedMeta.sizeBytes,
        )}).`,
      );
      setTimeout(() => setToast(null), 4500);

      await loadDatasetsList();
      setSelectedId(uploadedMeta.id);
      onDatasetsChanged?.();
    } catch (err: any) {
      setError(err?.message || 'Erro durante a importação do arquivo.');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDownloadOriginal = async () => {
    if (!activeMeta) return;
    try {
      await downloadAuthenticatedBlob(
        API_CONFIG.endpoints.datasetDownload(activeMeta.id),
        activeMeta.originalName,
      );
      setToast(`Arquivo original "${activeMeta.originalName}" baixado intacto.`);
      setTimeout(() => setToast(null), 3500);
    } catch (err: any) {
      setError(err?.message || 'Erro ao baixar arquivo original.');
    }
  };

  const handleImportToFinanceMonitor = async () => {
    if (!activeMeta) return;
    try {
      const res = await apiFetch<{ importedCount: number }>(
        API_CONFIG.endpoints.financeImportDataset,
        {
          method: 'POST',
          body: JSON.stringify({ datasetId: activeMeta.id }),
        },
      );
      setToast(
        `${res.importedCount} registros enviados como Snapshot Importado para o Monitor Financeiro.`,
      );
      setTimeout(() => setToast(null), 4000);
      onSendToFinanceMonitor?.();
    } catch (err: any) {
      setError(err?.message || 'Erro ao enviar snapshot ao Monitor Financeiro.');
    }
  };

  // Diagnóstico detalhado de valores ausentes e duplicados por linha e por coluna
  const rowDiagnostics = useMemo(() => {
    const sigCounts = new Map<string, number>();
    const rowSignatures: string[] = [];
    const rowHasMissing: boolean[] = [];
    const colMissingCounts: Record<string, number> = {};
    columns.forEach((c) => {
      colMissingCounts[c] = 0;
    });

    rows.forEach((row) => {
      let hasMissing = false;
      const parts: string[] = [];
      columns.forEach((c) => {
        const v = row[c];
        if (v === null || v === undefined || String(v).trim() === '') {
          hasMissing = true;
          colMissingCounts[c] = (colMissingCounts[c] || 0) + 1;
          parts.push('__NULL__');
        } else {
          parts.push(String(v).trim());
        }
      });
      const sig = parts.join('||');
      rowSignatures.push(sig);
      rowHasMissing.push(hasMissing);
      sigCounts.set(sig, (sigCounts.get(sig) || 0) + 1);
    });

    const isDuplicateRow = rowSignatures.map((sig, idx) => {
      // Marca como duplicada toda ocorrência que aparece mais de 1 vez
      return (sigCounts.get(sig) || 0) > 1;
    });

    // Para "ocultar duplicados", mantém a primeira ocorrência
    const seenOnce = new Set<string>();
    const isSubsequentDuplicate = rowSignatures.map((sig) => {
      if (seenOnce.has(sig)) return true;
      seenOnce.add(sig);
      return false;
    });

    return {
      isDuplicateRow,
      isSubsequentDuplicate,
      rowHasMissing,
      colMissingCounts,
      totalMissingCells: Object.values(colMissingCounts).reduce((a, b) => a + b, 0),
      totalDuplicateRows: isSubsequentDuplicate.filter(Boolean).length,
      rowsWithMissingCount: rowHasMissing.filter(Boolean).length,
    };
  }, [rows, columns]);

  // Linhas filtradas (sem alterar o arquivo original)
  const filteredRowsWithMeta = useMemo(() => {
    return rows
      .map((row, idx) => ({
        row,
        originalIndex: idx + 1,
        isDuplicate: rowDiagnostics.isDuplicateRow[idx],
        isSubsequentDuplicate: rowDiagnostics.isSubsequentDuplicate[idx],
        hasMissing: rowDiagnostics.rowHasMissing[idx],
      }))
      .filter((item) => {
        if (duplicateMode === 'only_duplicates' && !item.isDuplicate) return false;
        if (duplicateMode === 'hide_duplicates' && item.isSubsequentDuplicate)
          return false;

        if (missingRowMode === 'only_missing' && !item.hasMissing) return false;
        if (missingRowMode === 'hide_missing' && item.hasMissing) return false;

        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchAny = columns.some((c) => {
            const val = item.row[c];
            return val !== null && val !== undefined && String(val).toLowerCase().includes(q);
          });
          if (!matchAny) return false;
        }

        if (filterColumn && filterOp !== 'all') {
          const cellVal = item.row[filterColumn];
          const isNull =
            cellVal === null || cellVal === undefined || String(cellVal).trim() === '';
          if (filterOp === 'missing_only') return isNull;
          if (filterOp === 'non_missing') return !isNull;
          if (isNull) return false;

          const strCell = String(cellVal).toLowerCase();
          const strTarget = filterVal.toLowerCase().trim();
          if (filterOp === 'contains') return strCell.includes(strTarget);
          if (filterOp === 'equals') return strCell === strTarget;
          if (filterOp === 'gt') return Number(cellVal) > Number(filterVal);
          if (filterOp === 'lt') return Number(cellVal) < Number(filterVal);
        }

        return true;
      });
  }, [
    rows,
    columns,
    rowDiagnostics,
    duplicateMode,
    missingRowMode,
    searchQuery,
    filterColumn,
    filterOp,
    filterVal,
  ]);

  // Dados agregados para o construtor de gráficos
  const chartSeries = useMemo(() => {
    if (!chartXCol || filteredRowsWithMeta.length === 0) return [];
    const groups = new Map<string, number[]>();

    for (const { row } of filteredRowsWithMeta) {
      const rawX = row[chartXCol];
      const key =
        rawX === null || rawX === undefined || String(rawX).trim() === ''
          ? '(Ausente)'
          : String(rawX).trim();

      const rawY = chartYCol ? row[chartYCol] : 1;
      const numY = Number(rawY);

      if (!groups.has(key)) groups.set(key, []);
      if (chartAgg === 'count') {
        groups.get(key)!.push(1);
      } else if (rawY !== null && rawY !== undefined && !isNaN(numY)) {
        groups.get(key)!.push(numY);
      }
    }

    const result: Array<{ label: string; value: number; xNum?: number }> = [];
    for (const [label, vals] of groups.entries()) {
      if (vals.length === 0) continue;
      let aggVal = 0;
      if (chartAgg === 'count') aggVal = vals.length;
      else if (chartAgg === 'sum') aggVal = vals.reduce((a, b) => a + b, 0);
      else if (chartAgg === 'avg')
        aggVal = vals.reduce((a, b) => a + b, 0) / vals.length;
      else if (chartAgg === 'max') aggVal = Math.max(...vals);
      else if (chartAgg === 'min') aggVal = Math.min(...vals);

      result.push({
        label,
        value: Number(aggVal.toFixed(2)),
        xNum: !isNaN(Number(label)) ? Number(label) : undefined,
      });
    }

    return result.slice(0, 18);
  }, [filteredRowsWithMeta, chartXCol, chartYCol, chartAgg]);

  const exportFilteredCsv = () => {
    if (columns.length === 0) return;
    const csvLines = [
      columns.join(','),
      ...filteredRowsWithMeta.map(({ row }) =>
        columns
          .map((c) => {
            const v = row[c];
            if (v === null || v === undefined) return '';
            const s = String(v).replace(/"/g, '""');
            return s.includes(',') ? `"${s}"` : s;
          })
          .join(','),
      ),
    ];
    const blob = new Blob([csvLines.join('\n')], {
      type: 'text/csv;charset=utf-8;',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `filtrado_${activeMeta?.originalName || 'dados'}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Cabeçalho e Importação de CSV / XLSX */}
      <section className="rounded-2xl border border-neutral-200 bg-white p-5 sm:p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-500">
              <span>Formatos suportados: CSV e XLSX</span>
              <span aria-hidden="true">·</span>
              <span>Preservação binária do arquivo original com SHA-256</span>
            </div>
            <h1 className="mt-1.5 text-2xl sm:text-3xl font-semibold tracking-tight text-neutral-900">
              Analisador de dados
            </h1>
            <p className="mt-1 text-sm text-neutral-600 max-w-2xl">
              Importe planilhas CSV ou Excel (.xlsx), inspecione valores ausentes e registros duplicados, aplique filtros dinâmicos e gere gráficos sem modificar o arquivo original.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.xlsx,.xls,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
              className="hidden"
              onChange={(e) => handleFileUpload(e.target.files)}
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold transition cursor-pointer disabled:opacity-50"
            >
              {uploading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Upload className="h-4 w-4" />
              )}
              Importar CSV ou XLSX
            </button>
          </div>
        </div>

        {toast && (
          <div className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs font-medium text-emerald-900 flex items-center justify-between">
            <span>{toast}</span>
            <button
              onClick={() => setToast(null)}
              className="text-emerald-700 font-semibold ml-4 cursor-pointer"
            >
              Fechar
            </button>
          </div>
        )}

        {error && (
          <div className="mt-4 rounded-xl border border-io-red/30 bg-red-50 px-4 py-2.5 text-xs font-medium text-io-red flex items-center justify-between">
            <span>{error}</span>
            <button
              onClick={() => setError(null)}
              className="font-semibold underline ml-4 cursor-pointer"
            >
              Ocultar
            </button>
          </div>
        )}

        {/* Seletor de Arquivos Preservados */}
        <div className="mt-5 pt-4 border-t border-neutral-100">
          <div className="text-xs font-semibold text-neutral-700 mb-2">
            Arquivos originais preservados ({datasets.length})
          </div>
          {loadingList ? (
            <div className="text-xs text-neutral-400">Carregando arquivos...</div>
          ) : (
            <div className="flex flex-wrap gap-2">
              {datasets.map((ds) => {
                const isSelected = ds.id === selectedId;
                return (
                  <button
                    key={ds.id}
                    type="button"
                    onClick={() => setSelectedId(ds.id)}
                    className={`flex items-center gap-2 px-3.5 py-2 rounded-xl border text-xs transition cursor-pointer ${
                      isSelected
                        ? 'border-neutral-900 bg-neutral-900 text-white font-semibold'
                        : 'border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-neutral-800'
                    }`}
                  >
                    <FileSpreadsheet className="h-3.5 w-3.5 shrink-0" />
                    <span className="truncate max-w-[200px]">{ds.originalName}</span>
                    <span
                      className={`font-mono text-[11px] tabular-nums ${
                        isSelected ? 'text-neutral-300' : 'text-neutral-500'
                      }`}
                    >
                      · {ds.format.toUpperCase()} · {ds.rowCount} linhas
                      {ds.is_sample ? ' · Dados de exemplo' : ''}
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </section>

      {activeMeta && (
        <>
          {/* Painel de Qualidade de Dados (Valores Ausentes, Duplicados e Arquivo Original) */}
          <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="rounded-2xl border border-neutral-200 bg-white p-5 flex flex-col justify-between">
              <div className="text-xs text-neutral-500">Dimensões da tabela</div>
              <div className="my-2 text-2xl font-semibold font-mono tabular-nums text-neutral-900">
                {rows.length} × {columns.length}
              </div>
              <div className="text-xs text-neutral-500 font-mono tabular-nums">
                Exibindo {filteredRowsWithMeta.length} linhas após filtros
              </div>
            </div>

            <div className="rounded-2xl border border-neutral-200 bg-white p-5 flex flex-col justify-between">
              <div className="flex items-center justify-between text-xs text-neutral-500">
                <span>Valores ausentes (Null / Vazio)</span>
                <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
              </div>
              <div className="my-2 text-2xl font-semibold font-mono tabular-nums text-amber-700">
                {rowDiagnostics.totalMissingCells} células
              </div>
              <div className="text-xs text-neutral-500 font-mono tabular-nums">
                Em {rowDiagnostics.rowsWithMissingCount} linhas da planilha
              </div>
            </div>

            <div className="rounded-2xl border border-neutral-200 bg-white p-5 flex flex-col justify-between">
              <div className="flex items-center justify-between text-xs text-neutral-500">
                <span>Registros duplicados</span>
                <Copy className="h-3.5 w-3.5 text-io-red" />
              </div>
              <div className="my-2 text-2xl font-semibold font-mono tabular-nums text-io-red">
                {rowDiagnostics.totalDuplicateRows} duplicatas
              </div>
              <div className="text-xs text-neutral-500">
                Linhas idênticas detectadas automaticamente
              </div>
            </div>

            <div className="rounded-2xl border border-neutral-200 bg-white p-5 flex flex-col justify-between">
              <div className="flex items-center justify-between text-xs text-neutral-500">
                <span>Arquivo original preservado</span>
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />
              </div>
              <div
                className="my-1 text-xs font-mono text-neutral-800 truncate"
                title={activeMeta.sha256}
              >
                SHA-256: {activeMeta.sha256.slice(0, 16)}…
              </div>
              <div className="flex items-center gap-2 mt-2">
                <button
                  type="button"
                  onClick={handleDownloadOriginal}
                  className="px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="h-3.5 w-3.5" />
                  Baixar original ({formatBytes(activeMeta.sizeBytes)})
                </button>
              </div>
            </div>
          </section>

          {/* Construtor de Gráficos Interativos */}
          <section className="rounded-2xl border border-neutral-200 bg-white p-5 sm:p-6">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-neutral-100">
              <div>
                <h2 className="text-base font-semibold text-neutral-900 flex items-center gap-2">
                  <BarChart3 className="h-4 w-4 text-io-blue" />
                  Visualização gráfica dos dados filtrados
                </h2>
                <p className="text-xs text-neutral-500 mt-0.5">
                  Configure os eixos e a agregação para inspecionar distribuições e tendências em tempo real.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 text-xs">
                <div className="flex items-center gap-1 p-1 bg-neutral-100 rounded-xl">
                  {(
                    [
                      { id: 'bar', label: 'Barras' },
                      { id: 'line', label: 'Linhas' },
                      { id: 'scatter', label: 'Dispersão' },
                      { id: 'pie', label: 'Proporção' },
                    ] as const
                  ).map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setChartType(t.id)}
                      className={`px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                        chartType === t.id
                          ? 'bg-white text-neutral-900 shadow-2xs'
                          : 'text-neutral-600 hover:text-neutral-900'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>

                <select
                  value={chartXCol}
                  onChange={(e) => setChartXCol(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-neutral-300 bg-white text-neutral-800 outline-none"
                >
                  {columns.map((c) => (
                    <option key={c} value={c}>
                      Eixo X: {c}
                    </option>
                  ))}
                </select>

                <select
                  value={chartYCol}
                  onChange={(e) => setChartYCol(e.target.value)}
                  disabled={chartAgg === 'count'}
                  className="px-3 py-2 rounded-xl border border-neutral-300 bg-white text-neutral-800 outline-none disabled:opacity-50"
                >
                  {columns.map((c) => (
                    <option key={c} value={c}>
                      Eixo Y: {c}
                    </option>
                  ))}
                </select>

                <select
                  value={chartAgg}
                  onChange={(e) => setChartAgg(e.target.value as AggregationFn)}
                  className="px-3 py-2 rounded-xl border border-neutral-300 bg-white text-neutral-800 outline-none"
                >
                  <option value="sum">Agregação: Soma</option>
                  <option value="avg">Agregação: Média</option>
                  <option value="count">Agregação: Contagem</option>
                  <option value="max">Agregação: Máximo</option>
                  <option value="min">Agregação: Mínimo</option>
                </select>
              </div>
            </div>

            {/* Renderização SVG do Gráfico */}
            <div className="mt-5">
              {chartSeries.length === 0 ? (
                <div className="h-56 flex items-center justify-center text-xs text-neutral-400 border border-dashed border-neutral-200 rounded-xl">
                  Selecione uma coluna numérica para o Eixo Y ou use "Agregação: Contagem" para gerar o gráfico.
                </div>
              ) : (
                <InteractiveSvgChart
                  type={chartType}
                  data={chartSeries}
                  xLabel={chartXCol}
                  yLabel={chartAgg === 'count' ? 'Contagem de registros' : `${chartAgg.toUpperCase()}(${chartYCol})`}
                />
              )}
            </div>
          </section>

          {/* Barra de Filtros, Diagnóstico por Coluna e Tabela */}
          <section className="rounded-2xl border border-neutral-200 bg-white overflow-hidden">
            <div className="p-5 border-b border-neutral-200 space-y-4">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                <div>
                  <h2 className="text-base font-semibold text-neutral-900 flex items-center gap-2">
                    <Filter className="h-4 w-4 text-io-blue" />
                    Inspeção tabular, valores ausentes e duplicados
                  </h2>
                  <p className="text-xs text-neutral-500 mt-0.5">
                    Células ausentes são destacadas em âmbar e linhas duplicadas são sinalizadas. O arquivo original nunca é sobrescrito.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={exportFilteredCsv}
                    className="px-3 py-1.5 rounded-xl border border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-xs font-medium text-neutral-800 cursor-pointer"
                  >
                    Exportar visão filtrada (.CSV)
                  </button>
                  <button
                    type="button"
                    onClick={handleImportToFinanceMonitor}
                    className="px-3 py-1.5 rounded-xl border border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-xs font-medium text-neutral-800 inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <TrendingUp className="h-3.5 w-3.5 text-io-blue" />
                    Enviar snapshot ao Monitor Financeiro
                  </button>
                  {onOpenInAssistant && (
                    <button
                      type="button"
                      onClick={() => onOpenInAssistant(activeMeta, rawCsvContent)}
                      className="px-3.5 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <Sparkles className="h-3.5 w-3.5 text-io-yellow" />
                      Analisar no Assistente IA
                    </button>
                  )}
                </div>
              </div>

              {/* Controles de Filtro */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5 pt-2">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar texto em qualquer coluna..."
                  className="px-3.5 py-2 text-xs rounded-xl border border-neutral-300 focus:border-io-blue outline-none"
                />

                <select
                  value={filterColumn}
                  onChange={(e) => setFilterColumn(e.target.value)}
                  className="px-3 py-2 text-xs rounded-xl border border-neutral-300 bg-white outline-none"
                >
                  {columns.map((c) => (
                    <option key={c} value={c}>
                      Coluna: {c} ({rowDiagnostics.colMissingCounts[c] || 0} ausentes)
                    </option>
                  ))}
                </select>

                <select
                  value={filterOp}
                  onChange={(e) => setFilterOp(e.target.value as FilterOperator)}
                  className="px-3 py-2 text-xs rounded-xl border border-neutral-300 bg-white outline-none"
                >
                  <option value="all">Operador: Sem filtro de coluna</option>
                  <option value="contains">Contém texto</option>
                  <option value="equals">Igual a</option>
                  <option value="gt">Maior que (&gt;)</option>
                  <option value="lt">Menor que (&lt;)</option>
                  <option value="missing_only">Apenas valores ausentes nesta coluna</option>
                  <option value="non_missing">Sem valores ausentes nesta coluna</option>
                </select>

                <input
                  type="text"
                  value={filterVal}
                  onChange={(e) => setFilterVal(e.target.value)}
                  disabled={
                    filterOp === 'all' ||
                    filterOp === 'missing_only' ||
                    filterOp === 'non_missing'
                  }
                  placeholder="Valor para comparar..."
                  className="px-3.5 py-2 text-xs rounded-xl border border-neutral-300 focus:border-io-blue outline-none disabled:opacity-40"
                />

                <div className="flex gap-1.5">
                  <select
                    value={duplicateMode}
                    onChange={(e) => setDuplicateMode(e.target.value as any)}
                    className="w-1/2 px-2.5 py-2 text-xs rounded-xl border border-neutral-300 bg-white outline-none"
                  >
                    <option value="all">Duplicados: Todos</option>
                    <option value="only_duplicates">Apenas duplicados</option>
                    <option value="hide_duplicates">Ocultar duplicados</option>
                  </select>
                  <select
                    value={missingRowMode}
                    onChange={(e) => setMissingRowMode(e.target.value as any)}
                    className="w-1/2 px-2.5 py-2 text-xs rounded-xl border border-neutral-300 bg-white outline-none"
                  >
                    <option value="all">Ausentes: Todos</option>
                    <option value="only_missing">Linhas c/ ausentes</option>
                    <option value="hide_missing">Apenas completas</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Tabela de Dados */}
            <div className="overflow-x-auto max-h-[520px]">
              {loadingDataset ? (
                <div className="py-12 text-center text-xs text-neutral-500">
                  Lendo registros da planilha...
                </div>
              ) : (
                <table className="w-full text-left text-xs">
                  <thead className="sticky top-0 z-10 bg-neutral-100 border-b border-neutral-200 text-neutral-700">
                    <tr>
                      <th className="py-2.5 px-3 font-mono text-[11px] text-neutral-500 w-14">
                        #
                      </th>
                      <th className="py-2.5 px-3 font-semibold whitespace-nowrap">
                        Diagnóstico
                      </th>
                      {columns.map((col) => (
                        <th
                          key={col}
                          className="py-2.5 px-3.5 font-semibold whitespace-nowrap"
                        >
                          <div>{col}</div>
                          {rowDiagnostics.colMissingCounts[col] > 0 && (
                            <div className="text-[10px] font-normal text-amber-700 font-mono">
                              {rowDiagnostics.colMissingCounts[col]} ausente(s)
                            </div>
                          )}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {filteredRowsWithMeta.slice(0, 200).map((item) => (
                      <tr
                        key={item.originalIndex}
                        className={`transition ${
                          item.isDuplicate
                            ? 'bg-red-50/40 hover:bg-red-50/70'
                            : 'hover:bg-neutral-50'
                        }`}
                      >
                        <td className="py-2 px-3 font-mono tabular-nums text-neutral-400">
                          {item.originalIndex}
                        </td>
                        <td className="py-2 px-3 whitespace-nowrap text-[11px]">
                          {item.isDuplicate && (
                            <span className="text-io-red font-semibold">
                              Duplicado
                            </span>
                          )}
                          {item.isDuplicate && item.hasMissing && (
                            <span className="mx-1 text-neutral-400">·</span>
                          )}
                          {item.hasMissing && (
                            <span className="text-amber-700 font-semibold">
                              Valor ausente
                            </span>
                          )}
                          {!item.isDuplicate && !item.hasMissing && (
                            <span className="text-emerald-700">Íntegro</span>
                          )}
                        </td>
                        {columns.map((col) => {
                          const val = item.row[col];
                          const isMissing =
                            val === null ||
                            val === undefined ||
                            String(val).trim() === '';
                          const isNum = !isMissing && !isNaN(Number(val));
                          return (
                            <td
                              key={col}
                              className={`py-2 px-3.5 whitespace-nowrap ${
                                isMissing
                                  ? 'bg-amber-50/90 text-amber-800 font-mono italic'
                                  : isNum
                                    ? 'font-mono tabular-nums text-neutral-800'
                                    : 'text-neutral-800'
                              }`}
                            >
                              {isMissing ? 'AUSENTE (NULL)' : String(val)}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                    {filteredRowsWithMeta.length === 0 && (
                      <tr>
                        <td
                          colSpan={columns.length + 2}
                          className="py-10 text-center text-neutral-400"
                        >
                          Nenhum registro corresponde aos filtros aplicados.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              )}
            </div>
          </section>
        </>
      )}
    </div>
  );
};

/* ─────────────── Componente SVG Nativo de Gráficos ─────────────── */

const CHART_PALETTE = [
  '#4285f4',
  '#34a853',
  '#fbbc04',
  '#ea4335',
  '#7c3aed',
  '#0891b2',
  '#db2777',
  '#4f46e5',
];

const InteractiveSvgChart: React.FC<{
  type: ChartType;
  data: Array<{ label: string; value: number; xNum?: number }>;
  xLabel: string;
  yLabel: string;
}> = ({ type, data, xLabel, yLabel }) => {
  const maxVal = Math.max(...data.map((d) => d.value), 1);
  const minVal = Math.min(...data.map((d) => d.value), 0);

  if (type === 'pie') {
    const total = data.reduce((acc, d) => acc + Math.max(0, d.value), 0) || 1;
    let cumulativeAngle = 0;

    return (
      <div className="flex flex-col md:flex-row items-center justify-center gap-8 py-4">
        <svg viewBox="-110 -110 220 220" className="w-52 h-52 shrink-0">
          {data.slice(0, 8).map((d, i) => {
            const val = Math.max(0, d.value);
            const sliceAngle = (val / total) * Math.PI * 2;
            const x1 = Math.cos(cumulativeAngle) * 95;
            const y1 = Math.sin(cumulativeAngle) * 95;
            cumulativeAngle += sliceAngle;
            const x2 = Math.cos(cumulativeAngle) * 95;
            const y2 = Math.sin(cumulativeAngle) * 95;
            const largeArc = sliceAngle > Math.PI ? 1 : 0;
            const pathData =
              data.length === 1
                ? 'M -95 0 A 95 95 0 1 0 95 0 A 95 95 0 1 0 -95 0'
                : `M 0 0 L ${x1} ${y1} A 95 95 0 ${largeArc} 1 ${x2} ${y2} Z`;

            return (
              <path
                key={d.label}
                d={pathData}
                fill={CHART_PALETTE[i % CHART_PALETTE.length]}
                stroke="#ffffff"
                strokeWidth="2"
              />
            );
          })}
        </svg>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2 text-xs">
          {data.slice(0, 8).map((d, i) => {
            const pct = ((Math.max(0, d.value) / total) * 100).toFixed(1);
            return (
              <div key={d.label} className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-2 truncate">
                  <span
                    className="h-3 w-3 rounded-xs shrink-0"
                    style={{
                      backgroundColor: CHART_PALETTE[i % CHART_PALETTE.length],
                    }}
                  />
                  <span className="text-neutral-800 font-medium truncate max-w-[140px]">
                    {d.label}
                  </span>
                </div>
                <span className="font-mono tabular-nums text-neutral-600">
                  {d.value.toLocaleString('pt-BR')} ({pct}%)
                </span>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  const width = 820;
  const height = 260;
  const padLeft = 64;
  const padRight = 24;
  const padTop = 24;
  const padBottom = 52;
  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;

  return (
    <div className="w-full overflow-x-auto">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-64 bg-neutral-50/50 rounded-xl border border-neutral-100"
      >
        {/* Linhas de grade horizontais */}
        {[0, 0.25, 0.5, 0.75, 1].map((t) => {
          const y = padTop + plotH * (1 - t);
          const labelVal = (minVal + (maxVal - minVal) * t).toFixed(1);
          return (
            <g key={t}>
              <line
                x1={padLeft}
                y1={y}
                x2={width - padRight}
                y2={y}
                stroke="#e5e5e5"
                strokeDasharray="3 3"
              />
              <text
                x={padLeft - 8}
                y={y + 4}
                textAnchor="end"
                className="fill-neutral-500 text-[10px] font-mono"
              >
                {labelVal}
              </text>
            </g>
          );
        })}

        {type === 'bar' &&
          data.map((d, i) => {
            const barW = Math.max(14, Math.min(48, plotW / data.length - 10));
            const step = plotW / data.length;
            const x = padLeft + i * step + (step - barW) / 2;
            const ratio = Math.max(0, d.value) / maxVal;
            const h = Math.max(2, ratio * plotH);
            const y = padTop + plotH - h;

            return (
              <g key={d.label}>
                <rect
                  x={x}
                  y={y}
                  width={barW}
                  height={h}
                  rx={4}
                  fill="#4285f4"
                  className="hover:opacity-85 transition"
                />
                <text
                  x={x + barW / 2}
                  y={y - 5}
                  textAnchor="middle"
                  className="fill-neutral-700 text-[10px] font-mono"
                >
                  {d.value}
                </text>
                <text
                  x={x + barW / 2}
                  y={padTop + plotH + 16}
                  textAnchor="middle"
                  className="fill-neutral-600 text-[10px]"
                >
                  {d.label.length > 10 ? `${d.label.slice(0, 9)}…` : d.label}
                </text>
              </g>
            );
          })}

        {(type === 'line' || type === 'scatter') && (
          <>
            {type === 'line' && data.length > 1 && (
              <polyline
                fill="none"
                stroke="#4285f4"
                strokeWidth="2.5"
                points={data
                  .map((d, i) => {
                    const x =
                      padLeft +
                      (i / Math.max(1, data.length - 1)) * plotW;
                    const y =
                      padTop +
                      plotH -
                      (Math.max(0, d.value) / maxVal) * plotH;
                    return `${x},${y}`;
                  })
                  .join(' ')}
              />
            )}
            {data.map((d, i) => {
              const x =
                padLeft +
                (data.length === 1
                  ? plotW / 2
                  : (i / Math.max(1, data.length - 1)) * plotW);
              const y =
                padTop + plotH - (Math.max(0, d.value) / maxVal) * plotH;
              return (
                <g key={`${d.label}-${i}`}>
                  <circle
                    cx={x}
                    cy={y}
                    r={5}
                    fill={type === 'scatter' ? '#ea4335' : '#4285f4'}
                    stroke="#fff"
                    strokeWidth="1.5"
                  />
                  <text
                    x={x}
                    y={y - 8}
                    textAnchor="middle"
                    className="fill-neutral-700 text-[10px] font-mono"
                  >
                    {d.value}
                  </text>
                  <text
                    x={x}
                    y={padTop + plotH + 16}
                    textAnchor="middle"
                    className="fill-neutral-600 text-[10px]"
                  >
                    {d.label.length > 10 ? `${d.label.slice(0, 9)}…` : d.label}
                  </text>
                </g>
              );
            })}
          </>
        )}

        <text
          x={padLeft + plotW / 2}
          y={height - 8}
          textAnchor="middle"
          className="fill-neutral-500 text-[11px] font-medium"
        >
          {xLabel} — {yLabel}
        </text>
      </svg>
    </div>
  );
};
