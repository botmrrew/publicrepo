import React, { useState, useEffect, useCallback } from 'react';
import type { ScrapingJob, ScrapingJobStatus } from '../types';
import {
  API_CONFIG,
  apiFetch,
  downloadAuthenticatedBlob,
} from '../config/api';
import { formatBytes, formatDateTimePtBR } from './OverviewSection';
import {
  Plus,
  RefreshCw,
  Download,
  Play,
  Eye,
  Copy,
  Check,
  AlertCircle,
  Loader2,
  X,
} from 'lucide-react';

interface ScrapingPipelineSectionProps {
  onJobsChanged?: () => void;
}

const PRESET_URLS = [
  {
    label: 'Cotações AwesomeAPI (USD, EUR, BTC)',
    url: 'https://economia.awesomeapi.com.br/json/last/USD-BRL,EUR-BRL,BTC-BRL',
    format: 'json' as const,
  },
  {
    label: 'Série Histórica Selic Meta (BCB SGS 432)',
    url: 'https://api.bcb.gov.br/dados/serie/bcdata.sgs.432/dados/ultimos/10?formato=json',
    format: 'json' as const,
  },
  {
    label: 'Boletim PTAX Dólar (BCB Olinda JSON)',
    url: 'https://olinda.bcb.gov.br/olinda/servico/PTAX/versao/v1/odata/Moedas?$format=json',
    format: 'json' as const,
  },
];

export const ScrapingPipelineSection: React.FC<ScrapingPipelineSectionProps> = ({
  onJobsChanged,
}) => {
  const [jobs, setJobs] = useState<ScrapingJob[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<'all' | ScrapingJobStatus>('all');

  // Form state for POST /v1/scraping/jobs
  const [urlInput, setUrlInput] = useState('');
  const [labelInput, setLabelInput] = useState('');
  const [targetFormat, setTargetFormat] = useState<'json' | 'csv' | 'html' | 'text'>('json');
  const [maxAttempts, setMaxAttempts] = useState(3);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Selected job for GET /v1/scraping/jobs/{job_id} modal
  const [selectedJob, setSelectedJob] = useState<ScrapingJob | null>(null);
  const [jobPreview, setJobPreview] = useState<string | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);

  // Action feedback
  const [runningJobId, setRunningJobId] = useState<string | null>(null);
  const [downloadingJobId, setDownloadingJobId] = useState<string | null>(null);
  const [copiedShaId, setCopiedShaId] = useState<string | null>(null);
  const [actionToast, setActionToast] = useState<string | null>(null);

  const fetchJobs = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<{ jobs: ScrapingJob[] }>(
        API_CONFIG.endpoints.scrapingJobs,
      );
      setJobs(res.jobs || []);
    } catch (err: any) {
      setError(err?.message || 'Erro ao consultar tarefas em /v1/scraping/jobs');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchJobs();
  }, [fetchJobs]);

  const handleCreateJob = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!urlInput.trim()) {
      setFormError('Informe uma URL válida para coleta.');
      return;
    }

    setSubmitting(true);
    try {
      const created = await apiFetch<{ job: ScrapingJob }>(
        API_CONFIG.endpoints.scrapingJobs,
        {
          method: 'POST',
          body: JSON.stringify({
            url: urlInput.trim(),
            label: labelInput.trim() || undefined,
            targetFormat,
            max_attempts: maxAttempts,
            runImmediately: true,
          }),
        },
      );

      setUrlInput('');
      setLabelInput('');
      setActionToast(`Tarefa ${created.job.id} registrada em POST /v1/scraping/jobs`);
      setTimeout(() => setActionToast(null), 4000);

      // Aguarda breve instante para o coletor atualizar o status e recarrega
      setTimeout(() => {
        fetchJobs();
        onJobsChanged?.();
      }, 900);
    } catch (err: any) {
      setFormError(err?.message || 'Falha ao cadastrar tarefa de coleta.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleInspectJob = async (jobId: string) => {
    setLoadingDetail(true);
    try {
      const detail = await apiFetch<{
        job: ScrapingJob;
        previewContent: string | null;
      }>(API_CONFIG.endpoints.scrapingJobDetail(jobId));
      setSelectedJob(detail.job);
      setJobPreview(detail.previewContent);
    } catch (err: any) {
      setError(err?.message || 'Falha ao carregar detalhes da tarefa.');
    } finally {
      setLoadingDetail(false);
    }
  };

  const handleRunOrRetryJob = async (jobId: string) => {
    setRunningJobId(jobId);
    try {
      await apiFetch(API_CONFIG.endpoints.scrapingJobRun(jobId), {
        method: 'POST',
      });
      await fetchJobs();
      onJobsChanged?.();
      if (selectedJob?.id === jobId) {
        await handleInspectJob(jobId);
      }
      setActionToast(`Coleta executada para ${jobId}`);
      setTimeout(() => setActionToast(null), 3500);
    } catch (err: any) {
      setError(err?.message || 'Erro ao executar tarefa.');
    } finally {
      setRunningJobId(null);
    }
  };

  const handleAuthenticatedDownload = async (job: ScrapingJob) => {
    setDownloadingJobId(job.id);
    try {
      const { sha256Header, size } = await downloadAuthenticatedBlob(
        API_CONFIG.endpoints.scrapingJobDownload(job.id),
        job.artifact_filename || `${job.id}.${job.targetFormat}`,
      );
      setActionToast(
        `Download autenticado concluído (${formatBytes(size)}${
          sha256Header ? ` · SHA-256 verificado: ${sha256Header.slice(0, 12)}…` : ''
        })`,
      );
      setTimeout(() => setActionToast(null), 4500);
    } catch (err: any) {
      setError(err?.message || 'Falha no download autenticado.');
    } finally {
      setDownloadingJobId(null);
    }
  };

  const copySha256 = (jobId: string, sha: string) => {
    navigator.clipboard?.writeText(sha);
    setCopiedShaId(jobId);
    setTimeout(() => setCopiedShaId(null), 2000);
  };

  const filteredJobs = jobs.filter((j) =>
    statusFilter === 'all' ? true : j.status === statusFilter,
  );

  return (
    <div className="space-y-6">
      {/* Cabeçalho & Contratos REST */}
      <section className="rounded-2xl border border-neutral-200 bg-white p-5 sm:p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-500 font-mono">
              <span>POST /v1/scraping/jobs</span>
              <span aria-hidden="true">·</span>
              <span>GET /v1/scraping/jobs</span>
              <span aria-hidden="true">·</span>
              <span>GET /v1/scraping/jobs/&#123;job_id&#125;</span>
              <span aria-hidden="true">·</span>
              <span>GET /v1/scraping/jobs/&#123;job_id&#125;/download</span>
            </div>
            <h1 className="mt-1.5 text-2xl sm:text-3xl font-semibold tracking-tight text-neutral-900">
              Pipeline de coleta
            </h1>
            <p className="mt-1 text-sm text-neutral-600 max-w-2xl">
              Cadastre endpoints e páginas para coleta automatizada, inspecione tentativas e erros, verifique a integridade criptográfica SHA-256 e realize o download autenticado dos artefatos.
            </p>
          </div>

          <button
            onClick={fetchJobs}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 rounded-xl border border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-xs font-semibold text-neutral-800 transition self-start lg:self-center whitespace-nowrap cursor-pointer"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
            Sincronizar fila
          </button>
        </div>

        {actionToast && (
          <div className="mt-4 rounded-xl border border-emerald-200 bg-emerald-50/80 px-4 py-2.5 text-xs font-medium text-emerald-900 flex items-center justify-between">
            <span>{actionToast}</span>
            <button
              onClick={() => setActionToast(null)}
              className="text-emerald-700 hover:text-emerald-950 font-semibold ml-4 cursor-pointer"
            >
              Fechar
            </button>
          </div>
        )}
      </section>

      {/* Formulário de Cadastro de URL (POST /v1/scraping/jobs) */}
      <section className="rounded-2xl border border-neutral-200 bg-white p-5 sm:p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <h2 className="text-base font-semibold text-neutral-900">
            Cadastrar nova URL de coleta
          </h2>
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            <span className="text-neutral-500">Fontes reais rápidas:</span>
            {PRESET_URLS.map((preset) => (
              <button
                key={preset.url}
                type="button"
                onClick={() => {
                  setUrlInput(preset.url);
                  setLabelInput(preset.label);
                  setTargetFormat(preset.format);
                }}
                className="px-2.5 py-1 rounded-lg border border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-neutral-700 font-medium transition cursor-pointer"
              >
                {preset.label}
              </button>
            ))}
          </div>
        </div>

        <form onSubmit={handleCreateJob} className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-5">
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              URL de destino *
            </label>
            <input
              type="url"
              required
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="https://economia.awesomeapi.com.br/json/last/USD-BRL"
              className="w-full px-3.5 py-2 text-xs rounded-xl border border-neutral-300 focus:border-io-blue outline-none font-mono"
            />
          </div>

          <div className="md:col-span-3">
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Identificação da tarefa
            </label>
            <input
              type="text"
              value={labelInput}
              onChange={(e) => setLabelInput(e.target.value)}
              placeholder="Ex: Fechamento Câmbio Spot"
              className="w-full px-3.5 py-2 text-xs rounded-xl border border-neutral-300 focus:border-io-blue outline-none"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-xs font-medium text-neutral-700 mb-1">
              Formato / Limite
            </label>
            <div className="flex gap-1.5">
              <select
                value={targetFormat}
                onChange={(e) => setTargetFormat(e.target.value as any)}
                className="w-1/2 px-2.5 py-2 text-xs rounded-xl border border-neutral-300 bg-white focus:border-io-blue outline-none"
              >
                <option value="json">JSON</option>
                <option value="csv">CSV</option>
                <option value="html">HTML</option>
                <option value="text">TXT</option>
              </select>
              <select
                value={maxAttempts}
                onChange={(e) => setMaxAttempts(Number(e.target.value))}
                title="Máximo de tentativas"
                className="w-1/2 px-2.5 py-2 text-xs rounded-xl border border-neutral-300 bg-white focus:border-io-blue outline-none font-mono"
              >
                <option value={1}>1x</option>
                <option value={2}>2x</option>
                <option value={3}>3x</option>
                <option value={5}>5x</option>
              </select>
            </div>
          </div>

          <div className="md:col-span-2 flex items-end">
            <button
              type="submit"
              disabled={submitting}
              className="w-full flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold transition whitespace-nowrap cursor-pointer disabled:opacity-50"
            >
              {submitting ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Plus className="h-3.5 w-3.5" />
              )}
              Iniciar coleta
            </button>
          </div>
        </form>

        {formError && (
          <div className="mt-3 text-xs text-io-red flex items-center gap-1.5">
            <AlertCircle className="h-3.5 w-3.5 shrink-0" />
            <span>{formError}</span>
          </div>
        )}
      </section>

      {/* Tabela de Acompanhamento de Tarefas */}
      <section className="rounded-2xl border border-neutral-200 bg-white overflow-hidden">
        <div className="px-5 py-4 border-b border-neutral-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold text-neutral-900">
              Tarefas registradas ({filteredJobs.length})
            </h2>
            <p className="text-xs text-neutral-500">
              Clique em inspecionar para ver o histórico de tentativas ou baixe o arquivo autenticado.
            </p>
          </div>

          {/* Controles interativos de filtro */}
          <div className="flex items-center gap-1 p-1 bg-neutral-100 rounded-xl self-start sm:self-center">
            {(
              [
                { id: 'all', label: 'Todas' },
                { id: 'completed', label: 'Concluídas' },
                { id: 'pending', label: 'Pendentes' },
                { id: 'processing', label: 'Processando' },
                { id: 'failed', label: 'Com falha' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setStatusFilter(tab.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition whitespace-nowrap cursor-pointer ${
                  statusFilter === tab.id
                    ? 'bg-white text-neutral-900 shadow-2xs'
                    : 'text-neutral-600 hover:text-neutral-900'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {error && (
          <div className="m-4 rounded-xl border border-io-red/30 bg-red-50 px-4 py-3 text-xs text-io-red flex items-center justify-between">
            <span>{error}</span>
            <button
              onClick={() => setError(null)}
              className="font-semibold underline ml-3 cursor-pointer"
            >
              Ocultar
            </button>
          </div>
        )}

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-600">
              <tr>
                <th className="py-3 px-4 font-semibold">Tarefa / URL</th>
                <th className="py-3 px-3 font-semibold">Estado</th>
                <th className="py-3 px-3 font-semibold text-right">Tentativas</th>
                <th className="py-3 px-3 font-semibold text-right">Tamanho</th>
                <th className="py-3 px-3 font-semibold">SHA-256 do Artefato</th>
                <th className="py-3 px-4 font-semibold text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100">
              {loading && jobs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-10 text-center text-neutral-500">
                    Carregando fila de coleta...
                  </td>
                </tr>
              ) : filteredJobs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-10 text-center text-neutral-500">
                    Nenhuma tarefa encontrada para o filtro selecionado.
                  </td>
                </tr>
              ) : (
                filteredJobs.map((job) => {
                  const isRunning = runningJobId === job.id || job.status === 'processing';
                  const isDownloading = downloadingJobId === job.id;

                  return (
                    <tr key={job.id} className="hover:bg-neutral-50/70 transition">
                      <td className="py-3 px-4 max-w-xs">
                        <div className="flex items-center gap-1.5">
                          <span className="font-semibold text-neutral-900 truncate">
                            {job.label}
                          </span>
                          {job.is_sample && (
                            <span className="text-[11px] text-amber-700 font-normal shrink-0">
                              · Dados de exemplo
                            </span>
                          )}
                        </div>
                        <div
                          className="font-mono text-[11px] text-neutral-500 truncate mt-0.5"
                          title={job.url}
                        >
                          {job.url}
                        </div>
                        {job.error_message && (
                          <div className="text-[11px] text-io-red mt-1 line-clamp-1">
                            Erro: {job.error_message}
                          </div>
                        )}
                      </td>

                      <td className="py-3 px-3 whitespace-nowrap">
                        {job.status === 'completed' && (
                          <span className="text-emerald-700 font-semibold">Concluída</span>
                        )}
                        {job.status === 'processing' && (
                          <span className="text-io-blue font-semibold">Em processamento</span>
                        )}
                        {job.status === 'pending' && (
                          <span className="text-amber-700 font-semibold">Pendente</span>
                        )}
                        {job.status === 'failed' && (
                          <span className="text-io-red font-semibold">Com falha</span>
                        )}
                        <div className="text-[11px] text-neutral-400 font-mono tabular-nums">
                          {formatDateTimePtBR(job.updated_at)}
                        </div>
                      </td>

                      <td className="py-3 px-3 text-right font-mono tabular-nums text-neutral-800">
                        {job.attempts} / {job.max_attempts}
                      </td>

                      <td className="py-3 px-3 text-right font-mono tabular-nums text-neutral-800 whitespace-nowrap">
                        {job.file_size !== null ? formatBytes(job.file_size) : '—'}
                      </td>

                      <td className="py-3 px-3 font-mono text-[11px] text-neutral-600">
                        {job.sha256 ? (
                          <div className="flex items-center gap-1.5">
                            <span title={job.sha256}>
                              {job.sha256.slice(0, 16)}…{job.sha256.slice(-6)}
                            </span>
                            <button
                              type="button"
                              onClick={() => copySha256(job.id, job.sha256!)}
                              className="p-1 rounded hover:bg-neutral-200/70 text-neutral-500 hover:text-neutral-900 cursor-pointer"
                              title="Copiar hash SHA-256 completo"
                            >
                              {copiedShaId === job.id ? (
                                <Check className="h-3 w-3 text-emerald-600" />
                              ) : (
                                <Copy className="h-3 w-3" />
                              )}
                            </button>
                          </div>
                        ) : (
                          <span className="text-neutral-400">Não calculado</span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleRunOrRetryJob(job.id)}
                            disabled={isRunning}
                            title="Executar / Retentar coleta agora"
                            className="px-2.5 py-1.5 rounded-lg border border-neutral-200 bg-white hover:bg-neutral-100 text-neutral-700 font-medium inline-flex items-center gap-1 transition cursor-pointer disabled:opacity-50"
                          >
                            {isRunning ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin text-io-blue" />
                            ) : (
                              <Play className="h-3.5 w-3.5 text-io-blue" />
                            )}
                            <span>{job.status === 'pending' ? 'Coletar' : 'Retentar'}</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleInspectJob(job.id)}
                            className="px-2.5 py-1.5 rounded-lg border border-neutral-200 bg-white hover:bg-neutral-100 text-neutral-700 font-medium inline-flex items-center gap-1 transition cursor-pointer"
                            title="Inspecionar GET /v1/scraping/jobs/{job_id}"
                          >
                            <Eye className="h-3.5 w-3.5" />
                            <span>Detalhes</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleAuthenticatedDownload(job)}
                            disabled={job.status !== 'completed' || isDownloading}
                            className="px-2.5 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-white font-medium inline-flex items-center gap-1 transition cursor-pointer disabled:opacity-35 disabled:cursor-not-allowed"
                            title="Download autenticado GET /v1/scraping/jobs/{job_id}/download"
                          >
                            {isDownloading ? (
                              <Loader2 className="h-3.5 w-3.5 animate-spin" />
                            ) : (
                              <Download className="h-3.5 w-3.5" />
                            )}
                            <span>Download</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* Modal de Inspeção Detalhada (GET /v1/scraping/jobs/{job_id}) */}
      {selectedJob && (
        <div
          className="fixed inset-0 z-50 bg-neutral-900/60 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setSelectedJob(null)}
        >
          <div
            className="bg-white rounded-2xl border border-neutral-200 max-w-3xl w-full max-h-[88vh] flex flex-col overflow-hidden shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between bg-neutral-50">
              <div>
                <div className="text-xs font-mono text-neutral-500">
                  GET /v1/scraping/jobs/{selectedJob.id}
                </div>
                <h3 className="text-base font-semibold text-neutral-900 mt-0.5">
                  {selectedJob.label}
                </h3>
              </div>
              <button
                onClick={() => setSelectedJob(null)}
                className="p-1.5 rounded-lg text-neutral-500 hover:bg-neutral-200/70 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-5 text-xs">
              {loadingDetail ? (
                <div className="py-8 text-center text-neutral-500">
                  Carregando metadados da tarefa...
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-neutral-50 p-4 rounded-xl border border-neutral-200">
                    <div>
                      <span className="text-neutral-500 block">URL Alvo</span>
                      <span className="font-mono text-neutral-900 break-all font-medium">
                        {selectedJob.url}
                      </span>
                    </div>
                    <div>
                      <span className="text-neutral-500 block">Hash SHA-256 Completo</span>
                      <span className="font-mono text-neutral-900 break-all">
                        {selectedJob.sha256 || 'Indisponível (tarefa não concluída)'}
                      </span>
                    </div>
                    <div>
                      <span className="text-neutral-500 block">Tamanho / Tipo MIME</span>
                      <span className="font-mono tabular-nums text-neutral-900">
                        {selectedJob.file_size !== null
                          ? formatBytes(selectedJob.file_size)
                          : '—'}{' '}
                        · {selectedJob.content_type || selectedJob.targetFormat}
                      </span>
                    </div>
                    <div>
                      <span className="text-neutral-500 block">Tentativas realizadas</span>
                      <span className="font-mono tabular-nums text-neutral-900">
                        {selectedJob.attempts} de {selectedJob.max_attempts}
                      </span>
                    </div>
                  </div>

                  {selectedJob.error_message && (
                    <div className="rounded-xl border border-io-red/30 bg-red-50 p-4 text-io-red">
                      <div className="font-semibold mb-1">Último erro registrado:</div>
                      <div className="font-mono">{selectedJob.error_message}</div>
                    </div>
                  )}

                  <div>
                    <h4 className="font-semibold text-neutral-900 mb-2">
                      Histórico de Tentativas ({selectedJob.attempt_logs.length})
                    </h4>
                    {selectedJob.attempt_logs.length === 0 ? (
                      <p className="text-neutral-500">
                        Nenhuma tentativa executada ainda.
                      </p>
                    ) : (
                      <div className="border border-neutral-200 rounded-xl overflow-hidden">
                        <table className="w-full text-left text-xs font-mono">
                          <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-600">
                            <tr>
                              <th className="py-2 px-3">#</th>
                              <th className="py-2 px-3">Horário</th>
                              <th className="py-2 px-3">Resultado</th>
                              <th className="py-2 px-3 text-right">Duração</th>
                              <th className="py-2 px-3">Detalhe / HTTP</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-neutral-100">
                            {selectedJob.attempt_logs.map((log) => (
                              <tr key={log.attempt}>
                                <td className="py-2 px-3 tabular-nums">{log.attempt}</td>
                                <td className="py-2 px-3 tabular-nums">
                                  {formatDateTimePtBR(log.timestamp)}
                                </td>
                                <td className="py-2 px-3">
                                  {log.status === 'success' ? (
                                    <span className="text-emerald-700 font-semibold">
                                      Sucesso
                                    </span>
                                  ) : (
                                    <span className="text-io-red font-semibold">Falha</span>
                                  )}
                                </td>
                                <td className="py-2 px-3 text-right tabular-nums">
                                  {log.durationMs} ms
                                </td>
                                <td className="py-2 px-3 text-neutral-600">
                                  {log.httpStatus ? `HTTP ${log.httpStatus}` : ''}{' '}
                                  {log.error || ''}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>

                  {jobPreview && (
                    <div>
                      <h4 className="font-semibold text-neutral-900 mb-2">
                        Prévia do Artefato Coletado
                      </h4>
                      <pre className="bg-neutral-900 text-neutral-100 p-4 rounded-xl font-mono text-[11px] overflow-x-auto max-h-60">
                        {jobPreview}
                      </pre>
                    </div>
                  )}
                </>
              )}
            </div>

            <div className="px-6 py-3.5 border-t border-neutral-200 bg-neutral-50 flex items-center justify-between">
              <button
                type="button"
                onClick={() => handleRunOrRetryJob(selectedJob.id)}
                className="px-3.5 py-2 rounded-xl border border-neutral-300 bg-white hover:bg-neutral-100 text-xs font-semibold text-neutral-800 cursor-pointer"
              >
                Executar nova tentativa
              </button>
              <div className="flex items-center gap-2">
                {selectedJob.status === 'completed' && (
                  <button
                    type="button"
                    onClick={() => handleAuthenticatedDownload(selectedJob)}
                    className="px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download className="h-3.5 w-3.5" />
                    Baixar artefato original
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
