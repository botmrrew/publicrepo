import React from 'react';
import type { AdminAreaId, OverviewResponse, ScrapingJob } from '../types';
import {
  RefreshCw,
  HardDrive,
  Clock,
  ArrowUpRight,
  AlertTriangle,
  CheckCircle2,
  Loader2,
  FileSpreadsheet,
  Globe,
  TrendingUp,
  Sparkles,
} from 'lucide-react';

interface OverviewSectionProps {
  data: OverviewResponse | null;
  loading: boolean;
  error: string | null;
  onRefresh: () => void;
  onNavigate: (area: AdminAreaId) => void;
}

export function formatBytes(bytes: number | null | undefined): string {
  if (bytes === null || bytes === undefined || isNaN(bytes)) return '0 B';
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}

export function formatDateTimePtBR(iso: string | null | undefined): string {
  if (!iso) return 'Aguardando registro';
  try {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  } catch {
    return iso;
  }
}

function statusLabelPt(status: ScrapingJob['status']): {
  text: string;
  colorClass: string;
} {
  switch (status) {
    case 'completed':
      return { text: 'Concluída', colorClass: 'text-emerald-700 font-semibold' };
    case 'processing':
      return { text: 'Em processamento', colorClass: 'text-io-blue font-semibold' };
    case 'pending':
      return { text: 'Pendente', colorClass: 'text-amber-700 font-semibold' };
    case 'failed':
      return { text: 'Com falha', colorClass: 'text-io-red font-semibold' };
  }
}

export const OverviewSection: React.FC<OverviewSectionProps> = ({
  data,
  loading,
  error,
  onRefresh,
  onNavigate,
}) => {
  if (loading && !data) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((n) => (
            <div
              key={n}
              className="h-32 rounded-2xl border border-neutral-200 bg-white p-5 animate-pulse flex flex-col justify-between"
            >
              <div className="h-3 w-28 bg-neutral-200 rounded" />
              <div className="h-8 w-16 bg-neutral-200 rounded" />
              <div className="h-3 w-36 bg-neutral-100 rounded" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="rounded-2xl border border-io-red/30 bg-red-50/70 p-6 text-neutral-900">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h3 className="text-base font-semibold text-io-red flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 shrink-0" />
              Falha ao carregar visão geral
            </h3>
            <p className="mt-1 text-sm text-neutral-700">{error}</p>
          </div>
          <button
            onClick={onRefresh}
            className="px-4 py-2 rounded-xl bg-neutral-900 text-white text-xs font-medium hover:bg-neutral-800 transition whitespace-nowrap cursor-pointer"
          >
            Tentar novamente
          </button>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="rounded-2xl border border-neutral-200 bg-white p-10 text-center">
        <p className="text-base font-semibold text-neutral-800">
          Nenhum dado operacional disponível
        </p>
        <p className="mt-1 text-sm text-neutral-500">
          Inicie uma coleta ou importe um conjunto de dados para visualizar as métricas.
        </p>
      </div>
    );
  }

  const storagePercent = Math.min(
    100,
    Math.max(0.5, (data.storage.usedBytes / data.storage.quotaBytes) * 100),
  );

  return (
    <div className="space-y-6">
      {/* Cabeçalho contextual com horário da última atualização e aviso de dados de exemplo */}
      <section className="rounded-2xl border border-neutral-200 bg-white p-5 sm:p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-500">
              <span>Painel Operacional Bot Signature</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums flex items-center gap-1.5 text-neutral-700">
                <Clock className="h-3.5 w-3.5 text-io-blue" />
                Última atualização: {formatDateTimePtBR(data.lastUpdated)}
              </span>
              {data.dataOrigin.hasSampleData && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="text-amber-700 font-medium">
                    Contém Dados de exemplo ({data.dataOrigin.realJobsCount} coletas reais /{' '}
                    {data.dataOrigin.realDatasetsCount} planilhas reais)
                  </span>
                </>
              )}
            </div>
            <h1 className="mt-1.5 text-2xl sm:text-3xl font-semibold tracking-tight text-neutral-900">
              Visão geral da operação
            </h1>
            <p className="mt-1 text-sm text-neutral-600 max-w-2xl">
              Acompanhe em tempo real o estado das filas do pipeline de coleta, o uso de armazenamento de artefatos preservados e os indicadores do monitor financeiro.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              onClick={onRefresh}
              disabled={loading}
              className="flex items-center gap-2 px-4 py-2 rounded-xl border border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-xs font-semibold text-neutral-800 transition whitespace-nowrap cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
              Atualizar dados armazenados
            </button>
            <button
              onClick={() => onNavigate('scraping')}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold transition whitespace-nowrap cursor-pointer"
            >
              Nova coleta
              <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* Grade de KPIs das Tarefas de Coleta */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-2xl border border-neutral-200 bg-white p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-neutral-500">
            <span>Tarefas pendentes</span>
            <span className="font-mono text-amber-700">Fila de espera</span>
          </div>
          <div className="my-3 text-3xl font-semibold text-neutral-900 font-mono tabular-nums">
            {data.tasks.pending}
          </div>
          <div className="text-xs text-neutral-500">
            Aguardando execução no coletor
          </div>
        </div>

        <div className="rounded-2xl border border-neutral-200 bg-white p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-neutral-500">
            <span>Em processamento</span>
            <span className="font-mono text-io-blue">Workers ativos</span>
          </div>
          <div className="my-3 text-3xl font-semibold text-io-blue font-mono tabular-nums flex items-center gap-2">
            {data.tasks.processing}
            {data.tasks.processing > 0 && (
              <Loader2 className="h-5 w-5 animate-spin text-io-blue" />
            )}
          </div>
          <div className="text-xs text-neutral-500">
            Coletas HTTP / extração em andamento
          </div>
        </div>

        <div className="rounded-2xl border border-neutral-200 bg-white p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-neutral-500">
            <span>Tarefas concluídas</span>
            <span className="font-mono text-emerald-700">SHA-256 íntegro</span>
          </div>
          <div className="my-3 text-3xl font-semibold text-emerald-700 font-mono tabular-nums">
            {data.tasks.completed}
          </div>
          <div className="text-xs text-neutral-500">
            Artefatos prontos para download autenticado
          </div>
        </div>

        <div className="rounded-2xl border border-neutral-200 bg-white p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-neutral-500">
            <span>Tarefas com falha</span>
            <span className="font-mono text-io-red">Requer atenção</span>
          </div>
          <div className="my-3 text-3xl font-semibold text-io-red font-mono tabular-nums">
            {data.tasks.failed}
          </div>
          <div className="text-xs text-neutral-500">
            Excederam limite de tentativas ou erro HTTP
          </div>
        </div>
      </section>

      {/* Armazenamento utilizado & Resumo dos módulos */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Card de Armazenamento Utilizado */}
        <section className="rounded-2xl border border-neutral-200 bg-white p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <h2 className="text-base font-semibold text-neutral-900 flex items-center gap-2">
                <HardDrive className="h-4 w-4 text-io-blue" />
                Armazenamento utilizado
              </h2>
              <span className="text-xs font-mono tabular-nums text-neutral-500">
                {data.storage.fileCount} arquivos preservados
              </span>
            </div>

            <div className="mt-4 flex items-baseline justify-between">
              <span className="text-2xl font-semibold font-mono tabular-nums text-neutral-900">
                {formatBytes(data.storage.usedBytes)}
              </span>
              <span className="text-xs font-mono tabular-nums text-neutral-500">
                de {formatBytes(data.storage.quotaBytes)} alocados
              </span>
            </div>

            <div className="mt-3 h-2 w-full rounded-full bg-neutral-100 overflow-hidden">
              <div
                className="h-full gradient-io rounded-full transition-all duration-300"
                style={{ width: `${storagePercent}%` }}
              />
            </div>

            <div className="mt-5 space-y-2.5 border-t border-neutral-100 pt-4 text-xs">
              <div className="flex items-center justify-between text-neutral-700">
                <span>Artefatos do pipeline (/output/scraping)</span>
                <span className="font-mono tabular-nums font-medium">
                  {formatBytes(data.storage.scrapingBytes)}
                </span>
              </div>
              <div className="flex items-center justify-between text-neutral-700">
                <span>Planilhas originais CSV/XLSX (/output/originals)</span>
                <span className="font-mono tabular-nums font-medium">
                  {formatBytes(data.storage.originalsBytes)}
                </span>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-neutral-100 flex items-center justify-between text-xs text-neutral-500">
            <span>Preservação binária SHA-256 ativa</span>
            <button
              onClick={() => onNavigate('analyzer')}
              className="text-io-blue hover:underline font-semibold cursor-pointer"
            >
              Gerenciar arquivos →
            </button>
          </div>
        </section>

        {/* Últimas tarefas do Pipeline de Coleta */}
        <section className="lg:col-span-2 rounded-2xl border border-neutral-200 bg-white p-6 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-base font-semibold text-neutral-900">
                  Atividade recente no pipeline de coleta
                </h2>
                <p className="text-xs text-neutral-500 mt-0.5">
                  Últimas tarefas registradas em <code className="font-mono">/v1/scraping/jobs</code>
                </p>
              </div>
              <button
                onClick={() => onNavigate('scraping')}
                className="text-xs font-semibold text-io-blue hover:underline cursor-pointer whitespace-nowrap"
              >
                Abrir pipeline completo →
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-neutral-200 text-neutral-500">
                    <th className="py-2.5 pr-3 font-medium">Identificação / URL</th>
                    <th className="py-2.5 px-3 font-medium">Estado</th>
                    <th className="py-2.5 px-3 font-medium text-right">Tentativas</th>
                    <th className="py-2.5 px-3 font-medium text-right">Tamanho</th>
                    <th className="py-2.5 pl-3 font-medium text-right">Atualizado em</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {data.recentJobs.map((job) => {
                    const st = statusLabelPt(job.status);
                    return (
                      <tr key={job.id} className="hover:bg-neutral-50/80 transition">
                        <td className="py-2.5 pr-3 max-w-[240px]">
                          <div className="font-medium text-neutral-900 truncate">
                            {job.label}
                          </div>
                          <div className="text-neutral-500 truncate font-mono text-[11px]">
                            {job.url}
                          </div>
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <span className={st.colorClass}>{st.text}</span>
                          {job.is_sample && (
                            <span className="ml-1.5 text-[11px] text-neutral-400">
                              · Dados de exemplo
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-neutral-700">
                          {job.attempts}/{job.max_attempts}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-neutral-700 whitespace-nowrap">
                          {job.file_size !== null ? formatBytes(job.file_size) : '—'}
                        </td>
                        <td className="py-2.5 pl-3 text-right font-mono tabular-nums text-neutral-500 whitespace-nowrap">
                          {formatDateTimePtBR(job.updated_at)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Atalhos rápidos para os demais módulos */}
          <div className="mt-6 pt-4 border-t border-neutral-100 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <button
              onClick={() => onNavigate('analyzer')}
              className="flex items-center justify-between p-3 rounded-xl border border-neutral-200 hover:border-neutral-300 bg-neutral-50/60 text-left transition cursor-pointer"
            >
              <div>
                <div className="text-xs font-semibold text-neutral-900 flex items-center gap-1.5">
                  <FileSpreadsheet className="h-3.5 w-3.5 text-io-green" />
                  Analisador de dados
                </div>
                <div className="text-[11px] text-neutral-500 mt-0.5 font-mono tabular-nums">
                  {data.datasetsCount} planilhas preservadas
                </div>
              </div>
              <ArrowUpRight className="h-3.5 w-3.5 text-neutral-400" />
            </button>

            <button
              onClick={() => onNavigate('finance')}
              className="flex items-center justify-between p-3 rounded-xl border border-neutral-200 hover:border-neutral-300 bg-neutral-50/60 text-left transition cursor-pointer"
            >
              <div>
                <div className="text-xs font-semibold text-neutral-900 flex items-center gap-1.5">
                  <TrendingUp className="h-3.5 w-3.5 text-io-blue" />
                  Monitor financeiro
                </div>
                <div className="text-[11px] text-neutral-500 mt-0.5 font-mono tabular-nums">
                  {data.financialSummary.collected} coletados · {data.financialSummary.awaiting} na fila
                </div>
              </div>
              <ArrowUpRight className="h-3.5 w-3.5 text-neutral-400" />
            </button>

            <button
              onClick={() => onNavigate('assistant')}
              className="flex items-center justify-between p-3 rounded-xl border border-neutral-200 hover:border-neutral-300 bg-neutral-50/60 text-left transition cursor-pointer"
            >
              <div>
                <div className="text-xs font-semibold text-neutral-900 flex items-center gap-1.5">
                  <Sparkles className="h-3.5 w-3.5 text-io-yellow" />
                  Assistente de análise
                </div>
                <div className="text-[11px] text-neutral-500 mt-0.5">
                  Execução sob demanda
                </div>
              </div>
              <ArrowUpRight className="h-3.5 w-3.5 text-neutral-400" />
            </button>
          </div>
        </section>
      </div>
    </div>
  );
};
