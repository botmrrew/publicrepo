import React, { useState, useEffect, useCallback } from 'react';
import type { IntegrationsStatusResponse } from '../types';
import { API_CONFIG, apiFetch } from '../config/api';
import { formatDateTimePtBR } from './OverviewSection';
import {
  RefreshCw,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Server,
  ShieldCheck,
} from 'lucide-react';

export const IntegrationsSection: React.FC = () => {
  const [data, setData] = useState<IntegrationsStatusResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const checkIntegrations = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiFetch<IntegrationsStatusResponse>(
        API_CONFIG.endpoints.integrationsStatus,
      );
      setData(res);
    } catch (err: any) {
      setError(err?.message || 'Falha ao verificar o estado das integrações.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    checkIntegrations();
  }, [checkIntegrations]);

  const effectiveBaseUrl =
    API_CONFIG.baseUrl || (typeof window !== 'undefined' ? window.location.origin : '');

  return (
    <div className="space-y-6">
      {/* Cabeçalho e Configuração Centralizada */}
      <section className="rounded-2xl border border-neutral-200 bg-white p-5 sm:p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-500">
              <span>Credenciais isoladas no servidor</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono">
                API Base: {effectiveBaseUrl}
              </span>
              {data?.checkedAt && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">
                    Verificado em: {formatDateTimePtBR(data.checkedAt)}
                  </span>
                </>
              )}
            </div>
            <h1 className="mt-1.5 text-2xl sm:text-3xl font-semibold tracking-tight text-neutral-900">
              Integrações e serviços
            </h1>
            <p className="mt-1 text-sm text-neutral-600 max-w-2xl">
              Inspecione o estado verificado de cada conector da Bot Signature. Serviços externos sem credenciais definidas no ambiente do servidor são apresentados como “Configuração pendente”.
            </p>
          </div>

          <button
            type="button"
            onClick={checkIntegrations}
            disabled={loading}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold transition self-start lg:self-center whitespace-nowrap cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
            Verificar conexões agora
          </button>
        </div>

        {error && (
          <div className="mt-4 rounded-xl border border-io-red/30 bg-red-50 px-4 py-3 text-xs text-io-red">
            {error}
          </div>
        )}
      </section>

      {/* Resumo de Segurança & Centralização de API */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-2xl border border-neutral-200 bg-white p-5">
          <div className="flex items-center justify-between text-xs text-neutral-500">
            <span>Endereço centralizado da API</span>
            <Server className="h-4 w-4 text-io-blue" />
          </div>
          <div className="my-2 text-sm font-mono font-semibold text-neutral-900 truncate">
            {effectiveBaseUrl}
          </div>
          <p className="text-xs text-neutral-500">
            Definido em <code className="font-mono">src/config/api.ts</code> via{' '}
            <code className="font-mono">VITE_API_BASE_URL</code>.
          </p>
        </div>

        <div className="rounded-2xl border border-neutral-200 bg-white p-5">
          <div className="flex items-center justify-between text-xs text-neutral-500">
            <span>Isolamento de credenciais</span>
            <ShieldCheck className="h-4 w-4 text-emerald-600" />
          </div>
          <div className="my-2 text-sm font-semibold text-emerald-700">
            Exclusivo no Servidor (Server-Only)
          </div>
          <p className="text-xs text-neutral-500">
            Chaves de API, tokens upstream e segredos de sessão jamais são enviados ao navegador.
          </p>
        </div>

        <div className="rounded-2xl border border-neutral-200 bg-white p-5">
          <div className="flex items-center justify-between text-xs text-neutral-500">
            <span>Provedor de IA no servidor</span>
            <Clock className="h-4 w-4 text-io-yellow" />
          </div>
          <div className="my-2 text-sm font-mono font-semibold text-neutral-900">
            {data?.aiConfig
              ? `${data.aiConfig.provider.toUpperCase()} · ${data.aiConfig.model}`
              : 'Verificando...'}
          </div>
          <p className="text-xs text-neutral-500">
            Preparado para Vertex AI / Gemini API via variáveis de ambiente.
          </p>
        </div>
      </section>

      {/* Lista de Serviços Verificados */}
      <section className="space-y-4">
        {loading && !data ? (
          <div className="rounded-2xl border border-neutral-200 bg-white p-8 text-center text-xs text-neutral-500">
            Executando verificação de conectividade nos serviços...
          </div>
        ) : (
          data?.services.map((svc) => {
            const isVerified = svc.status === 'verified';
            const isPending = svc.status === 'pending_config';

            return (
              <div
                key={svc.id}
                className="rounded-2xl border border-neutral-200 bg-white p-5 sm:p-6 transition"
              >
                <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
                  <div className="space-y-1.5 max-w-2xl">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-500">
                      <span>{svc.category}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono">{svc.endpoint}</span>
                    </div>

                    <h2 className="text-base font-semibold text-neutral-900">
                      {svc.name}
                    </h2>

                    <p className="text-xs text-neutral-600 leading-relaxed">
                      {svc.details}
                    </p>
                  </div>

                  {/* Estado Verificado */}
                  <div className="flex items-center gap-2 shrink-0">
                    {isVerified ? (
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
                        <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
                        <span>{svc.statusLabel}</span>
                      </div>
                    ) : isPending ? (
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-700">
                        <Clock className="h-4 w-4 text-amber-600 shrink-0" />
                        <span>Configuração pendente</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-io-red">
                        <AlertTriangle className="h-4 w-4 text-io-red shrink-0" />
                        <span>{svc.statusLabel}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Variáveis de Configuração Verificadas no Servidor */}
                <div className="mt-4 pt-4 border-t border-neutral-100 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                  {svc.configKeys.map((ck) => (
                    <div
                      key={ck.key}
                      className="rounded-xl bg-neutral-50 border border-neutral-200/80 px-3.5 py-2.5 text-xs"
                    >
                      <div className="font-mono text-[11px] text-neutral-500 truncate">
                        {ck.key}
                      </div>
                      <div
                        className={`mt-1 font-mono font-medium truncate ${
                          ck.configured ? 'text-neutral-900' : 'text-amber-700'
                        }`}
                      >
                        {ck.configured ? ck.valuePreview : 'Configuração pendente'}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })
        )}
      </section>
    </div>
  );
};
