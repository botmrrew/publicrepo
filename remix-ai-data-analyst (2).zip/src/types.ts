export interface ReportInsight {
  title: string;
  detail: string;
  metric?: string;
  value?: string;
}

export interface ReportChart {
  title: string;
  file: string;
  caption?: string;
  type?: string;
  /** Base64 data URL injected by the server after extracting the PNG from the sandbox. */
  image?: string;
}

export interface ReportTable {
  title: string;
  columns: string[];
  rows: Array<Array<string | number | null>>;
  caption?: string;
}

export interface AnalysisReport {
  dataset_name: string;
  question: string;
  title: string;
  executive_summary: string;
  insights: ReportInsight[];
  charts: ReportChart[];
  tables: ReportTable[];
  methodology?: string;
  recommendations?: string[];
  generated_at?: string;
}

export type ActivityType =
  | 'info'
  | 'thinking'
  | 'text'
  | 'tool_call'
  | 'tool_result'
  | 'error';

export interface ActivityLog {
  id: string;
  timestamp: string;
  type: ActivityType;
  content?: string;
  name?: string;
  args?: Record<string, unknown>;
  result?: string;
}

export interface UploadedFile {
  name: string;
  content?: string;
  gsUri?: string;
  localPath?: string;
  isLocal?: boolean;
  isGcsUri?: boolean;
  size?: number;
  driveId?: string;
  mimeType?: string;
}

/* ─────────────────── Bot Signature Admin Types ─────────────────── */

export type AdminAreaId =
  | 'overview'
  | 'scraping'
  | 'analyzer'
  | 'finance'
  | 'integrations'
  | 'assistant';

export type ScrapingJobStatus = 'pending' | 'processing' | 'completed' | 'failed';

export interface ScrapingAttemptLog {
  attempt: number;
  timestamp: string;
  status: 'success' | 'error';
  httpStatus?: number;
  durationMs: number;
  error?: string;
}

export interface ScrapingJob {
  id: string;
  url: string;
  label: string;
  targetFormat: 'html' | 'json' | 'csv' | 'text';
  status: ScrapingJobStatus;
  attempts: number;
  max_attempts: number;
  error_message: string | null;
  file_size: number | null;
  sha256: string | null;
  content_type: string | null;
  artifact_filename: string | null;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
  is_sample?: boolean;
  attempt_logs: ScrapingAttemptLog[];
}

export interface StoredDatasetMeta {
  id: string;
  originalName: string;
  storedFilename: string;
  format: 'csv' | 'xlsx';
  sizeBytes: number;
  sha256: string;
  rowCount: number;
  columnCount: number;
  columns: string[];
  missingValuesCount: number;
  duplicateRowsCount: number;
  uploadedAt: string;
  is_sample?: boolean;
}

export type FinancialOriginType =
  | 'collected'
  | 'imported_snapshot'
  | 'awaiting_collection';

export interface FinancialObservation {
  id: string;
  symbol: string;
  name: string;
  category: 'Câmbio' | 'Criptoativo' | 'Índice / Ação' | 'Taxa / Commodity';
  source: string;
  price: number | null;
  currency: string;
  changePercent24h: number | null;
  observedAt: string | null;
  originType: FinancialOriginType;
  jobId?: string;
  datasetId?: string;
  is_sample?: boolean;
  notes?: string;
}

export interface OverviewResponse {
  tasks: {
    pending: number;
    processing: number;
    completed: number;
    failed: number;
    total: number;
  };
  storage: {
    usedBytes: number;
    scrapingBytes: number;
    originalsBytes: number;
    quotaBytes: number;
    fileCount: number;
  };
  datasetsCount: number;
  financialSummary: {
    total: number;
    collected: number;
    imported: number;
    awaiting: number;
  };
  dataOrigin: {
    hasSampleData: boolean;
    realJobsCount: number;
    realDatasetsCount: number;
  };
  recentJobs: ScrapingJob[];
  lastUpdated: string;
  serverTimestamp: string;
}

export interface IntegrationServiceStatus {
  id: string;
  name: string;
  category: string;
  status: 'verified' | 'pending_config' | 'error';
  statusLabel: string;
  endpoint: string;
  details: string;
  verifiedAt: string;
  configKeys: Array<{
    key: string;
    configured: boolean;
    valuePreview: string;
  }>;
}

export interface IntegrationsStatusResponse {
  checkedAt: string;
  aiConfig: {
    provider: string;
    model: string;
    ready: boolean;
    vertexReady: boolean;
  };
  services: IntegrationServiceStatus[];
}

export interface OnDemandAiAnalysisResponse {
  provider: string;
  model: string;
  generated_at: string;
  title: string;
  executive_summary: string;
  insights: ReportInsight[];
  recommendations: string[];
  methodology: string;
}

declare global {
  interface Window {
    gapi: any;
    google?: any;
  }
  const google: any;
}
