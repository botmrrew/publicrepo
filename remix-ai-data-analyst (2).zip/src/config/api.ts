/**
 * Configuração centralizada de endereço da API e cliente autenticado da Bot Signature.
 * Todas as requisições do painel administrativo utilizam este módulo.
 */

const rawBaseUrl =
  typeof import.meta !== "undefined" &&
  (import.meta as any).env?.VITE_API_BASE_URL
    ? String((import.meta as any).env.VITE_API_BASE_URL).trim()
    : "";

export const API_CONFIG = {
  baseUrl: rawBaseUrl.replace(/\/+$/, ""),
  tokenStorageKey: "bot_signature_admin_token",
  endpoints: {
    authLogin: "/api/auth/login",
    authSession: "/api/auth/session",
    authLogout: "/api/auth/logout",
    overview: "/api/admin/overview",
    scrapingJobs: "/v1/scraping/jobs",
    scrapingJobDetail: (jobId: string) =>
      `/v1/scraping/jobs/${encodeURIComponent(jobId)}`,
    scrapingJobRun: (jobId: string) =>
      `/v1/scraping/jobs/${encodeURIComponent(jobId)}/run`,
    scrapingJobDownload: (jobId: string) =>
      `/v1/scraping/jobs/${encodeURIComponent(jobId)}/download`,
    datasets: "/api/datasets",
    datasetUpload: "/api/datasets/upload",
    datasetDetail: (id: string) => `/api/datasets/${encodeURIComponent(id)}`,
    datasetDownload: (id: string) =>
      `/api/datasets/${encodeURIComponent(id)}/download`,
    financeAssets: "/api/finance/assets",
    financeCollect: "/api/finance/collect",
    financeImportDataset: "/api/finance/import-from-dataset",
    integrationsStatus: "/api/integrations/status",
    aiAnalyzeOnDemand: "/api/ai/analyze-on-demand",
    managedAgentAnalyze: "/api/analyze",
    managedAgentUpload: "/api/upload",
    managedAgentCancel: "/api/cancel-show",
    managedAgentClearFiles: "/api/clear-files",
  },
};

export function resolveApiUrl(path: string): string {
  if (/^https?:\/\//i.test(path)) return path;
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  return `${API_CONFIG.baseUrl}${normalizedPath}`;
}

export function getStoredAdminToken(): string | null {
  try {
    return localStorage.getItem(API_CONFIG.tokenStorageKey);
  } catch {
    return null;
  }
}

export function setStoredAdminToken(token: string | null): void {
  try {
    if (token) {
      localStorage.setItem(API_CONFIG.tokenStorageKey, token);
    } else {
      localStorage.removeItem(API_CONFIG.tokenStorageKey);
    }
  } catch {
    // ignore storage errors
  }
}

export async function apiFetch<T = any>(
  endpointPath: string,
  options: RequestInit = {},
): Promise<T> {
  const token = getStoredAdminToken();
  const headers = new Headers(options.headers || {});

  if (token) {
    headers.set("Authorization", `Bearer ${token}`);
  }
  if (
    options.body &&
    typeof options.body === "string" &&
    !headers.has("Content-Type")
  ) {
    headers.set("Content-Type", "application/json");
  }

  const response = await fetch(resolveApiUrl(endpointPath), {
    ...options,
    headers,
  });

  const contentType = response.headers.get("content-type") || "";
  if (!response.ok) {
    let errMsg = `Erro HTTP ${response.status}`;
    if (contentType.includes("application/json")) {
      const errJson = await response.json().catch(() => ({}));
      errMsg = errJson.error || errJson.message || errMsg;
    } else {
      const text = await response.text().catch(() => "");
      if (text) errMsg = text;
    }
    const errorObj = new Error(errMsg) as Error & { status?: number };
    errorObj.status = response.status;
    throw errorObj;
  }

  if (contentType.includes("application/json")) {
    return (await response.json()) as T;
  }
  return (await response.text()) as unknown as T;
}

export async function downloadAuthenticatedBlob(
  endpointPath: string,
  fallbackFilename: string,
): Promise<{ sha256Header: string | null; size: number }> {
  const token = getStoredAdminToken();
  const headers = new Headers();
  if (token) {
    headers.set("Authorization", `Bearer ${token}`);
  }

  const response = await fetch(resolveApiUrl(endpointPath), {
    method: "GET",
    headers,
  });

  if (!response.ok) {
    let errMsg = `Falha no download (${response.status})`;
    try {
      const data = await response.json();
      if (data?.error) errMsg = data.error;
    } catch {
      // ignore
    }
    throw new Error(errMsg);
  }

  const sha256Header = response.headers.get("X-Artifact-SHA256");
  const disposition = response.headers.get("Content-Disposition") || "";
  let filename = fallbackFilename;
  const match = disposition.match(/filename="?([^"]+)"?/i);
  if (match && match[1]) {
    filename = match[1];
  }

  const blob = await response.blob();
  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = objectUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(objectUrl);

  return { sha256Header, size: blob.size };
}
