import React, { useCallback, useMemo, useRef, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import type {
  ActivityLog,
  AnalysisReport,
  ReportChart,
  ReportTable,
  UploadedFile,
  AdminAreaId,
  OverviewResponse,
  StoredDatasetMeta,
  OnDemandAiAnalysisResponse,
} from './types';
import {
  API_CONFIG,
  apiFetch,
  getStoredAdminToken,
  setStoredAdminToken,
  resolveApiUrl,
} from './config/api';
import { OverviewSection } from './components/OverviewSection';
import { ScrapingPipelineSection } from './components/ScrapingPipelineSection';
import { DataAnalyzerSection } from './components/DataAnalyzerSection';
import { FinancialMonitorSection } from './components/FinancialMonitorSection';
import { IntegrationsSection } from './components/IntegrationsSection';
import {
  LogOut,
  Check,
  Sparkles,
  Presentation,
  Database,
  ShieldCheck,
  Lock,
  Loader2,
} from 'lucide-react';

const PixelatedHeader: React.FC = () => {
  return (
    <div className="w-full relative overflow-hidden flex flex-col">
      <div className="h-10 sm:h-12 lg:h-16 w-full relative rounded-t-2xl sm:rounded-t-[1.5rem] overflow-hidden mt-2 mx-2 max-w-[calc(100%-16px)] lg:max-w-screen-2xl lg:mx-auto">
        <div
          className="absolute inset-0"
          style={{
            background:
              'linear-gradient(135deg, #e93822 0%, #a24db3 50%, #4a78ed 100%)',
          }}
        />
        <div className="absolute top-[35%] left-0 right-0 bottom-0 bg-white/15 backdrop-blur-[2px]" />
        <div className="absolute top-[65%] left-0 right-0 bottom-0 bg-white/30 backdrop-blur-[6px]" />
        <div
          className="absolute inset-0 mix-blend-overlay opacity-[0.12]"
          style={{
            backgroundImage: `repeating-linear-gradient(0deg, transparent, transparent 3px, rgba(0,0,0,0.2) 3px, rgba(0,0,0,0.2) 6px)`,
          }}
        />
      </div>
    </div>
  );
};

const UPLOAD_EXAMPLES = [
  'Resuma as principais tendências, anomalias e os fatores mais importantes nestes dados.',
  'Quais são os principais segmentos por valor e como eles se comparam?',
  'Existem valores ausentes críticos, duplicidades ou outliers que exigem ação imediata?',
];

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  status?: Status;
  logs?: ActivityLog[];
  report?: AnalysisReport | null;
  stage?: string;
  question?: string;
}

type Status = 'idle' | 'uploading' | 'running' | 'done' | 'error';

const nowStamp = () => new Date().toISOString().split('T')[1].split('.')[0];

function createUploadSessionId(): string {
  return typeof crypto.randomUUID === 'function'
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function waitForRetry(delayMs: number, signal: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    const timeoutId = window.setTimeout(() => {
      signal.removeEventListener('abort', handleAbort);
      resolve();
    }, delayMs);

    const handleAbort = () => {
      window.clearTimeout(timeoutId);
      reject(new DOMException('A requisição foi cancelada.', 'AbortError'));
    };

    signal.addEventListener('abort', handleAbort, { once: true });
  });
}

function stageFromCommand(cmd: string): string | null {
  if (/curl|wget|gsutil|storage\.googleapis/.test(cmd))
    return 'Carregando conjunto de dados...';
  if (/profil(e|ing)|profile\.json/.test(cmd)) return 'Perfilando tabelas...';
  if (cmd.includes('make_chart.py')) return 'Renderizando gráficos...';
  if (cmd.includes('build_report.py')) return 'Compilando relatório executivo...';
  if (/sklearn|RandomForest|KMeans|LinearRegression|LogisticRegression/.test(cmd))
    return 'Executando modelagem estatística...';
  if (/groupby|merge|pivot|pd\.|pandas|resample/.test(cmd))
    return 'Analisando registros com Pandas...';
  if (cmd.includes('pip install')) return 'Configurando ambiente Python...';
  return null;
}

function sanitizeAgentText(text: string): string {
  if (!text) return text;
  let sanitized = text;
  sanitized = sanitized.replace(
    /call:default_api:[a-zA-Z0-9_!:#-]+(?:\s*\{[\s\S]*?\})?/g,
    '',
  );
  sanitized = sanitized.replace(/call:default_api:[^\s]+/g, '');
  sanitized = sanitized.replace(/\n{3,}/g, '\n\n');
  return sanitized.trim();
}

export const FormattedMarkdown: React.FC<{
  content?: string;
  className?: string;
}> = ({ content = '', className = '' }) => {
  const cleaned = sanitizeAgentText(content);
  return (
    <div className={`prose prose-sm max-w-none text-neutral-800 ${className}`}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          p({ children }) {
            return (
              <p className="mb-2.5 last:mb-0 leading-relaxed text-neutral-800">
                {children}
              </p>
            );
          },
          h1({ children }) {
            return (
              <h1 className="text-base font-bold mt-3 mb-1.5 text-neutral-900 border-b border-neutral-200 pb-1">
                {children}
              </h1>
            );
          },
          h2({ children }) {
            return (
              <h2 className="text-sm font-bold mt-2.5 mb-1 text-neutral-900">
                {children}
              </h2>
            );
          },
          h3({ children }) {
            return (
              <h3 className="text-xs font-bold mt-2 mb-1 text-neutral-800 uppercase tracking-wide">
                {children}
              </h3>
            );
          },
          strong({ children }) {
            return (
              <strong className="font-semibold text-neutral-900">
                {children}
              </strong>
            );
          },
          ul({ children }) {
            return (
              <ul className="list-disc list-outside ml-4 my-2 space-y-1 text-neutral-800">
                {children}
              </ul>
            );
          },
          ol({ children }) {
            return (
              <ol className="list-decimal list-outside ml-4 my-2 space-y-1 text-neutral-800">
                {children}
              </ol>
            );
          },
          li({ children }) {
            return <li className="leading-relaxed pl-0.5">{children}</li>;
          },
          code({ inline, children, ...props }: any) {
            const isInline = inline || !String(children).includes('\n');
            if (isInline) {
              return (
                <code
                  className="bg-neutral-100 font-mono text-[12px] px-1.5 py-0.5 rounded text-neutral-800 font-medium border border-neutral-200/60"
                  {...props}
                >
                  {children}
                </code>
              );
            }
            return (
              <pre className="bg-neutral-900 text-neutral-100 p-3 rounded-xl font-mono text-[11px] leading-relaxed overflow-x-auto my-2.5 shadow-xs">
                <code {...props}>{children}</code>
              </pre>
            );
          },
          table({ children }) {
            return (
              <div className="overflow-x-auto my-3 rounded-xl border border-neutral-200 shadow-2xs">
                <table className="w-full text-xs text-left border-collapse">
                  {children}
                </table>
              </div>
            );
          },
          thead({ children }) {
            return (
              <thead className="bg-neutral-100/80 text-neutral-800 font-semibold border-b border-neutral-200">
                {children}
              </thead>
            );
          },
          tbody({ children }) {
            return (
              <tbody className="divide-y divide-neutral-100 bg-white">
                {children}
              </tbody>
            );
          },
          tr({ children }) {
            return <tr className="hover:bg-neutral-50/50 transition">{children}</tr>;
          },
          th({ children }) {
            return (
              <th className="p-2.5 font-semibold text-neutral-800">{children}</th>
            );
          },
          td({ children }) {
            return <td className="p-2.5 text-neutral-700">{children}</td>;
          },
          blockquote({ children }) {
            return (
              <blockquote className="border-l-3 border-io-blue bg-blue-50/40 px-3 py-2 text-neutral-700 italic my-2 rounded-r-lg text-xs">
                {children}
              </blockquote>
            );
          },
          a({ href, children }) {
            return (
              <a
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="text-io-blue font-medium underline hover:text-blue-700"
              >
                {children}
              </a>
            );
          },
        }}
      >
        {cleaned}
      </ReactMarkdown>
    </div>
  );
};

function environmentIdFromInteraction(interaction: any): string | null {
  if (!interaction || typeof interaction !== 'object') return null;
  const environment = interaction.environment;
  const candidates = [
    environment?.env_id,
    environment?.environment_id,
    environment?.id,
    environment?.name,
    interaction.environment_id,
    interaction.env_id,
  ];
  const value = candidates.find(
    (candidate) => typeof candidate === 'string' && candidate.trim(),
  );
  if (typeof value !== 'string') return null;
  return value.replace(/^environments?\//, '').replace(/^environment-/, '');
}

const NAV_ITEMS: Array<{ id: AdminAreaId; label: string }> = [
  { id: 'overview', label: 'Visão geral' },
  { id: 'scraping', label: 'Pipeline de coleta' },
  { id: 'analyzer', label: 'Analisador de dados' },
  { id: 'finance', label: 'Monitor financeiro' },
  { id: 'integrations', label: 'Integrações' },
  { id: 'assistant', label: 'Assistente de análise' },
];

const App: React.FC = () => {
  // Authentication State
  const [authChecking, setAuthChecking] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [adminEmail, setAdminEmail] = useState('admin@botsignature.com.br');
  const [loginEmail, setLoginEmail] = useState('admin@botsignature.com.br');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loggingIn, setLoggingIn] = useState(false);

  // Active Navigation Area
  const [activeArea, setActiveArea] = useState<AdminAreaId>('overview');

  // Overview Data (consulted from stored server data without calling AI)
  const [overviewData, setOverviewData] = useState<OverviewResponse | null>(null);
  const [overviewLoading, setOverviewLoading] = useState(false);
  const [overviewError, setOverviewError] = useState<string | null>(null);

  // Assistant Mode ('structured' server-configured provider vs 'sandbox' Python agent)
  const [assistantMode, setAssistantMode] = useState<'structured' | 'sandbox'>(
    'structured',
  );
  const [structuredContextType, setStructuredContextType] = useState<
    'general' | 'scraping' | 'finance' | 'dataset'
  >('general');
  const [availableDatasets, setAvailableDatasets] = useState<StoredDatasetMeta[]>([]);
  const [selectedDatasetIdForAi, setSelectedDatasetIdForAi] = useState<string>('');
  const [structuredQuestion, setStructuredQuestion] = useState('');
  const [structuredLoading, setStructuredLoading] = useState(false);
  const [structuredError, setStructuredError] = useState<string | null>(null);
  const [structuredMeta, setStructuredMeta] = useState<{
    provider: string;
    model: string;
  } | null>(null);

  // Original Sandbox Data Analyst state (preserved)
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [question, setQuestion] = useState('');
  const [status, setStatus] = useState<Status>('idle');
  const [stage, setStage] = useState('');
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [report, setReport] = useState<AnalysisReport | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [environmentId, setEnvironmentId] = useState<string | null>(null);
  const [uploadSessionId, setUploadSessionId] = useState(createUploadSessionId);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [viewedMessageId, setViewedMessageId] = useState<string | null>(null);
  const activeMessageIdRef = useRef<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const generationIdRef = useRef<string | null>(null);

  const datasetName =
    files.length === 1
      ? files[0].name.replace(/\.csv$/i, '')
      : files.length > 1
        ? `${files.length} arquivos`
        : 'Dataset';

  const canRun =
    status !== 'running' && question.trim() !== '' && files.length > 0;

  // Verify or initialize session on mount
  useEffect(() => {
    let mounted = true;
    async function verifySession() {
      setAuthChecking(true);
      const existingToken = getStoredAdminToken();
      if (existingToken) {
        try {
          const session = await apiFetch<{
            authenticated: boolean;
            user: { email: string };
          }>(API_CONFIG.endpoints.authSession);
          if (mounted && session.authenticated) {
            setIsAuthenticated(true);
            setAdminEmail(session.user.email);
            setAuthChecking(false);
            return;
          }
        } catch {
          setStoredAdminToken(null);
        }
      }

      // Se não houver sessão prévia, realiza bootstrap autenticado inicial para visualização imediata
      try {
        const demoLogin = await apiFetch<{
          authenticated: boolean;
          token: string;
          user: { email: string };
        }>(API_CONFIG.endpoints.authLogin, {
          method: 'POST',
          body: JSON.stringify({ quickDemo: true }),
        });
        if (mounted && demoLogin.authenticated && demoLogin.token) {
          setStoredAdminToken(demoLogin.token);
          setIsAuthenticated(true);
          setAdminEmail(demoLogin.user.email);
        }
      } catch {
        if (mounted) setIsAuthenticated(false);
      } finally {
        if (mounted) setAuthChecking(false);
      }
    }
    verifySession();
    return () => {
      mounted = false;
    };
  }, []);

  const fetchOverview = useCallback(async () => {
    if (!isAuthenticated) return;
    setOverviewLoading(true);
    setOverviewError(null);
    try {
      const res = await apiFetch<OverviewResponse>(API_CONFIG.endpoints.overview);
      setOverviewData(res);
    } catch (err: any) {
      if (err?.status === 401) {
        setIsAuthenticated(false);
        setStoredAdminToken(null);
      } else {
        setOverviewError(
          err?.message || 'Não foi possível consultar os dados armazenados.',
        );
      }
    } finally {
      setOverviewLoading(false);
    }
  }, [isAuthenticated]);

  const fetchDatasetsForAssistant = useCallback(async () => {
    if (!isAuthenticated) return;
    try {
      const res = await apiFetch<{ datasets: StoredDatasetMeta[] }>(
        API_CONFIG.endpoints.datasets,
      );
      setAvailableDatasets(res.datasets || []);
      if (res.datasets?.length && !selectedDatasetIdForAi) {
        setSelectedDatasetIdForAi(res.datasets[0].id);
      }
    } catch {
      // ignore
    }
  }, [isAuthenticated, selectedDatasetIdForAi]);

  useEffect(() => {
    if (isAuthenticated) {
      fetchOverview();
      fetchDatasetsForAssistant();
    }
  }, [isAuthenticated, fetchOverview, fetchDatasetsForAssistant]);

  const handleLoginSubmit = async (e: React.FormEvent, quickDemo = false) => {
    e.preventDefault();
    setLoggingIn(true);
    setLoginError(null);
    try {
      const res = await apiFetch<{
        authenticated: boolean;
        token: string;
        user: { email: string };
      }>(API_CONFIG.endpoints.authLogin, {
        method: 'POST',
        body: JSON.stringify(
          quickDemo
            ? { quickDemo: true }
            : { email: loginEmail, password: loginPassword },
        ),
      });
      if (res.authenticated && res.token) {
        setStoredAdminToken(res.token);
        setAdminEmail(res.user.email);
        setIsAuthenticated(true);
        setLoginPassword('');
      }
    } catch (err: any) {
      setLoginError(err?.message || 'Falha na autenticação administrativa.');
    } finally {
      setLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    try {
      await apiFetch(API_CONFIG.endpoints.authLogout, { method: 'POST' });
    } catch {
      // ignore
    }
    setStoredAdminToken(null);
    setIsAuthenticated(false);
  };

  // Executa análise estruturada sob demanda (somente quando o administrador clica no botão)
  const handleRunStructuredAiAnalysis = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!structuredQuestion.trim() || structuredLoading) return;
    setStructuredLoading(true);
    setStructuredError(null);
    try {
      const res = await apiFetch<OnDemandAiAnalysisResponse>(
        API_CONFIG.endpoints.aiAnalyzeOnDemand,
        {
          method: 'POST',
          body: JSON.stringify({
            question: structuredQuestion.trim(),
            contextType: structuredContextType,
            datasetId:
              structuredContextType === 'dataset'
                ? selectedDatasetIdForAi
                : undefined,
          }),
        },
      );

      setStructuredMeta({ provider: res.provider, model: res.model });
      setReport({
        dataset_name:
          structuredContextType === 'dataset'
            ? availableDatasets.find((d) => d.id === selectedDatasetIdForAi)
                ?.originalName || 'Dataset'
            : structuredContextType === 'scraping'
              ? 'Pipeline de Coleta'
              : structuredContextType === 'finance'
                ? 'Monitor Financeiro'
                : 'Operação Bot Signature',
        question: structuredQuestion.trim(),
        title: res.title,
        executive_summary: res.executive_summary,
        insights: res.insights || [],
        charts: [],
        tables: [],
        methodology: res.methodology,
        recommendations: res.recommendations || [],
        generated_at: new Date(res.generated_at).toLocaleString('pt-BR'),
      });
    } catch (err: any) {
      setStructuredError(
        err?.message ||
          'Falha ao consultar o provedor de IA configurado no servidor.',
      );
    } finally {
      setStructuredLoading(false);
    }
  };

  // Preserved Sandbox Data Analyst handlers
  const addFiles = useCallback(
    async (fileList: FileList | File[]) => {
      const csvs = Array.from(fileList).filter((f) => /\.csv$/i.test(f.name));
      if (csvs.length === 0) return;

      const MAX_INLINE_SIZE = 1 * 1024 * 1024;
      const oversizedFiles = csvs.filter((f) => f.size > MAX_INLINE_SIZE);
      if (oversizedFiles.length > 0) {
        setErrorMsg(
          `Arquivo excede o limite inline de 1MB: ${oversizedFiles
            .map((f) => `${f.name} (${(f.size / (1024 * 1024)).toFixed(2)}MB)`)
            .join(', ')}. Para arquivos maiores que 1MB, informe uma URI GCS!`,
        );
        setStatus('error');
        return;
      }

      setStatus('uploading');
      try {
        const token = getStoredAdminToken();
        const uploaded = await Promise.all(
          csvs.map(async (file) => {
            const formData = new FormData();
            formData.append('file', file);
            formData.append('sessionId', uploadSessionId);

            const maxAttempts = 5;
            const retryDelayMs = 2000;
            let res: Response | null = null;

            for (let attempt = 1; attempt <= maxAttempts; attempt++) {
              res = await fetch(
                resolveApiUrl(API_CONFIG.endpoints.managedAgentUpload),
                {
                  method: 'POST',
                  headers: token
                    ? { Authorization: `Bearer ${token}` }
                    : undefined,
                  body: formData,
                  redirect: 'manual',
                },
              );

              const wasRedirected =
                res.type === 'opaqueredirect' ||
                res.redirected ||
                (res.status >= 300 && res.status < 400);

              if (!wasRedirected) break;
              if (attempt === maxAttempts) {
                throw new Error(
                  'O serviço de upload redirecionou repetidamente. Tente novamente.',
                );
              }
              await new Promise((resolve) =>
                window.setTimeout(resolve, retryDelayMs),
              );
            }

            if (!res || !res.ok) {
              throw new Error(`Falha ao enviar ${file.name}`);
            }

            const data = await res.json();
            return {
              name: file.name,
              content: data.content,
              size: file.size,
              gsUri: data.gsUri,
              localPath: data.localPath,
              isLocal: data.isLocal,
            } as UploadedFile;
          }),
        );
        setFiles((prev) => {
          const byName = new Map(prev.map((f) => [f.name, f]));
          for (const f of uploaded) byName.set(f.name, f);
          return Array.from(byName.values());
        });
        setStatus('idle');
        setErrorMsg(null);
      } catch (err: any) {
        setErrorMsg(err.message || 'Erro no upload dos arquivos');
        setStatus('error');
      }
    },
    [uploadSessionId],
  );

  const addGcsUriFile = useCallback((uri: string) => {
    const trimmed = uri.trim();
    if (!trimmed.startsWith('gs://')) {
      setErrorMsg(
        'A URI GCS deve iniciar com gs:// (ex: gs://bucket-name/dataset.csv)',
      );
      setStatus('error');
      return;
    }
    const filename = trimmed.split('/').pop() || 'dataset.csv';
    const name = filename.toLowerCase().endsWith('.csv')
      ? filename
      : `${filename}.csv`;
    const gcsFile: UploadedFile = {
      name,
      gsUri: trimmed,
      isGcsUri: true,
    };
    setFiles((prev) => {
      const byName = new Map(prev.map((f) => [f.name, f]));
      byName.set(gcsFile.name, gcsFile);
      return Array.from(byName.values());
    });
    setErrorMsg(null);
  }, []);

  const onDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDragOver(false);
      if (e.dataTransfer.files?.length) addFiles(e.dataTransfer.files);
    },
    [addFiles],
  );

  const removeFile = (name: string) =>
    setFiles((prev) => prev.filter((f) => f.name !== name));

  const pushLog = (log: Omit<ActivityLog, 'id' | 'timestamp'>) => {
    const fullLog: ActivityLog = {
      ...log,
      id: Math.random().toString(36).slice(2),
      timestamp: nowStamp(),
    };
    setLogs((prev) => [...prev, fullLog]);

    setChatMessages((prevChat) => {
      const idx = prevChat.findIndex((m) => m.id === activeMessageIdRef.current);
      if (idx !== -1) {
        const nextChat = [...prevChat];
        const msg = nextChat[idx];
        const nextLogs = [...(msg.logs || []), fullLog];
        nextChat[idx] = {
          ...msg,
          logs: nextLogs,
          stage: log.content || msg.stage,
        };
        return nextChat;
      }
      return prevChat;
    });
  };

  const appendStreamingText = (type: 'thinking' | 'text', chunk: string) => {
    setLogs((prev) => {
      const last = prev[prev.length - 1];
      if (last && last.type === type) {
        const prevContent = last.content ?? '';
        if (chunk === prevContent) return prev;
        const merged = chunk.startsWith(prevContent)
          ? chunk
          : prevContent + chunk;
        const copy = [...prev];
        copy[copy.length - 1] = {
          ...last,
          content: merged,
          timestamp: nowStamp(),
        };
        return copy;
      }
      return [
        ...prev,
        {
          id: Math.random().toString(36).slice(2),
          timestamp: nowStamp(),
          type,
          content: chunk,
        },
      ];
    });

    setChatMessages((prevChat) => {
      const idx = prevChat.findIndex((m) => m.id === activeMessageIdRef.current);
      if (idx !== -1) {
        const nextChat = [...prevChat];
        const msg = nextChat[idx];
        const nextLogs = [...(msg.logs || [])];

        if (nextLogs.length > 0 && nextLogs[nextLogs.length - 1].type === type) {
          const lastLog = nextLogs[nextLogs.length - 1];
          const prevContent = lastLog.content ?? '';
          const merged = chunk.startsWith(prevContent)
            ? chunk
            : prevContent + chunk;
          nextLogs[nextLogs.length - 1] = {
            ...lastLog,
            content: merged,
            timestamp: nowStamp(),
          };
        } else {
          nextLogs.push({
            id: Math.random().toString(36).slice(2),
            timestamp: nowStamp(),
            type,
            content: chunk,
          });
        }

        let nextText = msg.text || '';
        if (type === 'text') {
          nextText += chunk;
        }

        nextChat[idx] = { ...msg, text: nextText, logs: nextLogs };
        return nextChat;
      }
      return prevChat;
    });
  };

  const stop = async () => {
    abortRef.current?.abort();
    if (generationIdRef.current) {
      try {
        await apiFetch(API_CONFIG.endpoints.managedAgentCancel, {
          method: 'POST',
          body: JSON.stringify({ generationId: generationIdRef.current }),
        });
      } catch {
        /* ignore */
      }
    }
    setStatus('idle');
    setStage('');
  };

  const runAnalysis = async (followUpTextArg?: unknown) => {
    const followUpText =
      typeof followUpTextArg === 'string' ? followUpTextArg : undefined;
    if (followUpText && status === 'running') return;
    if (!followUpText && !canRun) return;
    if (followUpText && !environmentId) {
      setErrorMsg(
        'Esta sessão de análise expirou. Inicie uma nova análise enviando o arquivo novamente.',
      );
      return;
    }

    setStatus('running');
    setStage('Inicializando ambiente seguro...');
    setErrorMsg(null);

    const controller = new AbortController();
    abortRef.current = controller;
    const generationId = Math.random().toString(36).slice(2);
    generationIdRef.current = generationId;

    const isFollowUp = !!followUpText && !!environmentId;
    const questionText = followUpText ? followUpText.trim() : question.trim();

    const userMsgId = `user-${Math.random().toString(36).slice(2)}`;
    const assistantMsgId = `assistant-${Math.random().toString(36).slice(2)}`;
    activeMessageIdRef.current = assistantMsgId;

    const userMsg: ChatMessage = {
      id: userMsgId,
      role: 'user',
      text: questionText,
    };
    const assistantMsg: ChatMessage = {
      id: assistantMsgId,
      role: 'assistant',
      text: '',
      status: 'running',
      logs: [],
      stage: 'Inicializando...',
      question: questionText,
    };

    if (followUpText) {
      setChatMessages((prev) => [...prev, userMsg, assistantMsg]);
    } else {
      setLogs([]);
      setReport(null);
      setChatMessages([userMsg, assistantMsg]);
    }
    setViewedMessageId(assistantMsgId);

    const payload: Record<string, unknown> = {
      question: questionText,
      datasetName,
      generationId,
      environmentId: isFollowUp ? environmentId : undefined,
    };

    if (!isFollowUp) {
      payload.files = files;
    }

    try {
      const maxAttempts = 5;
      const retryDelayMs = 2000;
      let response: Response | null = null;
      const token = getStoredAdminToken();

      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        response = await fetch(
          resolveApiUrl(API_CONFIG.endpoints.managedAgentAnalyze),
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              ...(token ? { Authorization: `Bearer ${token}` } : {}),
            },
            body: JSON.stringify(payload),
            signal: controller.signal,
            redirect: 'manual',
          },
        );

        const wasRedirected =
          response.type === 'opaqueredirect' ||
          response.redirected ||
          (response.status >= 300 && response.status < 400);

        if (!wasRedirected) break;
        if (attempt === maxAttempts) {
          throw new Error(
            'O serviço de análise redirecionou a requisição repetidamente.',
          );
        }

        setStage(
          `Serviço de análise preparando conexão. Nova tentativa em ${
            retryDelayMs / 1000
          }s...`,
        );
        await waitForRetry(retryDelayMs, controller.signal);
      }

      if (!response) {
        throw new Error('O serviço de análise não retornou resposta.');
      }

      if (!response.ok || !response.body) {
        const err = await response.json().catch(() => ({}));
        throw new Error(err.error || `Falha na requisição (${response.status})`);
      }

      if (isFollowUp) {
        setLogs([]);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let receivedReport = false;
      let streamError: string | null = null;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data: ')) continue;
          const dataStr = trimmed.slice(6);
          if (dataStr === '[DONE]') continue;

          let event: any;
          try {
            event = JSON.parse(dataStr);
          } catch {
            streamError =
              streamError || 'A conexão foi interrompida durante o relatório.';
            break;
          }

          switch (event.type) {
            case 'info':
              if (event.message) setStage(event.message);
              pushLog({ type: 'info', content: event.message });
              break;
            case 'thinking':
            case 'text':
              if (typeof event.text === 'string' && event.text) {
                appendStreamingText(event.type, event.text);
              }
              break;
            case 'tool_call': {
              const cmd = String(
                event.arguments?.command ?? event.arguments?.code ?? '',
              );
              const s = stageFromCommand(cmd);
              if (s) setStage(s);
              pushLog({
                type: 'tool_call',
                name: event.name,
                args: event.arguments,
              });
              break;
            }
            case 'tool_result': {
              let result = String(event.result ?? '');
              if (result.length > 3000) result = result.slice(0, 3000) + '…';
              pushLog({ type: 'tool_result', name: event.name, result });
              break;
            }
            case 'report_data':
              if (event.data) {
                receivedReport = true;
                const reportData = event.data as AnalysisReport;
                setReport(reportData);
                setChatMessages((prevChat) => {
                  const idx = prevChat.findIndex(
                    (m) => m.id === assistantMsgId,
                  );
                  if (idx !== -1) {
                    const nextChat = [...prevChat];
                    nextChat[idx] = { ...nextChat[idx], report: reportData };
                    return nextChat;
                  }
                  return prevChat;
                });
              }
              break;
            case 'interaction':
            case 'complete':
              if (event.interaction) {
                const envId = environmentIdFromInteraction(event.interaction);
                if (envId) setEnvironmentId(envId);
              }
              break;
            case 'session':
              if (
                typeof event.environmentId === 'string' &&
                event.environmentId
              ) {
                setEnvironmentId(event.environmentId);
              }
              break;
            case 'error':
              streamError = event.message || 'A análise falhou.';
              setErrorMsg(streamError);
              setStatus('error');
              pushLog({ type: 'error', content: streamError });
              break;
            default:
              break;
          }
        }
        if (streamError) break;
      }

      setStage('');

      if (streamError || !receivedReport) {
        const finalError =
          streamError ||
          'O fluxo de análise terminou antes que um relatório fosse produzido.';
        setErrorMsg(finalError);
        setStatus('error');
        return;
      }

      setStatus('done');
      setChatMessages((prevChat) => {
        const idx = prevChat.findIndex((m) => m.id === assistantMsgId);
        if (idx !== -1) {
          const nextChat = [...prevChat];
          nextChat[idx] = { ...nextChat[idx], status: 'done' };
          return nextChat;
        }
        return prevChat;
      });
    } catch (e: any) {
      if (e?.name === 'AbortError') return;
      setErrorMsg(e?.message || 'Erro inesperado');
      setStatus('error');
    } finally {
      generationIdRef.current = null;
    }
  };

  const selectMessage = (msgId: string) => {
    const msg = chatMessages.find((m) => m.id === msgId);
    if (msg && msg.role === 'assistant') {
      setViewedMessageId(msgId);
      if (msg.report) setReport(msg.report);
      if (msg.logs) setLogs(msg.logs);
    }
  };

  const reset = () => {
    const sessionIdToClear = uploadSessionId;
    setStatus('idle');
    setReport(null);
    setLogs([]);
    setErrorMsg(null);
    setStage('');
    setEnvironmentId(null);
    setChatMessages([]);
    setViewedMessageId(null);
    activeMessageIdRef.current = null;
    setFiles([]);
    setUploadSessionId(createUploadSessionId());

    apiFetch(API_CONFIG.endpoints.managedAgentClearFiles, {
      method: 'POST',
      body: JSON.stringify({ sessionId: sessionIdToClear }),
    }).catch(() => {});
  };

  if (authChecking) {
    return (
      <div className="min-h-screen w-full bg-[#f6f5f3] flex items-center justify-center p-6">
        <div className="flex items-center gap-3 text-sm font-medium text-neutral-700">
          <Loader2 className="h-5 w-5 animate-spin text-io-blue" />
          <span>Verificando credenciais administrativas Bot Signature...</span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen w-full bg-[#f6f5f3] text-neutral-900 font-sans flex flex-col">
        <PixelatedHeader />
        <div className="flex-1 flex items-center justify-center p-6">
          <div className="max-w-md w-full rounded-2xl border border-neutral-200 bg-white p-6 sm:p-8 shadow-xs">
            <div className="flex items-center gap-2 text-xs text-neutral-500 font-mono">
              <Lock className="h-3.5 w-3.5 text-io-blue" />
              <span>ÁREA ADMINISTRATIVA PROTEGIDA</span>
            </div>
            <h1 className="mt-2 text-2xl font-semibold text-neutral-900 tracking-tight">
              Bot Signature Admin
            </h1>
            <p className="mt-1 text-xs text-neutral-600 leading-relaxed">
              Autentique-se para acessar o pipeline de coleta, analisador de dados, monitor financeiro e assistente de análise. As credenciais são validadas exclusivamente no servidor.
            </p>

            <form
              onSubmit={(e) => handleLoginSubmit(e, false)}
              className="mt-6 space-y-4"
            >
              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">
                  E-mail administrativo
                </label>
                <input
                  type="email"
                  required
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-neutral-300 focus:border-io-blue outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-neutral-700 mb-1">
                  Senha do servidor
                </label>
                <input
                  type="password"
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-neutral-300 focus:border-io-blue outline-none"
                />
              </div>

              {loginError && (
                <div className="rounded-xl border border-io-red/30 bg-red-50 px-3.5 py-2.5 text-xs text-io-red">
                  {loginError}
                </div>
              )}

              <button
                type="submit"
                disabled={loggingIn}
                className="w-full py-2.5 px-4 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold transition cursor-pointer disabled:opacity-50"
              >
                {loggingIn ? 'Verificando no servidor...' : 'Entrar com credenciais'}
              </button>

              <div className="pt-3 border-t border-neutral-100">
                <button
                  type="button"
                  disabled={loggingIn}
                  onClick={(e) => handleLoginSubmit(e, true)}
                  className="w-full py-2 px-4 rounded-xl border border-neutral-200 bg-neutral-50 hover:bg-neutral-100 text-neutral-800 text-xs font-medium transition cursor-pointer"
                >
                  Acesso Rápido de Demonstração (Sessão Assinada no Servidor)
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-full bg-[#f6f5f3] text-neutral-900 font-sans flex flex-col pb-12">
      <PixelatedHeader />

      {/* Top Bar Contract: Zone 1 (Brand) — Zone 2 (Navigation Links) — Zone 3 (Primary Actions) */}
      <header className="mx-auto max-w-screen-2xl w-full px-6 py-4 border-b border-neutral-200/80 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <button
          type="button"
          onClick={() => setActiveArea('overview')}
          className="text-lg font-bold tracking-tight text-neutral-900 whitespace-nowrap cursor-pointer"
        >
          Bot Signature
        </button>

        {/* Zone 2: Navigation links */}
        <nav className="hidden lg:flex items-center gap-6 text-sm font-medium text-neutral-600">
          {NAV_ITEMS.map((item) => {
            const isActive = activeArea === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveArea(item.id)}
                className={`py-1 transition-colors whitespace-nowrap cursor-pointer border-b-2 ${
                  isActive
                    ? 'border-neutral-900 text-neutral-900 font-semibold'
                    : 'border-transparent hover:text-neutral-900 hover:border-neutral-300'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary actions */}
        <div className="flex items-center gap-3 shrink-0">
          <span className="hidden sm:inline-flex items-center gap-1.5 text-xs text-neutral-600 font-mono">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
            {adminEmail}
          </span>
          <button
            type="button"
            onClick={handleLogout}
            className="px-3.5 py-2 text-xs font-medium text-neutral-700 bg-white border border-neutral-200 rounded-xl hover:bg-neutral-100 transition-colors whitespace-nowrap inline-flex items-center gap-1.5 cursor-pointer"
          >
            <LogOut className="h-3.5 w-3.5" />
            Sair
          </button>
        </div>
      </header>

      {/* Navegação responsiva mobile/tablet */}
      <div className="lg:hidden mx-auto max-w-screen-2xl w-full px-6 pt-3 overflow-x-auto no-scrollbar">
        <div className="flex items-center gap-1.5 p-1 bg-neutral-200/60 rounded-xl w-max">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveArea(item.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition cursor-pointer ${
                activeArea === item.id
                  ? 'bg-white text-neutral-900 shadow-2xs font-semibold'
                  : 'text-neutral-600 hover:text-neutral-900'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Área de Conteúdo Principal */}
      <main className="mx-auto max-w-screen-2xl w-full px-6 pt-6 flex-1">
        {activeArea === 'overview' && (
          <OverviewSection
            data={overviewData}
            loading={overviewLoading}
            error={overviewError}
            onRefresh={fetchOverview}
            onNavigate={(target) => setActiveArea(target)}
          />
        )}

        {activeArea === 'scraping' && (
          <ScrapingPipelineSection onJobsChanged={fetchOverview} />
        )}

        {activeArea === 'analyzer' && (
          <DataAnalyzerSection
            onDatasetsChanged={() => {
              fetchOverview();
              fetchDatasetsForAssistant();
            }}
            onSendToFinanceMonitor={() => {
              fetchOverview();
            }}
            onOpenInAssistant={(dataset, csvContent) => {
              setSelectedDatasetIdForAi(dataset.id);
              setStructuredContextType('dataset');
              setFiles([
                {
                  name: dataset.originalName.endsWith('.csv')
                    ? dataset.originalName
                    : `${dataset.originalName}.csv`,
                  content: csvContent,
                  size: dataset.sizeBytes,
                },
              ]);
              setActiveArea('assistant');
            }}
          />
        )}

        {activeArea === 'finance' && (
          <FinancialMonitorSection onFinanceChanged={fetchOverview} />
        )}

        {activeArea === 'integrations' && <IntegrationsSection />}

        {activeArea === 'assistant' && (
          <div className="space-y-6">
            {/* Cabeçalho do Assistente de Análise */}
            <section className="rounded-2xl border border-neutral-200 bg-white p-5 sm:p-6">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-neutral-500">
                    <span>Provedor e modelo configurados no servidor</span>
                    <span aria-hidden="true">·</span>
                    <span>Execução estritamente sob demanda do administrador</span>
                    {structuredMeta && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono text-emerald-700 font-medium">
                          Última chamada: {structuredMeta.provider.toUpperCase()} ({structuredMeta.model})
                        </span>
                      </>
                    )}
                  </div>
                  <h1 className="mt-1.5 text-2xl sm:text-3xl font-semibold tracking-tight text-neutral-900">
                    Assistente de análise
                  </h1>
                  <p className="mt-1 text-sm text-neutral-600 max-w-2xl">
                    Solicite diagnósticos executivos sobre os dados armazenados ou execute o agente autônomo em Python para gerar gráficos e relatórios em PDF. Nenhuma chamada de IA ocorre sem solicitação explícita.
                  </p>
                </div>

                {/* Seletor de Modo do Assistente */}
                <div className="flex items-center gap-1 p-1 bg-neutral-100 rounded-xl self-start lg:self-center">
                  <button
                    type="button"
                    onClick={() => setAssistantMode('structured')}
                    className={`px-3.5 py-2 text-xs font-medium rounded-lg transition whitespace-nowrap cursor-pointer ${
                      assistantMode === 'structured'
                        ? 'bg-white text-neutral-900 shadow-2xs font-semibold'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    Análise Rápida (Gemini / Vertex Server)
                  </button>
                  <button
                    type="button"
                    onClick={() => setAssistantMode('sandbox')}
                    className={`px-3.5 py-2 text-xs font-medium rounded-lg transition whitespace-nowrap cursor-pointer ${
                      assistantMode === 'sandbox'
                        ? 'bg-white text-neutral-900 shadow-2xs font-semibold'
                        : 'text-neutral-600 hover:text-neutral-900'
                    }`}
                  >
                    Sandbox Python Autônomo (CSV)
                  </button>
                </div>
              </div>
            </section>

            {assistantMode === 'structured' ? (
              <div className="space-y-6">
                <section className="rounded-2xl border border-neutral-200 bg-white p-5 sm:p-6">
                  <h2 className="text-base font-semibold text-neutral-900 mb-3">
                    Solicitar análise sob demanda ao servidor
                  </h2>
                  <form
                    onSubmit={handleRunStructuredAiAnalysis}
                    className="space-y-4"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-medium text-neutral-700 mb-1">
                          Escopo de dados armazenados
                        </label>
                        <select
                          value={structuredContextType}
                          onChange={(e) =>
                            setStructuredContextType(e.target.value as any)
                          }
                          className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-neutral-300 bg-white outline-none"
                        >
                          <option value="general">
                            Visão Geral da Operação Bot Signature
                          </option>
                          <option value="dataset">
                            Planilha Preservada no Analisador de Dados
                          </option>
                          <option value="scraping">
                            Tarefas e Erros do Pipeline de Coleta (/v1/scraping/jobs)
                          </option>
                          <option value="finance">
                            Ativos e Cotações do Monitor Financeiro
                          </option>
                        </select>
                      </div>

                      {structuredContextType === 'dataset' && (
                        <div>
                          <label className="block text-xs font-medium text-neutral-700 mb-1">
                            Selecionar planilha preservada
                          </label>
                          <select
                            value={selectedDatasetIdForAi}
                            onChange={(e) =>
                              setSelectedDatasetIdForAi(e.target.value)
                            }
                            className="w-full px-3.5 py-2.5 text-xs rounded-xl border border-neutral-300 bg-white outline-none"
                          >
                            {availableDatasets.map((d) => (
                              <option key={d.id} value={d.id}>
                                {d.originalName} ({d.rowCount} linhas ·{' '}
                                {d.missingValuesCount} ausentes)
                              </option>
                            ))}
                          </select>
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-neutral-700 mb-1">
                        Pergunta ou objetivo da análise executiva
                      </label>
                      <textarea
                        rows={3}
                        value={structuredQuestion}
                        onChange={(e) => setStructuredQuestion(e.target.value)}
                        placeholder="Ex: Identifique os principais gargalos operacionais, anomalias de preços ou inconsistências nos dados coletados e recomende ações."
                        className="w-full rounded-xl border border-neutral-300 px-4 py-3 text-sm outline-none focus:border-io-blue"
                      />
                      <div className="mt-2 flex flex-wrap gap-2">
                        {UPLOAD_EXAMPLES.map((ex) => (
                          <button
                            key={ex}
                            type="button"
                            onClick={() => setStructuredQuestion(ex)}
                            className="rounded-lg border border-neutral-200 bg-neutral-50 px-3 py-1.5 text-xs text-neutral-600 hover:border-io-blue hover:text-io-blue transition cursor-pointer"
                          >
                            {ex}
                          </button>
                        ))}
                      </div>
                    </div>

                    {structuredError && (
                      <ErrorBanner message={structuredError} />
                    )}

                    <button
                      type="submit"
                      disabled={
                        structuredLoading || !structuredQuestion.trim()
                      }
                      className="inline-flex items-center justify-center gap-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 px-6 py-3 text-xs font-semibold text-white transition cursor-pointer disabled:opacity-40"
                    >
                      {structuredLoading ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Consultando provedor de IA no servidor...
                        </>
                      ) : (
                        <>
                          <Sparkles className="h-4 w-4 text-io-yellow" />
                          Solicitar análise com IA agora
                        </>
                      )}
                    </button>
                  </form>
                </section>

                {report && <ReportView report={report} />}
              </div>
            ) : (
              <AnimatePresence mode="wait">
                {(status === 'idle' || status === 'uploading') && !report ? (
                  <motion.div
                    key="setup"
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                  >
                    <SetupPanel
                      files={files}
                      dragOver={dragOver}
                      question={question}
                      examples={UPLOAD_EXAMPLES}
                      canRun={canRun}
                      isUploading={status === 'uploading'}
                      onDragOver={(e) => {
                        e.preventDefault();
                        setDragOver(true);
                      }}
                      onDragLeave={() => setDragOver(false)}
                      onDrop={onDrop}
                      onPickFiles={(fl) => fl && addFiles(fl)}
                      onAddGcsUri={addGcsUriFile}
                      onRemoveFile={removeFile}
                      onQuestionChange={setQuestion}
                      onRun={runAnalysis}
                    />
                  </motion.div>
                ) : (
                  <motion.div
                    key="run"
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-6"
                  >
                    <RunHeader
                      datasetName={datasetName}
                      question={question}
                      status={status}
                      stage={stage}
                      onStop={stop}
                      onReset={reset}
                    />
                    {errorMsg && <ErrorBanner message={errorMsg} />}
                    <div className="flex flex-col lg:flex-row gap-6 items-start">
                      <div className="w-full lg:w-[360px] xl:w-[420px] shrink-0 lg:sticky lg:top-6">
                        <AgentPanel
                          messages={chatMessages}
                          logs={logs}
                          status={status}
                          stage={stage}
                          viewedMessageId={viewedMessageId}
                          onSelectMessage={selectMessage}
                          onSendFollowUp={(text) => runAnalysis(text)}
                          report={report}
                          datasetName={datasetName}
                        />
                      </div>
                      <div className="flex-1 w-full min-w-0">
                        {report ? (
                          <ReportView report={report} />
                        ) : (
                          status === 'running' && (
                            <div className="flex h-[60vh] flex-col items-center justify-center rounded-2xl border border-dashed border-neutral-300 bg-neutral-50/50 p-8 text-center">
                              <p className="text-base font-medium text-neutral-700">
                                O relatório executivo será gerado aqui
                              </p>
                              <p className="mt-1.5 max-w-sm text-sm text-neutral-500">
                                O agente está explorando os dados e executando os cálculos em segundo plano.
                              </p>
                            </div>
                          )
                        )}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            )}
          </div>
        )}
      </main>
    </div>
  );
};

/* ─────────────────────────── Setup (Preservado em PT-BR) ─────────────────────────── */

interface SetupProps {
  files: UploadedFile[];
  dragOver: boolean;
  question: string;
  examples: string[];
  canRun: boolean;
  isUploading?: boolean;
  onDragOver: (e: React.DragEvent) => void;
  onDragLeave: () => void;
  onDrop: (e: React.DragEvent) => void;
  onPickFiles: (files: FileList | null) => void;
  onAddGcsUri: (uri: string) => void;
  onRemoveFile: (name: string) => void;
  onQuestionChange: (v: string) => void;
  onRun: () => void;
}

const SetupPanel: React.FC<SetupProps> = ({
  files,
  dragOver,
  question,
  examples,
  canRun,
  isUploading = false,
  onDragOver,
  onDragLeave,
  onDrop,
  onPickFiles,
  onAddGcsUri,
  onRemoveFile,
  onQuestionChange,
  onRun,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [gcsInput, setGcsInput] = useState('');

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <section className="rounded-2xl border border-neutral-200 bg-white p-5">
        <div className="mb-3 flex items-center gap-2 text-sm font-medium text-neutral-700">
          <span className="flex h-5 w-5 items-center justify-center rounded-full bg-neutral-900 text-[11px] text-white">
            1
          </span>
          Selecione um conjunto de dados CSV para o Sandbox Python
        </div>

        <div
          onDragOver={isUploading ? undefined : onDragOver}
          onDragLeave={isUploading ? undefined : onDragLeave}
          onDrop={isUploading ? undefined : onDrop}
          onClick={isUploading ? undefined : () => fileInputRef.current?.click()}
          className={`flex flex-col items-center justify-center rounded-xl border-2 border-dashed px-6 py-8 text-center transition ${
            isUploading
              ? 'border-neutral-200 bg-neutral-50/50 cursor-wait'
              : dragOver
                ? 'border-io-blue bg-blue-50 cursor-pointer'
                : 'border-neutral-300 hover:border-neutral-400 cursor-pointer'
          }`}
        >
          {isUploading ? (
            <div className="flex flex-col items-center justify-center space-y-2">
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-neutral-800 border-t-transparent" />
              <p className="text-sm font-medium text-neutral-700 animate-pulse">
                Enviando e preparando conjunto de dados...
              </p>
            </div>
          ) : (
            <>
              <p className="text-sm font-medium text-neutral-700">
                Arraste arquivos CSV aqui ou clique para selecionar (&le; 1MB)
              </p>
              <p className="mt-1 text-xs text-neutral-400">
                Suporta múltiplos arquivos CSV relacionados para análise com execução de código
              </p>
            </>
          )}
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,text/csv"
            multiple
            className="hidden"
            disabled={isUploading}
            onChange={(e) => onPickFiles(e.target.files)}
          />
        </div>

        <div className="mt-4 border-t border-neutral-100 pt-4">
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-semibold text-neutral-700 flex items-center gap-1.5">
              <Database className="h-3.5 w-3.5 text-io-blue" />
              Informe uma URI GCS para arquivos CSV maiores que 1MB
            </label>
            <span className="text-[11px] text-neutral-400">
              Sem limite de 1MB inline
            </span>
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="gs://bucket-name/caminho/grande_dataset.csv"
              value={gcsInput}
              onChange={(e) => setGcsInput(e.target.value)}
              disabled={isUploading}
              className="flex-1 px-3.5 py-2 text-xs rounded-xl border border-neutral-300 focus:border-io-blue outline-none"
            />
            <button
              type="button"
              disabled={isUploading || !gcsInput.trim()}
              onClick={() => {
                if (!gcsInput.trim()) return;
                onAddGcsUri(gcsInput.trim());
                setGcsInput('');
              }}
              className="px-4 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-medium transition cursor-pointer disabled:opacity-40"
            >
              Adicionar GCS
            </button>
          </div>
        </div>

        {files.length > 0 && (
          <ul className="mt-3 space-y-2">
            {files.map((f) => (
              <li
                key={f.name}
                className="flex items-center justify-between rounded-lg border border-neutral-200 bg-neutral-50 px-3 py-2 text-sm"
              >
                <span className="flex items-center gap-2 truncate max-w-[80%]">
                  <span className="truncate font-medium text-neutral-800">
                    {f.name}
                  </span>
                  <span className="text-[11px] text-neutral-500 font-mono truncate">
                    ·{' '}
                    {f.isGcsUri || (f.gsUri && !f.content)
                      ? `GCS (${f.gsUri})`
                      : `CSV Inline (${
                          f.size
                            ? (f.size / 1024).toFixed(1)
                            : f.content
                              ? (f.content.length / 1024).toFixed(1)
                              : '0'
                        } KB)`}
                  </span>
                </span>
                <button
                  disabled={isUploading}
                  onClick={(e) => {
                    e.stopPropagation();
                    onRemoveFile(f.name);
                  }}
                  className="text-neutral-400 hover:text-io-red font-medium text-xs px-1.5 py-0.5 cursor-pointer"
                >
                  Remover
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="rounded-2xl border border-neutral-200 bg-white p-5">
        <div className="mb-3 flex items-center gap-2 text-sm font-medium text-neutral-700">
          <span className="flex h-5 w-5 items-center justify-center rounded-full bg-neutral-900 text-[11px] text-white">
            2
          </span>
          Formule a pergunta de negócio para o agente
        </div>
        <textarea
          value={question}
          onChange={(e) => onQuestionChange(e.target.value)}
          disabled={isUploading}
          rows={3}
          placeholder="Ex: Quais categorias geram maior receita e qual a tendência mensal?"
          className="w-full resize-none rounded-xl border border-neutral-300 px-4 py-3 text-sm outline-none transition focus:border-io-blue"
        />
        <div className="mt-3 flex flex-wrap gap-2">
          {examples.map((ex) => (
            <button
              key={ex}
              disabled={isUploading}
              onClick={() => onQuestionChange(ex)}
              className="rounded-lg border border-neutral-200 bg-neutral-50 px-3 py-1.5 text-xs text-neutral-600 transition hover:border-io-blue hover:text-io-blue cursor-pointer"
            >
              {ex}
            </button>
          ))}
        </div>
      </section>

      <button
        onClick={onRun}
        disabled={!canRun || isUploading}
        className="flex w-full items-center justify-center gap-2 rounded-xl bg-neutral-900 px-6 py-3.5 text-sm font-semibold text-white transition enabled:hover:bg-neutral-800 disabled:cursor-not-allowed disabled:opacity-40 cursor-pointer"
      >
        Solicitar Análise no Sandbox
      </button>
    </div>
  );
};

/* ─────────────────────────── Run header ─────────────────────────── */

const RunHeader: React.FC<{
  datasetName: string;
  question: string;
  status: Status;
  stage: string;
  onStop: () => void;
  onReset: () => void;
}> = ({ datasetName, question, status, stage, onStop, onReset }) => (
  <div className="rounded-2xl border border-neutral-200 bg-white p-5">
    <div className="flex items-start justify-between gap-4">
      <div className="min-w-0">
        <div className="flex items-center gap-2 text-xs font-medium text-neutral-500">
          Conjunto de dados: {datasetName}
        </div>
        <p className="mt-1 truncate text-base font-medium text-neutral-900">
          {question}
        </p>
      </div>
      {status === 'running' ? (
        <button
          onClick={onStop}
          className="flex shrink-0 items-center gap-1.5 rounded-lg border border-io-red/30 bg-red-50 px-3 py-2 text-sm font-medium text-io-red transition hover:bg-red-100 cursor-pointer"
        >
          Interromper
        </button>
      ) : (
        <button
          onClick={onReset}
          className="flex shrink-0 items-center gap-1.5 rounded-lg border border-neutral-200 px-3 py-2 text-sm font-medium text-neutral-700 transition hover:bg-neutral-50 cursor-pointer"
        >
          Nova análise
        </button>
      )}
    </div>
    {status === 'running' && (
      <div className="mt-4 flex items-center gap-2 text-sm text-neutral-600">
        <span className="inline-block h-2 w-2 rounded-full bg-io-blue animate-pulse" />
        <span>{stage || 'Processando...'}</span>
      </div>
    )}
  </div>
);

const ErrorBanner: React.FC<{ message: string }> = ({ message }) => (
  <div className="flex items-start gap-2 rounded-xl border border-io-red/30 bg-red-50 px-4 py-3 text-sm text-io-red">
    <span>{message}</span>
  </div>
);

/* ─────────────────────────── Agent Panel ─────────────────────────── */

const AgentPanel: React.FC<{
  messages: ChatMessage[];
  logs: ActivityLog[];
  status: Status;
  stage: string;
  viewedMessageId: string | null;
  onSelectMessage: (id: string) => void;
  onSendFollowUp: (text: string) => void;
  report?: AnalysisReport | null;
  datasetName?: string;
}> = ({
  messages,
  logs,
  status,
  stage,
  viewedMessageId,
  onSelectMessage,
  onSendFollowUp,
  report,
  datasetName,
}) => {
  const [inputText, setInputText] = useState('');
  const [activeTab, setActiveTab] = useState<'chat' | 'activity'>('chat');
  const activityScrollRef = useRef<HTMLDivElement | null>(null);
  const shouldAutoScrollRef = useRef(true);

  useEffect(() => {
    if (status === 'running') {
      setActiveTab('activity');
    }
  }, [status]);

  useEffect(() => {
    const container = activityScrollRef.current;
    if (activeTab === 'activity' && container && shouldAutoScrollRef.current) {
      container.scrollTop = container.scrollHeight;
    }
  }, [logs, activeTab]);

  const handleActivityScroll = () => {
    if (activeTab !== 'activity') return;
    const container = activityScrollRef.current;
    if (!container) return;
    const distanceFromBottom =
      container.scrollHeight - container.scrollTop - container.clientHeight;
    shouldAutoScrollRef.current = distanceFromBottom < 80;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || status === 'running') return;
    onSendFollowUp(inputText.trim());
    setInputText('');
  };

  const suggestions = useMemo(() => {
    const name = (datasetName || report?.dataset_name || '').toLowerCase();
    if (name.includes('sales') || name.includes('finance') || name.includes('operacoes')) {
      return [
        'Identifique outliers ou anomalias nos valores',
        'Destaque os principais ofensores e tendências',
        'Sugira recomendações práticas de conciliação',
      ];
    }
    return [
      'Identifique outliers ou anomalias no dataset',
      'Quais são as correlações mais relevantes?',
      'Apresente recomendações estratégicas baseadas nos dados',
    ];
  }, [report, datasetName]);

  return (
    <div className="rounded-2xl border border-neutral-200 bg-white flex flex-col h-[75vh] relative overflow-hidden">
      <div className="flex items-center gap-2 border-b border-neutral-200 px-5 py-3 text-sm font-semibold text-neutral-800 bg-neutral-50/50">
        <span>Agente Analítico</span>
        {status === 'running' && (
          <span className="ml-auto flex items-center gap-1.5 text-xs text-neutral-500 font-normal">
            {stage || 'Processando...'}
          </span>
        )}
      </div>

      <div className="flex border-b border-neutral-200 bg-neutral-50/30 p-1">
        <button
          onClick={() => setActiveTab('chat')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
            activeTab === 'chat'
              ? 'bg-white text-neutral-800 shadow-2xs border border-neutral-200/50'
              : 'text-neutral-500 hover:text-neutral-800'
          }`}
        >
          <span>Conversa ({messages.filter((m) => m.role === 'assistant').length})</span>
        </button>
        <button
          onClick={() => setActiveTab('activity')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
            activeTab === 'activity'
              ? 'bg-white text-neutral-800 shadow-2xs border border-neutral-200/50'
              : 'text-neutral-500 hover:text-neutral-800'
          }`}
        >
          <span>Atividade do Agente</span>
          {status === 'running' && (
            <span className="h-2 w-2 rounded-full bg-io-blue animate-pulse" />
          )}
        </button>
      </div>

      <div
        ref={activityScrollRef}
        onScroll={handleActivityScroll}
        className="flex-1 overflow-y-auto p-4 space-y-4 flex flex-col no-scrollbar"
      >
        {activeTab === 'chat' ? (
          messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center p-6 text-neutral-400">
              <p className="text-sm font-medium">Sessão do Assistente</p>
              <p className="text-xs max-w-xs mt-1">
                Inicie uma análise para conversar com o agente e aprofundar os insights.
              </p>
            </div>
          ) : (
            messages.map((msg) => {
              const isUser = msg.role === 'user';
              const isActive = viewedMessageId === msg.id;

              if (isUser) {
                return (
                  <div
                    key={msg.id}
                    className="self-end max-w-[85%] bg-neutral-100 border border-neutral-200/80 rounded-2xl rounded-tr-none px-4 py-2.5 text-sm text-neutral-800"
                  >
                    <p className="leading-relaxed font-medium break-words">
                      {msg.text}
                    </p>
                  </div>
                );
              }

              return (
                <div
                  key={msg.id}
                  onClick={() => msg.report && onSelectMessage(msg.id)}
                  className={`self-start max-w-[95%] w-full rounded-2xl rounded-tl-none p-4 border transition text-sm flex flex-col space-y-2.5 ${
                    msg.report ? 'cursor-pointer' : ''
                  } ${
                    isActive
                      ? 'border-blue-200 bg-blue-50/20'
                      : 'border-neutral-200 bg-white hover:border-neutral-300'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 text-xs text-neutral-400">
                    <span className="font-semibold text-neutral-600">
                      Assistente Bot Signature
                    </span>
                    {msg.report && (
                      <span className="text-[11px] text-io-blue font-medium">
                        {isActive ? 'Exibindo no painel' : 'Clique para exibir'}
                      </span>
                    )}
                  </div>

                  {msg.text ? (
                    <div className="space-y-3">
                      <FormattedMarkdown content={msg.text} />
                      {msg.report && (
                        <div
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectMessage(msg.id);
                          }}
                          className={`p-3 rounded-xl border transition-all space-y-2 text-xs text-left ${
                            isActive
                              ? 'border-emerald-200 bg-emerald-50/40'
                              : 'border-neutral-200 bg-neutral-50 hover:border-neutral-300'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <Presentation className="h-4 w-4 text-emerald-600 shrink-0" />
                            <div className="flex-1 min-w-0">
                              <p className="font-bold text-neutral-800 truncate">
                                Relatório Atualizado
                              </p>
                              <p className="text-[10px] text-neutral-500 truncate">
                                {isActive
                                  ? 'Ativo no painel e pronto para PDF'
                                  : 'Clique para aplicar este relatório ao painel'}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    msg.status === 'running' && (
                      <div className="flex items-center gap-2 py-1">
                        <Loader2 className="h-3.5 w-3.5 animate-spin text-io-blue" />
                        <span className="text-xs text-neutral-500 font-mono">
                          {msg.stage || 'Analisando dados...'}
                        </span>
                      </div>
                    )
                  )}

                  {msg.logs && msg.logs.length > 0 && (
                    <div
                      className="pt-2 border-t border-neutral-100/70"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button
                        onClick={() => setActiveTab('activity')}
                        className="text-xs text-io-blue hover:underline font-semibold flex items-center gap-1.5 py-1 cursor-pointer"
                      >
                        Ver etapas completas de execução
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )
        ) : (
          <div className="w-full space-y-3">
            {logs.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center p-6 text-neutral-400">
                <p className="text-sm font-medium">
                  Aguardando atividade do agente...
                </p>
              </div>
            ) : (
              <div className="space-y-3.5 pr-1">
                {logs.map((log) => (
                  <ActivityRow key={log.id} log={log} />
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {status !== 'running' && messages.length > 0 && (
        <div className="px-4 py-2 border-t border-neutral-100 flex flex-wrap gap-1.5 bg-neutral-50/30">
          {suggestions.map((sug) => (
            <button
              key={sug}
              onClick={() => onSendFollowUp(sug)}
              className="text-xs font-medium text-neutral-600 hover:text-neutral-900 bg-neutral-100 hover:bg-neutral-200/80 px-2.5 py-1 rounded-lg transition cursor-pointer"
            >
              {sug}
            </button>
          ))}
        </div>
      )}

      <form onSubmit={handleSubmit} className="border-t border-neutral-200 p-3 bg-white">
        <div className="relative flex items-center">
          <input
            type="text"
            disabled={status === 'running'}
            placeholder={
              status === 'running'
                ? 'Aguarde a conclusão da análise...'
                : 'Faça uma pergunta complementar...'
            }
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            className="w-full pl-4 pr-20 py-3 text-sm rounded-xl border border-neutral-200 focus:border-io-blue/80 outline-none transition bg-neutral-50 focus:bg-white disabled:bg-neutral-100"
          />
          <button
            type="submit"
            disabled={status === 'running' || !inputText.trim()}
            className="absolute right-2 top-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 text-white text-xs font-semibold hover:bg-io-blue transition disabled:bg-neutral-200 disabled:text-neutral-400 cursor-pointer"
          >
            Enviar
          </button>
        </div>
      </form>
    </div>
  );
};

const ActivityRow: React.FC<{ log: ActivityLog }> = ({ log }) => {
  const [open, setOpen] = useState(false);

  if (log.type === 'thinking' || log.type === 'text') {
    const isThinking = log.type === 'thinking';
    return (
      <div className="flex gap-2 text-sm">
        <span className="mt-0.5 shrink-0 text-neutral-400 font-bold">•</span>
        <div
          className={`flex-1 min-w-0 ${
            isThinking ? 'italic text-neutral-500' : 'text-neutral-700'
          }`}
        >
          <FormattedMarkdown content={log.content} />
        </div>
      </div>
    );
  }

  if (log.type === 'tool_call') {
    const args = (log.args || {}) as Record<string, any>;
    let cmd = args.command || args.code || args.content;
    let pathVal = args.path || args.file || args.TargetFile;

    if (!cmd && args.arguments && typeof args.arguments === 'object') {
      const subArgs = args.arguments as Record<string, any>;
      cmd = subArgs.command || subArgs.code || subArgs.content;
      pathVal = pathVal || subArgs.path || subArgs.file || subArgs.TargetFile;
    }

    cmd = cmd ? String(cmd) : '';
    const displayPath = pathVal ? String(pathVal) : '';
    const hasDetails = Boolean(cmd || Object.keys(args).length > 0);

    return (
      <div className="rounded-lg border border-neutral-200 bg-neutral-50 text-sm">
        <button
          onClick={() => setOpen((o) => !o)}
          className={`flex w-full items-center gap-2 px-3 py-2 text-left ${
            !hasDetails ? 'pointer-events-none' : ''
          }`}
        >
          <span className="font-mono text-[11px] text-neutral-600 break-all">
            {log.name || 'tool'}{' '}
            {displayPath ? (
              <span className="text-neutral-400"> {displayPath}</span>
            ) : (
              ''
            )}
          </span>
          {hasDetails && (
            <span className="ml-auto text-xs text-neutral-400 font-bold transition">
              {open ? '▲' : '▼'}
            </span>
          )}
        </button>
        {open && hasDetails && (
          <pre className="overflow-x-auto max-h-60 border-t border-neutral-200 px-3 py-2 font-mono text-[10px] leading-relaxed text-neutral-700">
            {cmd || JSON.stringify(args, null, 2)}
          </pre>
        )}
      </div>
    );
  }

  if (log.type === 'tool_result') {
    return (
      <div className="rounded-lg border border-neutral-200 text-sm">
        <button
          onClick={() => setOpen((o) => !o)}
          className="flex w-full items-center gap-2 px-3 py-2 text-left"
        >
          <span className="text-xs text-neutral-500 font-medium">
            Resultado{log.name ? ` · ${log.name}` : ''}
          </span>
          <span className="ml-auto text-xs text-neutral-400 font-bold transition">
            {open ? '▲' : '▼'}
          </span>
        </button>
        {open && (
          <pre className="max-h-60 overflow-auto border-t border-neutral-200 px-3 py-2 font-mono text-[11px] leading-relaxed text-neutral-600">
            {log.result}
          </pre>
        )}
      </div>
    );
  }

  if (log.type === 'error') {
    return (
      <div className="flex gap-2 text-sm text-io-red font-medium">
        <span>Erro: {log.content}</span>
      </div>
    );
  }

  return (
    <div className="flex gap-2 text-sm text-neutral-500">
      <span className="mt-0.5 shrink-0">·</span>
      <div className="flex-1 min-w-0">
        <FormattedMarkdown content={log.content} />
      </div>
    </div>
  );
};

/* ─────────────────────────── ReportView (Preservado e Traduzido) ─────────────────────────── */

type DashboardTab =
  | 'overview'
  | 'charts'
  | 'tables'
  | 'recommendations'
  | 'print';

const ReportView: React.FC<{ report: AnalysisReport }> = ({ report }) => {
  const [activeTab, setActiveTab] = useState<DashboardTab>('overview');
  const [zoomedChart, setZoomedChart] = useState<ReportChart | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isExportingPdf, setIsExportingPdf] = useState(false);

  const validCharts = useMemo(() => {
    return report.charts?.filter((c) => c.image) || [];
  }, [report.charts]);

  const downloadJson = () => {
    const blob = new Blob([JSON.stringify(report, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(report.dataset_name || 'relatorio').replace(
      /[^a-z0-9]/gi,
      '_',
    )}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportDashboardToPDF = async () => {
    setIsExportingPdf(true);
    try {
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pageHeight = pdf.internal.pageSize.getHeight();
      const pageWidth = pdf.internal.pageSize.getWidth();
      const margin = 15;
      const contentWidth = pageWidth - margin * 2;
      let y = 15;

      const checkPageBreak = (neededHeight: number) => {
        if (y + neededHeight > pageHeight - 20) {
          pdf.addPage();
          y = 20;
          return true;
        }
        return false;
      };

      pdf.setFillColor(66, 133, 244);
      pdf.rect(0, 0, pageWidth, 4, 'F');

      y = 15;
      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(9);
      pdf.setTextColor(66, 133, 244);
      pdf.text(
        `${(report.dataset_name || 'BOT SIGNATURE').toUpperCase()} · RELATÓRIO EXECUTIVO`,
        margin,
        y,
      );

      y += 8;
      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(18);
      pdf.setTextColor(31, 41, 55);
      const titleLines = pdf.splitTextToSize(
        report.title || 'Relatório de Análise',
        contentWidth,
      );
      pdf.text(titleLines, margin, y);
      y += titleLines.length * 8 + 2;

      if (report.question) {
        pdf.setFont('helvetica', 'normal');
        pdf.setFontSize(10);
        pdf.setTextColor(75, 85, 99);
        const qLines = pdf.splitTextToSize(
          `Pergunta: ${report.question}`,
          contentWidth,
        );
        pdf.text(qLines, margin, y);
        y += qLines.length * 5.5 + 4;
      }

      if (report.executive_summary) {
        pdf.setFont('helvetica', 'bold');
        pdf.setFontSize(12);
        pdf.setTextColor(31, 41, 55);
        pdf.text('Resumo Executivo', margin, y);
        y += 6;

        pdf.setFont('helvetica', 'normal');
        pdf.setFontSize(9.5);
        pdf.setTextColor(55, 65, 81);
        const execLines = pdf.splitTextToSize(
          report.executive_summary,
          contentWidth - 10,
        );
        const boxHeight = execLines.length * 5 + 8;
        checkPageBreak(boxHeight + 5);
        pdf.setFillColor(243, 244, 246);
        pdf.roundedRect(margin, y, contentWidth, boxHeight, 2, 2, 'F');
        pdf.text(execLines, margin + 5, y + 6);
        y += boxHeight + 10;
      }

      if (report.tables && report.tables.length > 0) {
        for (const table of report.tables) {
          checkPageBreak(20);
          autoTable(pdf, {
            startY: y,
            margin: { left: margin, right: margin },
            head: [table.columns],
            body: table.rows
              .slice(0, 40)
              .map((row) =>
                row.map((cell) => (cell === null ? '—' : String(cell))),
              ),
          });
          y = (pdf as any).lastAutoTable?.finalY
            ? (pdf as any).lastAutoTable.finalY + 10
            : y + 30;
        }
      }

      const cleanName = (report.dataset_name || 'Bot_Signature').replace(
        /[^a-zA-Z0-9]/g,
        '_',
      );
      pdf.save(`${cleanName}_Relatorio_BotSignature.pdf`);
    } catch (err) {
      console.error('PDF export failed:', err);
    } finally {
      setIsExportingPdf(false);
    }
  };

  const kpiInsights = useMemo(() => {
    return report.insights?.slice(0, 4) || [];
  }, [report.insights]);

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border border-neutral-200 bg-white p-6 relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1.5 gradient-io" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pt-1">
          <div>
            <div className="flex items-center gap-2 text-xs text-neutral-500">
              <span className="font-semibold text-io-blue">
                {report.dataset_name}
              </span>
              {report.generated_at && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">
                    {report.generated_at}
                  </span>
                </>
              )}
            </div>
            <h2 className="mt-1.5 text-2xl font-bold tracking-tight text-neutral-900">
              {report.title}
            </h2>
            <p className="mt-1 text-sm text-neutral-600">
              <span className="font-semibold text-neutral-800">Consulta: </span>
              {report.question}
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0 self-start md:self-center">
            <button
              onClick={exportDashboardToPDF}
              disabled={isExportingPdf}
              className="flex items-center gap-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 px-4 py-2.5 text-xs font-semibold text-white transition disabled:opacity-60 cursor-pointer"
            >
              {isExportingPdf ? 'Gerando PDF...' : 'Exportar PDF'}
            </button>
            <button
              onClick={downloadJson}
              className="flex items-center gap-1.5 rounded-xl border border-neutral-200 bg-neutral-50 px-3.5 py-2.5 text-xs font-medium text-neutral-700 transition hover:bg-neutral-100 cursor-pointer"
            >
              JSON
            </button>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-neutral-100 flex flex-wrap gap-1.5 overflow-x-auto no-scrollbar">
          <TabBtn
            active={activeTab === 'overview'}
            onClick={() => setActiveTab('overview')}
            label="Resumo e KPIs"
          />
          {validCharts.length > 0 && (
            <TabBtn
              active={activeTab === 'charts'}
              onClick={() => setActiveTab('charts')}
              label={`Gráficos (${validCharts.length})`}
            />
          )}
          {report.tables && report.tables.length > 0 && (
            <TabBtn
              active={activeTab === 'tables'}
              onClick={() => setActiveTab('tables')}
              label={`Tabelas (${report.tables.length})`}
            />
          )}
          <TabBtn
            active={activeTab === 'recommendations'}
            onClick={() => setActiveTab('recommendations')}
            label="Insights e Recomendações"
          />
        </div>
      </section>

      {activeTab === 'overview' && (
        <div className="space-y-6">
          {kpiInsights.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
              {kpiInsights.map((kpi, idx) => (
                <div
                  key={idx}
                  className="rounded-2xl border border-neutral-200 bg-white p-5 flex flex-col justify-between min-w-0"
                >
                  <span className="text-xs font-semibold text-neutral-500 truncate">
                    {kpi.metric || kpi.title}
                  </span>
                  <div className="mt-2 text-2xl font-bold text-neutral-900 font-mono tabular-nums tracking-tight break-words py-1">
                    {kpi.value || kpi.title}
                  </div>
                  <p className="mt-1 text-xs text-neutral-600 leading-relaxed">
                    {kpi.detail}
                  </p>
                </div>
              ))}
            </div>
          )}

          <div className="rounded-2xl border border-neutral-200 bg-white p-6">
            <div className="text-sm font-bold text-neutral-900 mb-2">
              Síntese Executiva
            </div>
            <FormattedMarkdown content={report.executive_summary} />
          </div>

          {report.recommendations && report.recommendations.length > 0 && (
            <div className="rounded-2xl border border-neutral-200 bg-white p-6">
              <div className="text-sm font-bold text-neutral-900 mb-3">
                Recomendações Prioritárias
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                {report.recommendations.map((rec, rIdx) => (
                  <div
                    key={rIdx}
                    className="flex items-start gap-2.5 text-xs sm:text-sm text-neutral-700 bg-neutral-50 p-3.5 rounded-xl border border-neutral-200/70"
                  >
                    <span className="font-mono font-bold text-io-blue">
                      0{rIdx + 1}.
                    </span>
                    <span className="leading-snug">{rec}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'charts' && (
        <div className="grid gap-6 sm:grid-cols-2">
          {validCharts.map((c, i) => (
            <ChartCard key={i} chart={c} onZoom={() => setZoomedChart(c)} />
          ))}
        </div>
      )}

      {activeTab === 'tables' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-neutral-200">
            <span className="text-sm font-bold text-neutral-800">
              Tabelas de Suporte ({report.tables?.length || 0})
            </span>
            <input
              type="text"
              placeholder="Filtrar linhas nas tabelas..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full sm:w-72 px-3.5 py-2 text-xs rounded-lg border border-neutral-300 focus:border-io-blue outline-none"
            />
          </div>
          {report.tables?.map((t, i) => (
            <DataTable key={i} table={t} searchQuery={searchQuery} />
          ))}
        </div>
      )}

      {activeTab === 'recommendations' && (
        <div className="grid gap-4 sm:grid-cols-2">
          {report.insights?.map((ins, i) => (
            <div
              key={i}
              className="rounded-xl border border-neutral-200 bg-white p-5"
            >
              <div className="flex items-baseline justify-between gap-2">
                <h3 className="font-semibold text-neutral-900 text-base">
                  {ins.title}
                </h3>
                {ins.value && (
                  <span className="font-mono text-sm font-bold text-io-blue">
                    {ins.value}
                  </span>
                )}
              </div>
              {ins.metric && (
                <p className="mt-1 text-xs font-mono text-neutral-400">
                  {ins.metric}
                </p>
              )}
              <p className="mt-2 text-sm leading-relaxed text-neutral-600">
                {ins.detail}
              </p>
            </div>
          ))}
        </div>
      )}

      <AnimatePresence>
        {zoomedChart && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setZoomedChart(null)}
            className="fixed inset-0 z-50 bg-neutral-900/80 backdrop-blur-xs flex items-center justify-center p-4 sm:p-8"
          >
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-5xl w-full overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-neutral-100 bg-neutral-50">
                <div>
                  <h3 className="font-bold text-neutral-900 text-lg">
                    {zoomedChart.title}
                  </h3>
                  {zoomedChart.caption && (
                    <p className="text-xs text-neutral-500 mt-0.5">
                      {zoomedChart.caption}
                    </p>
                  )}
                </div>
                <button
                  onClick={() => setZoomedChart(null)}
                  className="rounded-xl px-3 py-1.5 text-xs font-semibold text-neutral-500 hover:bg-neutral-200 cursor-pointer"
                >
                  Fechar
                </button>
              </div>
              <div className="p-6 overflow-auto flex-1 flex items-center justify-center bg-white">
                <ChartImage
                  src={zoomedChart.image || ''}
                  alt={zoomedChart.title}
                  className="max-h-[75vh] w-auto object-contain mx-auto"
                />
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const TabBtn: React.FC<{
  active: boolean;
  onClick: () => void;
  label: string;
}> = ({ active, onClick, label }) => (
  <button
    onClick={onClick}
    className={`px-4 py-2 rounded-xl text-xs font-semibold transition cursor-pointer whitespace-nowrap ${
      active
        ? 'bg-neutral-900 text-white'
        : 'text-neutral-600 hover:bg-neutral-100 hover:text-neutral-900'
    }`}
  >
    {label}
  </button>
);

const ChartImage: React.FC<{ src: string; alt: string; className?: string }> = ({
  src,
  alt,
  className = '',
}) => {
  const [error, setError] = useState(false);
  if (error || !src) {
    return (
      <div
        className={`flex flex-col items-center justify-center p-6 bg-neutral-50 rounded-xl border border-dashed border-neutral-300 text-neutral-400 text-xs text-center min-h-[140px] w-full ${className}`}
      >
        <span>Imagem do gráfico indisponível</span>
      </div>
    );
  }
  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      className={className}
      onError={() => setError(true)}
    />
  );
};

const ChartCard: React.FC<{ chart: ReportChart; onZoom?: () => void }> = ({
  chart,
  onZoom,
}) => (
  <figure className="overflow-hidden rounded-2xl border border-neutral-200 bg-white flex flex-col group transition hover:border-neutral-300">
    <div className="relative bg-white p-3 flex-1 flex items-center justify-center min-h-[220px]">
      <ChartImage
        src={chart.image || ''}
        alt={chart.title}
        className="w-full h-auto max-h-72 object-contain mx-auto"
      />
      {onZoom && (
        <button
          onClick={onZoom}
          className="absolute right-3 top-3 opacity-0 group-hover:opacity-100 transition bg-neutral-900/75 hover:bg-neutral-900 text-white px-2.5 py-1.5 rounded-xl text-xs cursor-pointer"
        >
          Ampliar
        </button>
      )}
    </div>
    <figcaption className="border-t border-neutral-100 px-4 py-3 bg-neutral-50/50">
      <p className="text-sm font-bold text-neutral-800">{chart.title}</p>
      {chart.caption && (
        <p className="mt-0.5 text-xs text-neutral-500 line-clamp-2">
          {chart.caption}
        </p>
      )}
    </figcaption>
  </figure>
);

const DataTable: React.FC<{ table: ReportTable; searchQuery?: string }> = ({
  table,
  searchQuery = '',
}) => {
  const filteredRows = useMemo(() => {
    if (!searchQuery.trim()) return table.rows;
    const lower = searchQuery.toLowerCase();
    return table.rows.filter((row) =>
      row.some(
        (cell) => cell !== null && String(cell).toLowerCase().includes(lower),
      ),
    );
  }, [table.rows, searchQuery]);

  return (
    <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white">
      <div className="border-b border-neutral-100 px-5 py-3.5 flex items-center justify-between bg-neutral-50/50">
        <div>
          <p className="text-sm font-bold text-neutral-800">{table.title}</p>
          {table.caption && (
            <p className="mt-0.5 text-xs text-neutral-500">{table.caption}</p>
          )}
        </div>
        <span className="text-xs font-mono tabular-nums text-neutral-500">
          {filteredRows.length} registros
        </span>
      </div>
      <div className="overflow-x-auto max-h-[500px]">
        <table className="w-full text-xs">
          <thead className="sticky top-0 z-10 bg-neutral-100">
            <tr className="border-b border-neutral-200 text-left">
              {table.columns.map((c, i) => (
                <th
                  key={i}
                  className="px-4 py-2.5 font-bold text-neutral-700 whitespace-nowrap"
                >
                  {c}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-neutral-100">
            {filteredRows.map((row, ri) => (
              <tr key={ri} className="transition hover:bg-neutral-50/80">
                {row.map((cell, ci) => (
                  <td
                    key={ci}
                    className="px-4 py-2.5 text-neutral-700 whitespace-nowrap font-mono tabular-nums"
                  >
                    {cell === null ? (
                      <span className="text-neutral-300">—</span>
                    ) : (
                      String(cell)
                    )}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default App;
