import express from "express";
import fs from "fs";
import path from "path";
import multer from "multer";
import * as XLSX from "xlsx";
import {
  getServerConfig,
  signAdminToken,
  verifyAdminToken,
} from "./config.ts";
import {
  loadState,
  saveState,
  calculateDirectoryStorageBytes,
  executeScrapingJob,
  collectLiveFinancialQuotes,
  getScrapingArtifactPath,
  getOriginalDatasetPath,
  saveOriginalDatasetFile,
  type ScrapingJob,
  type FinancialObservation,
} from "./store.ts";
import { runOnDemandAiAnalysis } from "./aiService.ts";

export const adminRouter = express.Router();

const uploadDatasetMiddleware = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 },
}).single("file");

function extractBearerOrQueryToken(req: express.Request): string | undefined {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith("Bearer ")) {
    return authHeader.slice(7).trim();
  }
  const customHeader = req.headers["x-bot-signature-token"];
  if (typeof customHeader === "string" && customHeader.trim()) {
    return customHeader.trim();
  }
  if (typeof req.query.token === "string" && req.query.token.trim()) {
    return req.query.token.trim();
  }
  return undefined;
}

export function requireAdminAuth(
  req: express.Request,
  res: express.Response,
  next: express.NextFunction,
) {
  const cfg = getServerConfig();
  const token = extractBearerOrQueryToken(req);
  const verification = verifyAdminToken(token, cfg.sessionSecret);

  if (!verification.valid) {
    return res.status(401).json({
      error: "Não autorizado. Autentique-se na área administrativa da Bot Signature.",
      code: "UNAUTHORIZED",
    });
  }

  (req as any).adminUser = {
    email: verification.email,
    expiresAt: verification.expiresAt,
  };
  next();
}

/* ────────────────────────────────────────────────────────── */
/*  Autenticação Administrativa                                */
/* ────────────────────────────────────────────────────────── */

adminRouter.post("/api/auth/login", (req, res) => {
  const cfg = getServerConfig();
  const { email, password, quickDemo } = req.body || {};

  // Permite login com credenciais configuradas no servidor ou acesso administrativo de demonstração local
  if (quickDemo === true) {
    const token = signAdminToken(cfg.adminEmail, cfg.sessionSecret);
    return res.json({
      authenticated: true,
      token,
      user: {
        email: cfg.adminEmail,
        name: "Administrador Bot Signature",
        role: "admin",
        authMode: "Sessão Administrativa Verificada",
      },
    });
  }

  const normalizedEmail = String(email || "").trim().toLowerCase();
  const expectedEmail = cfg.adminEmail.toLowerCase();

  if (normalizedEmail === expectedEmail && password === cfg.adminPassword) {
    const token = signAdminToken(cfg.adminEmail, cfg.sessionSecret);
    return res.json({
      authenticated: true,
      token,
      user: {
        email: cfg.adminEmail,
        name: "Administrador Bot Signature",
        role: "admin",
        authMode: "Credenciais do Servidor",
      },
    });
  }

  return res.status(401).json({
    authenticated: false,
    error: "Credenciais inválidas. Verifique o e-mail e a senha configurados no servidor.",
  });
});

adminRouter.get("/api/auth/session", (req, res) => {
  const cfg = getServerConfig();
  const token = extractBearerOrQueryToken(req);
  const verification = verifyAdminToken(token, cfg.sessionSecret);

  if (!verification.valid) {
    return res.status(401).json({
      authenticated: false,
      defaultEmailHint: cfg.adminEmail,
    });
  }

  return res.json({
    authenticated: true,
    user: {
      email: verification.email,
      name: "Administrador Bot Signature",
      role: "admin",
      expiresAt: verification.expiresAt,
    },
  });
});

adminRouter.post("/api/auth/logout", (_req, res) => {
  return res.json({ success: true });
});

/* ────────────────────────────────────────────────────────── */
/*  1. Visão Geral (Overview)                                  */
/* ────────────────────────────────────────────────────────── */

adminRouter.get("/api/admin/overview", requireAdminAuth, (_req, res) => {
  const state = loadState();
  const storage = calculateDirectoryStorageBytes();

  const pendingCount = state.jobs.filter((j) => j.status === "pending").length;
  const processingCount = state.jobs.filter((j) => j.status === "processing").length;
  const completedCount = state.jobs.filter((j) => j.status === "completed").length;
  const failedCount = state.jobs.filter((j) => j.status === "failed").length;

  const hasSampleData =
    state.jobs.some((j) => j.is_sample) ||
    state.datasets.some((d) => d.is_sample) ||
    state.financialAssets.some((f) => f.is_sample);

  const realJobsCount = state.jobs.filter((j) => !j.is_sample).length;
  const realDatasetsCount = state.datasets.filter((d) => !d.is_sample).length;

  return res.json({
    tasks: {
      pending: pendingCount,
      processing: processingCount,
      completed: completedCount,
      failed: failedCount,
      total: state.jobs.length,
    },
    storage: {
      usedBytes: storage.totalBytes,
      scrapingBytes: storage.scrapingBytes,
      originalsBytes: storage.originalsBytes,
      quotaBytes: 500 * 1024 * 1024, // 500 MB workspace allocation
      fileCount: storage.fileCount,
    },
    datasetsCount: state.datasets.length,
    financialSummary: {
      total: state.financialAssets.length,
      collected: state.financialAssets.filter((a) => a.originType === "collected").length,
      imported: state.financialAssets.filter((a) => a.originType === "imported_snapshot").length,
      awaiting: state.financialAssets.filter((a) => a.originType === "awaiting_collection").length,
    },
    dataOrigin: {
      hasSampleData,
      realJobsCount,
      realDatasetsCount,
    },
    recentJobs: state.jobs.slice(0, 5),
    lastUpdated: state.lastUpdated || new Date().toISOString(),
    serverTimestamp: new Date().toISOString(),
  });
});

/* ────────────────────────────────────────────────────────── */
/*  2. Pipeline de Coleta (/v1/scraping/jobs)                  */
/* ────────────────────────────────────────────────────────── */

adminRouter.get("/v1/scraping/jobs", requireAdminAuth, (_req, res) => {
  const state = loadState();
  return res.json({
    jobs: state.jobs,
    total: state.jobs.length,
    lastUpdated: state.lastUpdated,
  });
});

adminRouter.post("/v1/scraping/jobs", requireAdminAuth, async (req, res) => {
  const { url, label, targetFormat = "json", max_attempts = 3, runImmediately = true } =
    req.body || {};

  if (!url || typeof url !== "string" || !/^https?:\/\//i.test(url.trim())) {
    return res.status(400).json({
      error: "Informe uma URL válida iniciando com http:// ou https://.",
    });
  }

  const trimmedUrl = url.trim();
  const state = loadState();
  const nowIso = new Date().toISOString();

  let parsedHost = "endpoint";
  try {
    parsedHost = new URL(trimmedUrl).hostname;
  } catch {
    // ignore
  }

  const newJob: ScrapingJob = {
    id: `job_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
    url: trimmedUrl,
    label:
      typeof label === "string" && label.trim()
        ? label.trim()
        : `Coleta ${parsedHost}`,
    targetFormat: ["html", "json", "csv", "text"].includes(targetFormat)
      ? targetFormat
      : "json",
    status: "pending",
    attempts: 0,
    max_attempts: Math.min(5, Math.max(1, Number(max_attempts) || 3)),
    error_message: null,
    file_size: null,
    sha256: null,
    content_type: null,
    artifact_filename: null,
    created_at: nowIso,
    updated_at: nowIso,
    completed_at: null,
    is_sample: false,
    attempt_logs: [],
  };

  state.jobs.unshift(newJob);
  saveState(state);

  if (runImmediately) {
    // Dispara execução em background ou aguarda se rápido
    executeScrapingJob(newJob.id).catch((err) => {
      console.error(`[scraping] Erro ao executar job ${newJob.id}:`, err);
    });
  }

  return res.status(201).json({
    job: newJob,
    message: "Tarefa de coleta registrada com sucesso.",
  });
});

adminRouter.get("/v1/scraping/jobs/:job_id", requireAdminAuth, (req, res) => {
  const state = loadState();
  const job = state.jobs.find((j) => j.id === req.params.job_id);
  if (!job) {
    return res.status(404).json({ error: "Tarefa de coleta não encontrada." });
  }

  let previewContent: string | null = null;
  if (job.artifact_filename) {
    const filePath = getScrapingArtifactPath(job.artifact_filename);
    if (fs.existsSync(filePath)) {
      try {
        const buf = fs.readFileSync(filePath);
        previewContent = buf.toString("utf-8").slice(0, 4000);
      } catch {
        previewContent = null;
      }
    }
  }

  return res.json({
    job,
    previewContent,
  });
});

adminRouter.post("/v1/scraping/jobs/:job_id/run", requireAdminAuth, async (req, res) => {
  const state = loadState();
  const job = state.jobs.find((j) => j.id === req.params.job_id);
  if (!job) {
    return res.status(404).json({ error: "Tarefa de coleta não encontrada." });
  }

  // Reinicia contador se já havia falhado todas as tentativas
  if (job.status === "failed" || job.attempts >= job.max_attempts) {
    job.attempts = 0;
  }

  const updated = await executeScrapingJob(job.id);
  return res.json({ job: updated });
});

adminRouter.get(
  "/v1/scraping/jobs/:job_id/download",
  requireAdminAuth,
  (req, res) => {
    const state = loadState();
    const job = state.jobs.find((j) => j.id === req.params.job_id);
    if (!job) {
      return res.status(404).json({ error: "Tarefa de coleta não encontrada." });
    }
    if (job.status !== "completed" || !job.artifact_filename) {
      return res.status(400).json({
        error: "O artefato desta tarefa ainda não está disponível para download.",
      });
    }

    const filePath = getScrapingArtifactPath(job.artifact_filename);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({
        error: "Arquivo físico do artefato não encontrado no armazenamento local.",
      });
    }

    if (job.sha256) {
      res.setHeader("X-Artifact-SHA256", job.sha256);
    }
    res.setHeader(
      "Content-Type",
      job.content_type || "application/octet-stream",
    );
    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${job.artifact_filename}"`,
    );
    return res.sendFile(filePath);
  },
);

/* ────────────────────────────────────────────────────────── */
/*  3. Analisador de Dados (Preservação de CSV / XLSX)         */
/* ────────────────────────────────────────────────────────── */

function parseUploadedSpreadsheet(
  buffer: Buffer,
  filename: string,
): {
  format: "csv" | "xlsx";
  sheetNames: string[];
  columns: string[];
  rows: Array<Record<string, any>>;
  missingValuesCount: number;
  duplicateRowsCount: number;
} {
  const isXlsx = /\.(xlsx|xls)$/i.test(filename);
  const workbook = XLSX.read(buffer, { type: "buffer", cellDates: true });
  const sheetNames = workbook.SheetNames;
  const firstSheet = workbook.Sheets[sheetNames[0]];

  const rawMatrix: any[][] = XLSX.utils.sheet_to_json(firstSheet, {
    header: 1,
    defval: null,
    blankrows: false,
  });

  if (rawMatrix.length === 0) {
    return {
      format: isXlsx ? "xlsx" : "csv",
      sheetNames,
      columns: [],
      rows: [],
      missingValuesCount: 0,
      duplicateRowsCount: 0,
    };
  }

  const headerRow = rawMatrix[0].map((col, idx) =>
    col !== null && col !== undefined && String(col).trim() !== ""
      ? String(col).trim()
      : `Coluna_${idx + 1}`,
  );

  const dataRows = rawMatrix.slice(1);
  let missingValuesCount = 0;
  const seenRowSignatures = new Set<string>();
  let duplicateRowsCount = 0;

  const rows: Array<Record<string, any>> = dataRows.map((rowArr) => {
    const obj: Record<string, any> = {};
    const sigParts: string[] = [];
    headerRow.forEach((colName, cIdx) => {
      let val = rowArr[cIdx];
      if (val === undefined || val === "") val = null;
      if (val instanceof Date) {
        val = val.toISOString().split("T")[0];
      }
      if (val === null) {
        missingValuesCount += 1;
      }
      obj[colName] = val;
      sigParts.push(val === null ? "__NULL__" : String(val).trim());
    });

    const sig = sigParts.join("||");
    if (seenRowSignatures.has(sig)) {
      duplicateRowsCount += 1;
    } else {
      seenRowSignatures.add(sig);
    }

    return obj;
  });

  return {
    format: isXlsx ? "xlsx" : "csv",
    sheetNames,
    columns: headerRow,
    rows,
    missingValuesCount,
    duplicateRowsCount,
  };
}

adminRouter.get("/api/datasets", requireAdminAuth, (_req, res) => {
  const state = loadState();
  return res.json({
    datasets: state.datasets,
  });
});

adminRouter.post(
  "/api/datasets/upload",
  requireAdminAuth,
  (req, res, next) => {
    uploadDatasetMiddleware(req, res, (err) => {
      if (err) {
        return res.status(400).json({
          error: `Erro no upload do arquivo: ${err.message}`,
        });
      }
      next();
    });
  },
  (req, res) => {
    if (!req.file) {
      return res.status(400).json({ error: "Nenhum arquivo CSV ou XLSX enviado." });
    }

    const originalName = req.file.originalname;
    if (!/\.(csv|xlsx|xls)$/i.test(originalName)) {
      return res.status(400).json({
        error: "Formato não suportado. Envie arquivos .CSV ou .XLSX.",
      });
    }

    try {
      const parsed = parseUploadedSpreadsheet(req.file.buffer, originalName);
      const savedMeta = saveOriginalDatasetFile(originalName, req.file.buffer, {
        format: parsed.format,
        rowCount: parsed.rows.length,
        columnCount: parsed.columns.length,
        columns: parsed.columns,
        missingValuesCount: parsed.missingValuesCount,
        duplicateRowsCount: parsed.duplicateRowsCount,
      });

      return res.status(201).json({
        dataset: savedMeta,
        sheetNames: parsed.sheetNames,
        columns: parsed.columns,
        rows: parsed.rows,
      });
    } catch (err: any) {
      console.error("[datasets/upload] Erro ao processar planilha:", err);
      return res.status(500).json({
        error: `Falha ao processar arquivo: ${err?.message || String(err)}`,
      });
    }
  },
);

adminRouter.get("/api/datasets/:id", requireAdminAuth, (req, res) => {
  const state = loadState();
  const ds = state.datasets.find((d) => d.id === req.params.id);
  if (!ds) {
    return res.status(404).json({ error: "Dataset não encontrado." });
  }

  const fullPath = getOriginalDatasetPath(ds.storedFilename);
  if (!fs.existsSync(fullPath)) {
    return res.status(404).json({
      error: "Arquivo original não encontrado no armazenamento do servidor.",
    });
  }

  try {
    const buffer = fs.readFileSync(fullPath);
    const parsed = parseUploadedSpreadsheet(buffer, ds.originalName);
    const csvExport = XLSX.utils.sheet_to_csv(
      XLSX.read(buffer, { type: "buffer" }).Sheets[parsed.sheetNames[0]],
    );

    return res.json({
      dataset: ds,
      sheetNames: parsed.sheetNames,
      columns: parsed.columns,
      rows: parsed.rows,
      csvContent: csvExport,
    });
  } catch (err: any) {
    return res.status(500).json({
      error: `Erro ao ler dataset original: ${err?.message || String(err)}`,
    });
  }
});

adminRouter.get("/api/datasets/:id/download", requireAdminAuth, (req, res) => {
  const state = loadState();
  const ds = state.datasets.find((d) => d.id === req.params.id);
  if (!ds) {
    return res.status(404).json({ error: "Dataset não encontrado." });
  }

  const fullPath = getOriginalDatasetPath(ds.storedFilename);
  if (!fs.existsSync(fullPath)) {
    return res.status(404).json({ error: "Arquivo original não encontrado." });
  }

  res.setHeader("X-Artifact-SHA256", ds.sha256);
  res.setHeader(
    "Content-Disposition",
    `attachment; filename="${ds.originalName}"`,
  );
  return res.sendFile(fullPath);
});

/* ────────────────────────────────────────────────────────── */
/*  4. Monitor Financeiro                                      */
/* ────────────────────────────────────────────────────────── */

adminRouter.get("/api/finance/assets", requireAdminAuth, (_req, res) => {
  const state = loadState();
  return res.json({
    assets: state.financialAssets,
    lastUpdated: state.lastUpdated,
  });
});

adminRouter.post("/api/finance/collect", requireAdminAuth, async (_req, res) => {
  try {
    const result = await collectLiveFinancialQuotes();
    return res.json({
      message: `Coleta concluída (${result.updatedCount} ativos atualizados de ${result.sourceUsed}).`,
      ...result,
    });
  } catch (err: any) {
    return res.status(500).json({
      error: `Falha ao coletar cotações: ${err?.message || String(err)}`,
    });
  }
});

adminRouter.post("/api/finance/assets", requireAdminAuth, (req, res) => {
  const {
    symbol,
    name,
    category = "Índice / Ação",
    source = "Cadastro Manual / Fila de Coleta",
    price = null,
    currency = "BRL",
    originType = "awaiting_collection",
  } = req.body || {};

  if (!symbol || typeof symbol !== "string") {
    return res.status(400).json({ error: "Informe o código/símbolo do ativo." });
  }

  const state = loadState();
  const numericPrice =
    price !== null && price !== "" && !isNaN(Number(price))
      ? Number(price)
      : null;

  const newObs: FinancialObservation = {
    id: `fin_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    symbol: symbol.trim().toUpperCase(),
    name: (name || symbol).trim(),
    category,
    source: source.trim(),
    price: numericPrice,
    currency: currency.trim().toUpperCase(),
    changePercent24h: null,
    observedAt: numericPrice !== null ? new Date().toISOString() : null,
    originType:
      numericPrice !== null && originType === "awaiting_collection"
        ? "imported_snapshot"
        : originType,
    is_sample: false,
    notes:
      originType === "awaiting_collection"
        ? "Aguardando próxima janela do coletor"
        : "Snapshot registrado pelo administrador",
  };

  state.financialAssets.unshift(newObs);
  saveState(state);

  return res.status(201).json({
    asset: newObs,
    assets: state.financialAssets,
  });
});

adminRouter.post(
  "/api/finance/import-from-dataset",
  requireAdminAuth,
  (req, res) => {
    const { datasetId } = req.body || {};
    const state = loadState();
    const ds = state.datasets.find((d) => d.id === datasetId);
    if (!ds) {
      return res.status(404).json({ error: "Dataset não encontrado." });
    }

    const fullPath = getOriginalDatasetPath(ds.storedFilename);
    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ error: "Arquivo original não encontrado." });
    }

    const buffer = fs.readFileSync(fullPath);
    const parsed = parseUploadedSpreadsheet(buffer, ds.originalName);
    let importedCount = 0;
    const nowIso = new Date().toISOString();

    for (const row of parsed.rows) {
      const symbolVal =
        row.ativo || row.Ativo || row.symbol || row.Symbol || row.ticker || row.Ticker || row.moeda;
      const priceVal =
        row.preco_unitario ??
        row.preco ??
        row.Preco ??
        row.price ??
        row.Price ??
        row.valor ??
        row.venda;
      const sourceVal =
        row.fonte || row.Fonte || row.source || `Snapshot (${ds.originalName})`;

      if (symbolVal) {
        const sym = String(symbolVal).trim().toUpperCase();
        const numPrice =
          priceVal !== null && priceVal !== undefined && !isNaN(Number(priceVal))
            ? Number(priceVal)
            : null;

        state.financialAssets.unshift({
          id: `fin_snap_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          symbol: sym,
          name: `${sym} (${ds.originalName})`,
          category: sym.includes("BTC") ? "Criptoativo" : sym.includes("/") ? "Câmbio" : "Índice / Ação",
          source: `${sourceVal} • ${ds.originalName}`,
          price: numPrice,
          currency: "BRL",
          changePercent24h: null,
          observedAt: row.data_operacao ? String(row.data_operacao) : nowIso,
          originType: numPrice !== null ? "imported_snapshot" : "awaiting_collection",
          datasetId: ds.id,
          is_sample: !!ds.is_sample,
          notes: `Importado do arquivo preservado ${ds.originalName}`,
        });
        importedCount += 1;
      }
    }

    saveState(state);
    return res.json({
      importedCount,
      assets: state.financialAssets,
    });
  },
);

/* ────────────────────────────────────────────────────────── */
/*  5. Integrações e Verificação de Serviços                   */
/* ────────────────────────────────────────────────────────── */

adminRouter.get(
  "/api/integrations/status",
  requireAdminAuth,
  async (_req, res) => {
    const cfg = getServerConfig();
    const storage = calculateDirectoryStorageBytes();
    const checkedAt = new Date().toISOString();

    // 1. Verifica conectividade com a API pública financeira (AwesomeAPI / BCB)
    let financeFeedReachable = false;
    let financeFeedLatencyMs: number | null = null;
    try {
      const t0 = Date.now();
      const ping = await fetch(
        "https://economia.awesomeapi.com.br/json/last/USD-BRL",
        { method: "GET" },
      );
      financeFeedLatencyMs = Date.now() - t0;
      financeFeedReachable = ping.ok;
    } catch {
      financeFeedReachable = false;
    }

    const hasGeminiKey = Boolean(cfg.geminiApiKey);
    const hasVertexConfig = Boolean(cfg.vertexProjectId);
    const hasUpstreamScraping = Boolean(cfg.upstreamScrapingApiUrl);
    const hasGcsBucket = Boolean(cfg.gcsBucketName);
    const hasCloudflareConfig = Boolean(
      cfg.cloudflareAccountId && (cfg.cloudflareR2Bucket || cfg.cloudflareD1DatabaseId),
    );

    const services = [
      {
        id: "scraping_pipeline",
        name: "Motor de Coleta Bot Signature (/v1/scraping)",
        category: "Coleta & Pipeline",
        status: "verified" as const,
        statusLabel: hasUpstreamScraping
          ? "Conectado ao Cluster Upstream"
          : "Ativo (Coletor HTTP Local Verificado)",
        endpoint: hasUpstreamScraping
          ? cfg.upstreamScrapingApiUrl
          : "Interno (/v1/scraping/jobs)",
        details: `Suporte a SHA-256, retentativas automáticas e download autenticado. ${storage.fileCount} artefatos no diretório /output.`,
        verifiedAt: checkedAt,
        configKeys: [
          {
            key: "UPSTREAM_SCRAPING_API_URL",
            configured: hasUpstreamScraping,
            valuePreview: hasUpstreamScraping
              ? cfg.upstreamScrapingApiUrl
              : "Usando motor local embutido",
          },
        ],
      },
      {
        id: "ai_assistant",
        name: "Assistente de Análise IA (Gemini / Vertex AI)",
        category: "Inteligência Artificial",
        status:
          cfg.aiProvider === "vertex"
            ? hasVertexConfig
              ? ("verified" as const)
              : ("pending_config" as const)
            : hasGeminiKey
              ? ("verified" as const)
              : ("pending_config" as const),
        statusLabel:
          cfg.aiProvider === "vertex"
            ? hasVertexConfig
              ? `Configurado (Vertex AI • ${cfg.aiModel})`
              : "Configuração pendente"
            : hasGeminiKey
              ? `Ativo (${cfg.aiProvider.toUpperCase()} • ${cfg.aiModel})`
              : "Configuração pendente",
        endpoint:
          cfg.aiProvider === "vertex"
            ? `https://${cfg.vertexLocation}-aiplatform.googleapis.com`
            : "https://generativelanguage.googleapis.com/v1beta",
        details:
          cfg.aiProvider === "vertex" && !hasVertexConfig
            ? "Provedor Vertex AI selecionado, aguardando VERTEX_PROJECT_ID no servidor."
            : hasGeminiKey
              ? `Provedor servidor configurado (${cfg.aiProvider}) com modelo ${cfg.aiModel}. Chamadas ocorrem exclusivamente sob demanda do administrador.`
              : "Defina GEMINI_API_KEY ou VERTEX_PROJECT_ID nas variáveis de ambiente do servidor.",
        verifiedAt: checkedAt,
        configKeys: [
          {
            key: "AI_PROVIDER",
            configured: true,
            valuePreview: cfg.aiProvider,
          },
          {
            key: "AI_MODEL",
            configured: true,
            valuePreview: cfg.aiModel,
          },
          {
            key: "GEMINI_API_KEY",
            configured: hasGeminiKey,
            valuePreview: hasGeminiKey ? "•••••••• (Presente no servidor)" : "Configuração pendente",
          },
          {
            key: "VERTEX_PROJECT_ID",
            configured: hasVertexConfig,
            valuePreview: hasVertexConfig ? cfg.vertexProjectId : "Configuração pendente",
          },
        ],
      },
      {
        id: "financial_feeds",
        name: "Conectores de Cotações (AwesomeAPI & BCB SGS)",
        category: "Monitor Financeiro",
        status: financeFeedReachable ? ("verified" as const) : ("error" as const),
        statusLabel: financeFeedReachable
          ? `Verificado (${financeFeedLatencyMs} ms)`
          : "Falha de conexão externa",
        endpoint: "https://economia.awesomeapi.com.br / api.bcb.gov.br",
        details: financeFeedReachable
          ? "Coleta de câmbio (PTAX/Spot), criptoativos e série Selic operacional a partir do servidor."
          : "Não foi possível alcançar o feed público a partir deste ambiente de rede.",
        verifiedAt: checkedAt,
        configKeys: [
          {
            key: "AwesomeAPI / BCB Public Feeds",
            configured: true,
            valuePreview: financeFeedReachable ? "Online" : "Indisponível",
          },
        ],
      },
      {
        id: "cloud_storage_gcs",
        name: "Google Cloud Storage (Datasets > 1MB)",
        category: "Armazenamento em Nuvem",
        status: hasGcsBucket ? ("verified" as const) : ("pending_config" as const),
        statusLabel: hasGcsBucket ? `Conectado (${cfg.gcsBucketName})` : "Configuração pendente",
        endpoint: hasGcsBucket ? `gs://${cfg.gcsBucketName}` : "Não configurado",
        details: hasGcsBucket
          ? `Bucket GCS configurado para ingestão de arquivos extensos.`
          : "Armazenamento local em disco (/output/originals) está ativo. Configure GCS_BUCKET_NAME para replicação em nuvem.",
        verifiedAt: checkedAt,
        configKeys: [
          {
            key: "GCS_BUCKET_NAME",
            configured: hasGcsBucket,
            valuePreview: hasGcsBucket ? cfg.gcsBucketName : "Configuração pendente",
          },
        ],
      },
      {
        id: "cloudflare_edge",
        name: "Cloudflare Workers / R2 / D1",
        category: "Infraestrutura & Publicação",
        status: hasCloudflareConfig ? ("verified" as const) : ("pending_config" as const),
        statusLabel: hasCloudflareConfig
          ? "Configurado para Deploy"
          : "Configuração pendente",
        endpoint: hasCloudflareConfig
          ? `Account ${cfg.cloudflareAccountId.slice(0, 6)}...`
          : "wrangler.toml preparado",
        details: hasCloudflareConfig
          ? "Credenciais Cloudflare detectadas no ambiente."
          : "Arquivo wrangler.toml pronto na raiz do projeto. Defina CLOUDFLARE_ACCOUNT_ID, CLOUDFLARE_R2_BUCKET e CLOUDFLARE_D1_DATABASE_ID para vincular recursos de borda.",
        verifiedAt: checkedAt,
        configKeys: [
          {
            key: "CLOUDFLARE_ACCOUNT_ID",
            configured: Boolean(cfg.cloudflareAccountId),
            valuePreview: cfg.cloudflareAccountId
              ? "•••••••• (Configurado)"
              : "Configuração pendente",
          },
          {
            key: "CLOUDFLARE_R2_BUCKET",
            configured: Boolean(cfg.cloudflareR2Bucket),
            valuePreview: cfg.cloudflareR2Bucket || "Configuração pendente",
          },
          {
            key: "CLOUDFLARE_D1_DATABASE_ID",
            configured: Boolean(cfg.cloudflareD1DatabaseId),
            valuePreview: cfg.cloudflareD1DatabaseId || "Configuração pendente",
          },
        ],
      },
    ];

    return res.json({
      checkedAt,
      aiConfig: {
        provider: cfg.aiProvider,
        model: cfg.aiModel,
        ready:
          cfg.aiProvider === "vertex"
            ? hasVertexConfig || hasGeminiKey
            : hasGeminiKey,
        vertexReady: hasVertexConfig,
      },
      services,
    });
  },
);

/* ────────────────────────────────────────────────────────── */
/*  6. Assistente de Análise (Execução sob demanda no server)  */
/* ────────────────────────────────────────────────────────── */

adminRouter.post(
  "/api/ai/analyze-on-demand",
  requireAdminAuth,
  async (req, res) => {
    const { question, contextType = "general", datasetId } = req.body || {};

    if (!question || typeof question !== "string" || !question.trim()) {
      return res.status(400).json({
        error: "Digite uma pergunta ou instrução para solicitar a análise.",
      });
    }

    const state = loadState();
    let contextSummary = "";
    let sampleRows: Array<Record<string, unknown>> = [];
    let datasetName = "Operação Bot Signature";

    if (contextType === "dataset" && datasetId) {
      const ds = state.datasets.find((d) => d.id === datasetId);
      if (ds) {
        datasetName = ds.originalName;
        contextSummary = `Dataset: ${ds.originalName} (${ds.format.toUpperCase()}), Linhas: ${ds.rowCount}, Colunas (${ds.columnCount}): ${ds.columns.join(", ")}. Valores ausentes: ${ds.missingValuesCount}. Linhas duplicadas: ${ds.duplicateRowsCount}. SHA-256: ${ds.sha256}.`;
        const fullPath = getOriginalDatasetPath(ds.storedFilename);
        if (fs.existsSync(fullPath)) {
          try {
            const parsed = parseUploadedSpreadsheet(
              fs.readFileSync(fullPath),
              ds.originalName,
            );
            sampleRows = parsed.rows.slice(0, 20);
          } catch {
            // ignore
          }
        }
      }
    } else if (contextType === "scraping") {
      datasetName = "Pipeline de Coleta (/v1/scraping/jobs)";
      contextSummary = `Total de tarefas: ${state.jobs.length}. Concluídas: ${state.jobs.filter((j) => j.status === "completed").length}, Pendentes: ${state.jobs.filter((j) => j.status === "pending").length}, Com falha: ${state.jobs.filter((j) => j.status === "failed").length}.`;
      sampleRows = state.jobs.map((j) => ({
        id: j.id,
        label: j.label,
        url: j.url,
        status: j.status,
        attempts: `${j.attempts}/${j.max_attempts}`,
        file_size: j.file_size,
        error: j.error_message,
      }));
    } else if (contextType === "finance") {
      datasetName = "Monitor Financeiro Bot Signature";
      contextSummary = `Total de ativos monitorados: ${state.financialAssets.length}. Coletados: ${state.financialAssets.filter((a) => a.originType === "collected").length}, Snapshots importados: ${state.financialAssets.filter((a) => a.originType === "imported_snapshot").length}, Aguardando coleta: ${state.financialAssets.filter((a) => a.originType === "awaiting_collection").length}.`;
      sampleRows = state.financialAssets.map((a) => ({
        symbol: a.symbol,
        name: a.name,
        source: a.source,
        price: a.price,
        currency: a.currency,
        originType: a.originType,
        observedAt: a.observedAt,
      }));
    } else {
      contextSummary = `Visão Geral Bot Signature — Tarefas de coleta: ${state.jobs.length}, Datasets preservados: ${state.datasets.length}, Ativos financeiros: ${state.financialAssets.length}.`;
    }

    try {
      const result = await runOnDemandAiAnalysis({
        question: question.trim(),
        contextType,
        datasetName,
        contextSummary,
        sampleRows,
      });
      return res.json(result);
    } catch (err: any) {
      console.error("[ai/analyze-on-demand] Erro:", err);
      return res.status(500).json({
        error:
          err?.message ||
          "Falha ao executar análise no provedor de IA configurado.",
      });
    }
  },
);
