import fs from "fs";
import path from "path";
import crypto from "crypto";
import { getServerConfig } from "./config.ts";

export type ScrapingJobStatus = "pending" | "processing" | "completed" | "failed";

export interface ScrapingAttemptLog {
  attempt: number;
  timestamp: string;
  status: "success" | "error";
  httpStatus?: number;
  durationMs: number;
  error?: string;
}

export interface ScrapingJob {
  id: string;
  url: string;
  label: string;
  targetFormat: "html" | "json" | "csv" | "text";
  status: ScrapingJobStatus;
  attempts: number;
  max_attempts: number;
  error_message: string | null;
  file_size: number | null;
  sha256: string | null;
  content_type: string | null;
  artifact_filename: string | null;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
  is_sample?: boolean;
  attempt_logs: ScrapingAttemptLog[];
}

export interface StoredDatasetMeta {
  id: string;
  originalName: string;
  storedFilename: string;
  format: "csv" | "xlsx";
  sizeBytes: number;
  sha256: string;
  rowCount: number;
  columnCount: number;
  columns: string[];
  missingValuesCount: number;
  duplicateRowsCount: number;
  uploadedAt: string;
  is_sample?: boolean;
}

export type FinancialOriginType =
  | "collected"
  | "imported_snapshot"
  | "awaiting_collection";

export interface FinancialObservation {
  id: string;
  symbol: string;
  name: string;
  category: "Câmbio" | "Criptoativo" | "Índice / Ação" | "Taxa / Commodity";
  source: string;
  price: number | null;
  currency: string;
  changePercent24h: number | null;
  observedAt: string | null;
  originType: FinancialOriginType;
  jobId?: string;
  datasetId?: string;
  is_sample?: boolean;
  notes?: string;
}

interface PersistedState {
  jobs: ScrapingJob[];
  datasets: StoredDatasetMeta[];
  financialAssets: FinancialObservation[];
  lastUpdated: string;
}

const OUTPUT_ROOT = path.join(process.cwd(), "output");
const SCRAPING_DIR = path.join(OUTPUT_ROOT, "scraping");
const ORIGINALS_DIR = path.join(OUTPUT_ROOT, "originals");
const STATE_FILE = path.join(OUTPUT_ROOT, "bot_signature_state.json");

function ensureDirs() {
  for (const dir of [OUTPUT_ROOT, SCRAPING_DIR, ORIGINALS_DIR]) {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }
}

function sha256Buffer(buf: Buffer | string): string {
  return crypto.createHash("sha256").update(buf).digest("hex");
}

function createInitialSeedState(): PersistedState {
  ensureDirs();
  const now = new Date();
  const tMinus30m = new Date(now.getTime() - 30 * 60 * 1000).toISOString();
  const tMinus15m = new Date(now.getTime() - 15 * 60 * 1000).toISOString();
  const tMinus5m = new Date(now.getTime() - 5 * 60 * 1000).toISOString();

  // Create sample artifact files on disk so authenticated download works immediately
  const sampleJsonPayload = JSON.stringify(
    {
      source: "https://dadosabertos.bcb.gov.br/dataset/taxas-de-cambio",
      collected_by: "Bot Signature Pipeline v1",
      timestamp: tMinus15m,
      records: [
        { moeda: "USD", compra: 5.142, venda: 5.148, boletim: "Fechamento PTAX" },
        { moeda: "EUR", compra: 5.581, venda: 5.589, boletim: "Fechamento PTAX" },
      ],
    },
    null,
    2,
  );
  const sampleBuf = Buffer.from(sampleJsonPayload, "utf-8");
  const sampleSha = sha256Buffer(sampleBuf);
  const sampleArtifactName = "job_bs_sample_01.json";
  fs.writeFileSync(path.join(SCRAPING_DIR, sampleArtifactName), sampleBuf);

  const sampleCsvPayload = `id_transacao,data_operacao,ativo,fonte,preco_unitario,volume,status_conciliacao
TX-1001,2026-10-01,USD/BRL,BCB PTAX,5.12,150000,Conciliado
TX-1002,2026-10-02,PETR4,B3 Feed,38.45,4200,Conciliado
TX-1003,2026-10-03,VALE3,B3 Feed,61.20,3100,Pendente
TX-1003,2026-10-03,VALE3,B3 Feed,61.20,3100,Pendente
TX-1004,2026-10-04,BTC/BRL,Mercado Cripto,,12,Revisao
TX-1005,2026-10-05,ITUB4,B3 Feed,34.80,,Conciliado
TX-1006,2026-10-06,EUR/BRL,BCB PTAX,5.58,85000,Conciliado
TX-1007,2026-10-07,WEGE3,B3 Feed,52.10,1900,Conciliado`;

  const sampleCsvBuf = Buffer.from(sampleCsvPayload, "utf-8");
  const sampleCsvSha = sha256Buffer(sampleCsvBuf);
  const sampleCsvStored = "sample_operacoes_financeiras.csv";
  fs.writeFileSync(path.join(ORIGINALS_DIR, sampleCsvStored), sampleCsvBuf);

  const jobs: ScrapingJob[] = [
    {
      id: "job_bs_sample_01",
      url: "https://olinda.bcb.gov.br/olinda/servico/PTAX/versao/v1/odata",
      label: "Boletim PTAX Banco Central (Dados de exemplo)",
      targetFormat: "json",
      status: "completed",
      attempts: 1,
      max_attempts: 3,
      error_message: null,
      file_size: sampleBuf.length,
      sha256: sampleSha,
      content_type: "application/json; charset=utf-8",
      artifact_filename: sampleArtifactName,
      created_at: tMinus30m,
      updated_at: tMinus15m,
      completed_at: tMinus15m,
      is_sample: true,
      attempt_logs: [
        {
          attempt: 1,
          timestamp: tMinus15m,
          status: "success",
          httpStatus: 200,
          durationMs: 342,
        },
      ],
    },
    {
      id: "job_bs_sample_02",
      url: "https://economia.awesomeapi.com.br/json/last/USD-BRL,EUR-BRL,BTC-BRL",
      label: "AwesomeAPI Cotações Spot (Dados de exemplo)",
      targetFormat: "json",
      status: "pending",
      attempts: 0,
      max_attempts: 3,
      error_message: null,
      file_size: null,
      sha256: null,
      content_type: null,
      artifact_filename: null,
      created_at: tMinus5m,
      updated_at: tMinus5m,
      completed_at: null,
      is_sample: true,
      attempt_logs: [],
    },
    {
      id: "job_bs_sample_03",
      url: "https://portal-legado.interno.invalid/relatorios/fechamento-diario.csv",
      label: "Exportação Legado Intranet (Dados de exemplo)",
      targetFormat: "csv",
      status: "failed",
      attempts: 3,
      max_attempts: 3,
      error_message: "ENOTFOUND: Host portal-legado.interno.invalid não pôde ser resolvido após 3 tentativas.",
      file_size: null,
      sha256: null,
      content_type: null,
      artifact_filename: null,
      created_at: tMinus30m,
      updated_at: tMinus5m,
      completed_at: null,
      is_sample: true,
      attempt_logs: [
        {
          attempt: 1,
          timestamp: tMinus30m,
          status: "error",
          durationMs: 1210,
          error: "getaddrinfo ENOTFOUND portal-legado.interno.invalid",
        },
        {
          attempt: 2,
          timestamp: tMinus15m,
          status: "error",
          durationMs: 1150,
          error: "getaddrinfo ENOTFOUND portal-legado.interno.invalid",
        },
        {
          attempt: 3,
          timestamp: tMinus5m,
          status: "error",
          durationMs: 1185,
          error: "getaddrinfo ENOTFOUND portal-legado.interno.invalid",
        },
      ],
    },
  ];

  const datasets: StoredDatasetMeta[] = [
    {
      id: "ds_sample_01",
      originalName: "operacoes_financeiras_exemplo.csv",
      storedFilename: sampleCsvStored,
      format: "csv",
      sizeBytes: sampleCsvBuf.length,
      sha256: sampleCsvSha,
      rowCount: 8,
      columnCount: 7,
      columns: [
        "id_transacao",
        "data_operacao",
        "ativo",
        "fonte",
        "preco_unitario",
        "volume",
        "status_conciliacao",
      ],
      missingValuesCount: 2,
      duplicateRowsCount: 1,
      uploadedAt: tMinus30m,
      is_sample: true,
    },
  ];

  const financialAssets: FinancialObservation[] = [
    {
      id: "fin_sample_usd",
      symbol: "USD/BRL",
      name: "Dólar Comercial PTAX",
      category: "Câmbio",
      source: "Pipeline BCB PTAX (job_bs_sample_01)",
      price: 5.148,
      currency: "BRL",
      changePercent24h: 0.42,
      observedAt: tMinus15m,
      originType: "collected",
      jobId: "job_bs_sample_01",
      is_sample: true,
      notes: "Coletado pelo pipeline de scraping",
    },
    {
      id: "fin_sample_eur",
      symbol: "EUR/BRL",
      name: "Euro Comercial",
      category: "Câmbio",
      source: "Pipeline BCB PTAX (job_bs_sample_01)",
      price: 5.589,
      currency: "BRL",
      changePercent24h: -0.18,
      observedAt: tMinus15m,
      originType: "collected",
      jobId: "job_bs_sample_01",
      is_sample: true,
      notes: "Coletado pelo pipeline de scraping",
    },
    {
      id: "fin_sample_petr4",
      symbol: "PETR4",
      name: "Petrobras PN",
      category: "Índice / Ação",
      source: "Snapshot CSV (operacoes_financeiras_exemplo.csv)",
      price: 38.45,
      currency: "BRL",
      changePercent24h: 1.15,
      observedAt: tMinus30m,
      originType: "imported_snapshot",
      datasetId: "ds_sample_01",
      is_sample: true,
      notes: "Importado via Analisador de Dados",
    },
    {
      id: "fin_sample_vale3",
      symbol: "VALE3",
      name: "Vale ON",
      category: "Índice / Ação",
      source: "Snapshot CSV (operacoes_financeiras_exemplo.csv)",
      price: 61.2,
      currency: "BRL",
      changePercent24h: -0.65,
      observedAt: tMinus30m,
      originType: "imported_snapshot",
      datasetId: "ds_sample_01",
      is_sample: true,
      notes: "Importado via Analisador de Dados",
    },
    {
      id: "fin_sample_btc",
      symbol: "BTC/BRL",
      name: "Bitcoin Spot BRL",
      category: "Criptoativo",
      source: "AwesomeAPI / Mercado Cripto",
      price: null,
      currency: "BRL",
      changePercent24h: null,
      observedAt: null,
      originType: "awaiting_collection",
      jobId: "job_bs_sample_02",
      is_sample: true,
      notes: "Aguardando execução da tarefa de coleta",
    },
    {
      id: "fin_sample_selic",
      symbol: "SELIC-META",
      name: "Taxa Selic Meta Anual (%)",
      category: "Taxa / Commodity",
      source: "SGS Banco Central (Série 432)",
      price: null,
      currency: "PCT",
      changePercent24h: null,
      observedAt: null,
      originType: "awaiting_collection",
      is_sample: true,
      notes: "Aguardando janela de coleta automática",
    },
  ];

  return {
    jobs,
    datasets,
    financialAssets,
    lastUpdated: now.toISOString(),
  };
}

let cachedState: PersistedState | null = null;

export function loadState(): PersistedState {
  ensureDirs();
  if (cachedState) return cachedState;

  if (fs.existsSync(STATE_FILE)) {
    try {
      const raw = fs.readFileSync(STATE_FILE, "utf-8");
      cachedState = JSON.parse(raw) as PersistedState;
      return cachedState;
    } catch (e) {
      console.error("[store] Failed to parse state file, recreating seed:", e);
    }
  }

  cachedState = createInitialSeedState();
  saveState(cachedState);
  return cachedState;
}

export function saveState(state: PersistedState): void {
  ensureDirs();
  state.lastUpdated = new Date().toISOString();
  cachedState = state;
  try {
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), "utf-8");
  } catch (e) {
    console.error("[store] Failed to persist state:", e);
  }
}

export function calculateDirectoryStorageBytes(dirPath: string = OUTPUT_ROOT): {
  totalBytes: number;
  scrapingBytes: number;
  originalsBytes: number;
  fileCount: number;
} {
  ensureDirs();
  let totalBytes = 0;
  let scrapingBytes = 0;
  let originalsBytes = 0;
  let fileCount = 0;

  function walk(current: string, category: "scraping" | "originals" | "other") {
    if (!fs.existsSync(current)) return;
    const entries = fs.readdirSync(current, { withFileTypes: true });
    for (const entry of entries) {
      const full = path.join(current, entry.name);
      if (entry.isDirectory()) {
        const nextCat =
          entry.name === "scraping"
            ? "scraping"
            : entry.name === "originals"
              ? "originals"
              : category;
        walk(full, nextCat);
      } else if (entry.isFile()) {
        const st = fs.statSync(full);
        totalBytes += st.size;
        fileCount += 1;
        if (category === "scraping") scrapingBytes += st.size;
        if (category === "originals") originalsBytes += st.size;
      }
    }
  }

  walk(dirPath, "other");
  return { totalBytes, scrapingBytes, originalsBytes, fileCount };
}

/**
 * Executa a coleta HTTP real de um ScrapingJob com suporte a retentativas,
 * cálculo de SHA-256 e persistência do artefato original para download autenticado.
 */
export async function executeScrapingJob(jobId: string): Promise<ScrapingJob | null> {
  const state = loadState();
  const job = state.jobs.find((j) => j.id === jobId);
  if (!job) return null;

  const cfg = getServerConfig();

  // Se houver um serviço upstream configurado, tenta encaminhar primeiro
  if (cfg.upstreamScrapingApiUrl) {
    try {
      const upstreamRes = await fetch(`${cfg.upstreamScrapingApiUrl}/v1/scraping/jobs`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(cfg.upstreamScrapingApiToken
            ? { Authorization: `Bearer ${cfg.upstreamScrapingApiToken}` }
            : {}),
        },
        body: JSON.stringify({ url: job.url, label: job.label }),
      });
      if (upstreamRes.ok) {
        const upstreamData: any = await upstreamRes.json();
        job.status = upstreamData.status || "completed";
        job.sha256 = upstreamData.sha256 || job.sha256;
        job.file_size = upstreamData.file_size ?? job.file_size;
        job.updated_at = new Date().toISOString();
        saveState(state);
        return job;
      }
    } catch (err) {
      console.warn("[scraping] Upstream indisponível, utilizando coletor local:", err);
    }
  }

  job.status = "processing";
  job.error_message = null;
  job.updated_at = new Date().toISOString();
  saveState(state);

  const maxAttempts = Math.max(1, job.max_attempts || 3);

  while (job.attempts < maxAttempts) {
    job.attempts += 1;
    const startMs = Date.now();
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 12000);

      const res = await fetch(job.url, {
        method: "GET",
        headers: {
          "User-Agent": "BotSignature-Collector/1.0 (+https://botsignature.com.br)",
          Accept: "application/json, text/csv, text/plain, text/html, */*",
        },
        signal: controller.signal,
      });
      clearTimeout(timeout);

      const durationMs = Date.now() - startMs;

      if (!res.ok) {
        const errMsg = `HTTP ${res.status} (${res.statusText})`;
        job.attempt_logs.push({
          attempt: job.attempts,
          timestamp: new Date().toISOString(),
          status: "error",
          httpStatus: res.status,
          durationMs,
          error: errMsg,
        });
        job.error_message = errMsg;
        job.updated_at = new Date().toISOString();
        saveState(state);
        if (job.attempts < maxAttempts) {
          await new Promise((r) => setTimeout(r, 600));
          continue;
        } else {
          job.status = "failed";
          saveState(state);
          return job;
        }
      }

      const arrayBuffer = await res.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);
      const hash = sha256Buffer(buffer);
      const contentType = res.headers.get("content-type") || "application/octet-stream";

      let ext = "bin";
      if (contentType.includes("json") || job.targetFormat === "json") ext = "json";
      else if (contentType.includes("csv") || job.targetFormat === "csv") ext = "csv";
      else if (contentType.includes("html") || job.targetFormat === "html") ext = "html";
      else ext = "txt";

      const filename = `${job.id}.${ext}`;
      const filePath = path.join(SCRAPING_DIR, filename);
      fs.writeFileSync(filePath, buffer);

      const completedIso = new Date().toISOString();
      job.status = "completed";
      job.file_size = buffer.length;
      job.sha256 = hash;
      job.content_type = contentType;
      job.artifact_filename = filename;
      job.error_message = null;
      job.updated_at = completedIso;
      job.completed_at = completedIso;
      job.is_sample = false;
      job.attempt_logs.push({
        attempt: job.attempts,
        timestamp: completedIso,
        status: "success",
        httpStatus: res.status,
        durationMs,
      });

      // Se for JSON de cotação (ex: AwesomeAPI), atualiza automaticamente o Monitor Financeiro!
      if (ext === "json") {
        try {
          const parsedJson = JSON.parse(buffer.toString("utf-8"));
          syncFinancialFromCollectedJson(state, parsedJson, job);
        } catch {
          // ignore non-quote json
        }
      }

      saveState(state);
      return job;
    } catch (err: any) {
      const durationMs = Date.now() - startMs;
      const errMsg = err?.message || String(err);
      job.attempt_logs.push({
        attempt: job.attempts,
        timestamp: new Date().toISOString(),
        status: "error",
        durationMs,
        error: errMsg,
      });
      job.error_message = errMsg;
      job.updated_at = new Date().toISOString();
      saveState(state);

      if (job.attempts < maxAttempts) {
        await new Promise((r) => setTimeout(r, 600));
      } else {
        job.status = "failed";
        saveState(state);
      }
    }
  }

  return job;
}

function syncFinancialFromCollectedJson(
  state: PersistedState,
  data: any,
  job: ScrapingJob,
) {
  if (!data || typeof data !== "object") return;
  const nowIso = new Date().toISOString();

  // AwesomeAPI pattern: { USDBRL: { code: 'USD', codein: 'BRL', bid: '5.15', pctChange: '0.3' } }
  for (const key of Object.keys(data)) {
    const item = data[key];
    if (item && typeof item === "object" && item.code && item.bid) {
      const symbol = `${item.code}/${item.codein || "BRL"}`;
      const price = parseFloat(item.bid);
      const pct = item.pctChange ? parseFloat(item.pctChange) : null;
      if (!isNaN(price)) {
        const existing = state.financialAssets.find(
          (a) => a.symbol.toUpperCase() === symbol.toUpperCase(),
        );
        if (existing) {
          existing.price = price;
          existing.changePercent24h = pct !== null && !isNaN(pct) ? pct : existing.changePercent24h;
          existing.observedAt = nowIso;
          existing.originType = "collected";
          existing.source = `Coleta Real (${job.id})`;
          existing.jobId = job.id;
          existing.is_sample = false;
          existing.notes = `Atualizado via pipeline (${job.url})`;
        } else {
          state.financialAssets.unshift({
            id: `fin_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            symbol,
            name: item.name || symbol,
            category: item.code === "BTC" || item.code === "ETH" ? "Criptoativo" : "Câmbio",
            source: `Coleta Real (${job.id})`,
            price,
            currency: item.codein || "BRL",
            changePercent24h: pct !== null && !isNaN(pct) ? pct : null,
            observedAt: nowIso,
            originType: "collected",
            jobId: job.id,
            is_sample: false,
            notes: `Coletado de ${job.url}`,
          });
        }
      }
    }
  }
}

/**
 * Executa coleta ao vivo de cotações reais para os itens do Monitor Financeiro
 */
export async function collectLiveFinancialQuotes(): Promise<{
  updatedCount: number;
  sourceUsed: string;
  assets: FinancialObservation[];
}> {
  const state = loadState();
  const nowIso = new Date().toISOString();
  let updatedCount = 0;
  let sourceUsed = "AwesomeAPI / Banco Central do Brasil";

  try {
    const res = await fetch(
      "https://economia.awesomeapi.com.br/json/last/USD-BRL,EUR-BRL,BTC-BRL",
      {
        headers: { "User-Agent": "BotSignature-FinancialMonitor/1.0" },
      },
    );
    if (res.ok) {
      const data: any = await res.json();
      const mapQuote = (
        pairKey: string,
        symbol: string,
        defaultName: string,
        cat: FinancialObservation["category"],
      ) => {
        const q = data[pairKey];
        if (!q || !q.bid) return;
        const price = parseFloat(q.bid);
        const pct = q.pctChange ? parseFloat(q.pctChange) : 0;
        if (isNaN(price)) return;

        let asset = state.financialAssets.find((a) => a.symbol === symbol);
        if (asset) {
          asset.price = price;
          asset.changePercent24h = pct;
          asset.observedAt = nowIso;
          asset.originType = "collected";
          asset.source = "AwesomeAPI Spot (Tempo Real)";
          asset.is_sample = false;
          asset.notes = "Cotação verificada via requisição HTTP no servidor";
        } else {
          state.financialAssets.unshift({
            id: `fin_live_${symbol.replace("/", "_")}`,
            symbol,
            name: q.name || defaultName,
            category: cat,
            source: "AwesomeAPI Spot (Tempo Real)",
            price,
            currency: "BRL",
            changePercent24h: pct,
            observedAt: nowIso,
            originType: "collected",
            is_sample: false,
            notes: "Cotação verificada via requisição HTTP no servidor",
          });
        }
        updatedCount += 1;
      };

      mapQuote("USDBRL", "USD/BRL", "Dólar Comercial Spot", "Câmbio");
      mapQuote("EURBRL", "EUR/BRL", "Euro Comercial Spot", "Câmbio");
      mapQuote("BTCBRL", "BTC/BRL", "Bitcoin Spot BRL", "Criptoativo");
    }
  } catch (err) {
    console.warn("[finance] Falha ao consultar AwesomeAPI, tentando BCB SGS:", err);
  }

  // Consulta Taxa Selic Meta no SGS do Banco Central (Série 432)
  try {
    const bcbRes = await fetch(
      "https://api.bcb.gov.br/dados/serie/bcdata.sgs.432/dados/ultimos/1?formato=json",
      {
        headers: { "User-Agent": "BotSignature-FinancialMonitor/1.0" },
      },
    );
    if (bcbRes.ok) {
      const bcbData: any = await bcbRes.json();
      if (Array.isArray(bcbData) && bcbData[0]?.valor) {
        const val = parseFloat(String(bcbData[0].valor).replace(",", "."));
        if (!isNaN(val)) {
          const selic = state.financialAssets.find((a) => a.symbol === "SELIC-META");
          if (selic) {
            selic.price = val;
            selic.changePercent24h = 0;
            selic.observedAt = nowIso;
            selic.originType = "collected";
            selic.source = "Banco Central SGS (Série 432)";
            selic.is_sample = false;
            selic.notes = `Data referência BCB: ${bcbData[0].data}`;
            updatedCount += 1;
          }
        }
      }
    }
  } catch (err) {
    console.warn("[finance] Falha ao consultar BCB SGS 432:", err);
  }

  saveState(state);
  return {
    updatedCount,
    sourceUsed,
    assets: state.financialAssets,
  };
}

export function getScrapingArtifactPath(filename: string): string {
  ensureDirs();
  return path.join(SCRAPING_DIR, path.basename(filename));
}

export function getOriginalDatasetPath(filename: string): string {
  ensureDirs();
  return path.join(ORIGINALS_DIR, path.basename(filename));
}

export function saveOriginalDatasetFile(
  originalName: string,
  buffer: Buffer,
  stats: {
    format: "csv" | "xlsx";
    rowCount: number;
    columnCount: number;
    columns: string[];
    missingValuesCount: number;
    duplicateRowsCount: number;
  },
): StoredDatasetMeta {
  ensureDirs();
  const state = loadState();
  const safeName = originalName.replace(/[^a-zA-Z0-9._-]/g, "_");
  const id = `ds_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
  const storedFilename = `${id}_${safeName}`;
  const fullPath = path.join(ORIGINALS_DIR, storedFilename);

  // Preserva o arquivo binário original intacto
  fs.writeFileSync(fullPath, buffer);
  const sha256 = sha256Buffer(buffer);

  const meta: StoredDatasetMeta = {
    id,
    originalName,
    storedFilename,
    format: stats.format,
    sizeBytes: buffer.length,
    sha256,
    rowCount: stats.rowCount,
    columnCount: stats.columnCount,
    columns: stats.columns,
    missingValuesCount: stats.missingValuesCount,
    duplicateRowsCount: stats.duplicateRowsCount,
    uploadedAt: new Date().toISOString(),
    is_sample: false,
  };

  state.datasets.unshift(meta);
  saveState(state);
  return meta;
}
