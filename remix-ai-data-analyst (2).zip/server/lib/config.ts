import path from "path";
import crypto from "crypto";

export interface ServerConfig {
  port: number;
  adminEmail: string;
  adminPassword: string;
  sessionSecret: string;
  upstreamScrapingApiUrl: string;
  upstreamScrapingApiToken: string;
  aiProvider: "gemini" | "vertex" | "managed-agent";
  aiModel: string;
  geminiApiKey: string;
  vertexProjectId: string;
  vertexLocation: string;
  gcsBucketName: string;
  cloudflareAccountId: string;
  cloudflareR2Bucket: string;
  cloudflareD1DatabaseId: string;
  storageDir: string;
}

export function getServerConfig(): ServerConfig {
  const rawProvider = (process.env.AI_PROVIDER || "gemini").toLowerCase().trim();
  const aiProvider: "gemini" | "vertex" | "managed-agent" =
    rawProvider === "vertex"
      ? "vertex"
      : rawProvider === "managed-agent"
        ? "managed-agent"
        : "gemini";

  return {
    port: parseInt(process.env.PORT || "3000", 10) || 3000,
    adminEmail: (process.env.BOT_SIGNATURE_ADMIN_EMAIL || "admin@botsignature.com.br").trim(),
    adminPassword: process.env.BOT_SIGNATURE_ADMIN_PASSWORD || "admin-bot-signature-2026",
    sessionSecret:
      process.env.BOT_SIGNATURE_SESSION_SECRET ||
      "bs-secret-hmac-key-change-in-production",
    upstreamScrapingApiUrl: (process.env.UPSTREAM_SCRAPING_API_URL || "").trim().replace(/\/+$/, ""),
    upstreamScrapingApiToken: (process.env.UPSTREAM_SCRAPING_API_TOKEN || "").trim(),
    aiProvider,
    aiModel: (process.env.AI_MODEL || "gemini-3.8-flash").trim(),
    geminiApiKey: (process.env.GEMINI_API_KEY || "").trim(),
    vertexProjectId: (process.env.VERTEX_PROJECT_ID || "").trim(),
    vertexLocation: (process.env.VERTEX_LOCATION || "us-central1").trim(),
    gcsBucketName: (process.env.GCS_BUCKET_NAME || "").trim(),
    cloudflareAccountId: (process.env.CLOUDFLARE_ACCOUNT_ID || "").trim(),
    cloudflareR2Bucket: (process.env.CLOUDFLARE_R2_BUCKET || "").trim(),
    cloudflareD1DatabaseId: (process.env.CLOUDFLARE_D1_DATABASE_ID || "").trim(),
    storageDir: path.join(process.cwd(), "output"),
  };
}

export function signAdminToken(email: string, secret: string): string {
  const issuedAt = Date.now();
  const expiresAt = issuedAt + 12 * 60 * 60 * 1000; // 12 hours
  const payload = Buffer.from(
    JSON.stringify({ email, role: "admin", issuedAt, expiresAt }),
  ).toString("base64url");
  const signature = crypto
    .createHmac("sha256", secret)
    .update(payload)
    .digest("base64url");
  return `${payload}.${signature}`;
}

export function verifyAdminToken(
  token: string | undefined,
  secret: string,
): { valid: boolean; email?: string; expiresAt?: number } {
  if (!token || !token.includes(".")) return { valid: false };
  const [payload, signature] = token.split(".");
  if (!payload || !signature) return { valid: false };

  const expectedSig = crypto
    .createHmac("sha256", secret)
    .update(payload)
    .digest("base64url");

  if (signature !== expectedSig) return { valid: false };

  try {
    const decoded = JSON.parse(Buffer.from(payload, "base64url").toString("utf-8"));
    if (!decoded.expiresAt || Date.now() > decoded.expiresAt) {
      return { valid: false };
    }
    return {
      valid: true,
      email: decoded.email,
      expiresAt: decoded.expiresAt,
    };
  } catch {
    return { valid: false };
  }
}
