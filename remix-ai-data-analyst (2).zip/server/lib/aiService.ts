import { GoogleGenAI, Type } from "@google/genai";
import { getServerConfig } from "./config.ts";

export interface StructuredAiAnalysisRequest {
  question: string;
  contextType: "dataset" | "scraping" | "finance" | "general";
  datasetName?: string;
  contextSummary: string;
  sampleRows?: Array<Record<string, unknown>>;
}

export interface StructuredAiAnalysisResponse {
  provider: string;
  model: string;
  generated_at: string;
  title: string;
  executive_summary: string;
  insights: Array<{
    title: string;
    detail: string;
    metric?: string;
    value?: string;
  }>;
  recommendations: string[];
  methodology: string;
}

/**
 * Executa uma análise sob demanda utilizando o provedor e modelo configurados no servidor.
 * Nunca é chamado automaticamente em atualizações periódicas do dashboard — apenas
 * quando o administrador solicita explicitamente uma análise.
 */
export async function runOnDemandAiAnalysis(
  req: StructuredAiAnalysisRequest,
): Promise<StructuredAiAnalysisResponse> {
  const cfg = getServerConfig();

  if (cfg.aiProvider === "vertex" && !cfg.vertexProjectId && !cfg.geminiApiKey) {
    throw new Error(
      "Provedor Vertex AI selecionado, porém VERTEX_PROJECT_ID não está configurado no servidor (Configuração pendente).",
    );
  }

  if (!cfg.geminiApiKey) {
    throw new Error(
      "Chave GEMINI_API_KEY não encontrada no servidor. Verifique a seção Integrações (Configuração pendente).",
    );
  }

  const ai = new GoogleGenAI({
    apiKey: cfg.geminiApiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });

  const modelToUse = cfg.aiModel || "gemini-3.8-flash";

  const prompt = `Você é o Assistente de Análise Executiva da plataforma Bot Signature.
Responda sempre em português brasileiro (pt-BR), com rigor analítico, clareza e foco operacional.

CONTEXTO DA SOLICITAÇÃO:
- Tipo de contexto: ${req.contextType}
- Conjunto de dados / Escopo: ${req.datasetName || "Operação Bot Signature"}
- Pergunta do Administrador: ${req.question}

RESUMO DOS DADOS ARMAZENADOS:
${req.contextSummary}

${
  req.sampleRows && req.sampleRows.length > 0
    ? `AMOSTRA DE REGISTROS (JSON):\n${JSON.stringify(req.sampleRows.slice(0, 25), null, 2)}`
    : ""
}

Produza um relatório estruturado em JSON contendo título executivo, resumo executivo em markdown, insights quantitativos (com métrica e valor quando aplicável), recomendações práticas e metodologia aplicada.`;

  const response = await ai.models.generateContent({
    model: modelToUse,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: {
            type: Type.STRING,
            description: "Título conciso da análise executiva em português.",
          },
          executive_summary: {
            type: Type.STRING,
            description: "Resumo executivo detalhado em Markdown.",
          },
          insights: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                detail: { type: Type.STRING },
                metric: { type: Type.STRING },
                value: { type: Type.STRING },
              },
              required: ["title", "detail"],
            },
          },
          recommendations: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
          methodology: {
            type: Type.STRING,
          },
        },
        required: [
          "title",
          "executive_summary",
          "insights",
          "recommendations",
          "methodology",
        ],
      },
    },
  });

  const rawText = response.text?.trim() || "{}";
  const parsed = JSON.parse(rawText);

  return {
    provider: cfg.aiProvider,
    model: modelToUse,
    generated_at: new Date().toISOString(),
    title: parsed.title || "Relatório de Análise Executiva",
    executive_summary:
      parsed.executive_summary || "Análise concluída com base nos dados fornecidos.",
    insights: Array.isArray(parsed.insights) ? parsed.insights : [],
    recommendations: Array.isArray(parsed.recommendations)
      ? parsed.recommendations
      : [],
    methodology:
      parsed.methodology ||
      `Análise sob demanda via ${cfg.aiProvider.toUpperCase()} (${modelToUse})`,
  };
}
